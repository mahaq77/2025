using System;

namespace API.DTOs;

public class MessageResponseDto : MessageRequestDto
{

}

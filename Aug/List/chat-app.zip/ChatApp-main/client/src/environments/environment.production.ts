export const environment = {
    production:true,
    baseUrl:'https://chatapp-api.azurewebsites.net'
};

export const environment = {
    production:false,
    baseUrl:'localhost:5000'
};

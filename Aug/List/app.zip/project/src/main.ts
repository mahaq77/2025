import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ShellHeaderComponent } from './app/components/shell-header.component';
import { DashboardPageComponent } from './app/pages/dashboard-page.component';
import { ProductsPageComponent } from './app/pages/products-page.component';
import { OrdersPageComponent } from './app/pages/orders-page.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ShellHeaderComponent],
  template: `
    <div class="app-container" [class.dark-theme]="false">
      <app-shell-header></app-shell-header>
      
      <main class="main-content">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
  styles: [`
    .app-container {
      min-height: 100vh;
      background-color: #f9fafb;
      transition: all 0.3s ease;
    }
    
    .app-container.dark-theme {
      background-color: #111827;
      color: #f9fafb;
    }
    
    .main-content {
      min-height: calc(100vh - 60px);
    }
  `]
})
export class App {}

bootstrapApplication(App, {
  providers: [
    provideRouter([
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardPageComponent },
      { path: 'products', component: ProductsPageComponent },
      { path: 'orders', component: OrdersPageComponent },
      { path: '**', redirectTo: '/dashboard' }
    ])
  ]
});
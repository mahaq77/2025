import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MfeWrapperComponent } from '../components/mfe-wrapper.component';
import { MfeConfig } from '../../shared/models/communication.types';
import { MfeCommunicationService } from '../../shared/services/mfe-communication.service';

@Component({
  selector: 'app-products-page',
  standalone: true,
  imports: [CommonModule, MfeWrapperComponent],
  template: `
    <div class="products-page">
      <div class="page-header">
        <h2>Products</h2>
        <p>Manage your product catalog</p>
      </div>
      
      <!-- Fallback content when MFE is not available -->
      <div class="fallback-products">
        <div class="products-actions">
          <button (click)="addProduct()" class="primary-button">Add Product</button>
          <button (click)="refreshProducts()" class="secondary-button">Refresh</button>
        </div>
        
        <div class="products-grid">
          <div *ngFor="let product of products" class="product-card">
            <div class="product-image">
              <img [src]="product.image" [alt]="product.name" />
            </div>
            <div class="product-info">
              <h3>{{ product.name }}</h3>
              <p class="product-description">{{ product.description }}</p>
              <div class="product-price">${{ product.price }}</div>
              <div class="product-actions">
                <button (click)="editProduct(product)" class="edit-button">Edit</button>
                <button (click)="deleteProduct(product)" class="delete-button">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Uncomment when you have a real MFE -->
      <!-- <app-mfe-wrapper [mfeConfig]="productsMfeConfig"></app-mfe-wrapper> -->
    </div>
  `,
  styles: [`
    .products-page {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .page-header {
      margin-bottom: 2rem;
    }
    
    .page-header h2 {
      color: #1f2937;
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
    }
    
    .page-header p {
      color: #6b7280;
      margin: 0;
    }
    
    .products-actions {
      display: flex;
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .primary-button, .secondary-button {
      padding: 0.75rem 1.5rem;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .primary-button {
      background: #3b82f6;
      color: white;
      border: none;
    }
    
    .primary-button:hover {
      background: #2563eb;
    }
    
    .secondary-button {
      background: white;
      color: #374151;
      border: 1px solid #d1d5db;
    }
    
    .secondary-button:hover {
      background: #f9fafb;
    }
    
    .products-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 1.5rem;
    }
    
    .product-card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      border: 1px solid #e5e7eb;
      overflow: hidden;
    }
    
    .product-image {
      height: 200px;
      overflow: hidden;
    }
    
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .product-info {
      padding: 1rem;
    }
    
    .product-info h3 {
      color: #1f2937;
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0 0 0.5rem 0;
    }
    
    .product-description {
      color: #6b7280;
      font-size: 0.875rem;
      margin: 0 0 1rem 0;
    }
    
    .product-price {
      color: #059669;
      font-size: 1.25rem;
      font-weight: 700;
      margin-bottom: 1rem;
    }
    
    .product-actions {
      display: flex;
      gap: 0.5rem;
    }
    
    .edit-button, .delete-button {
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .edit-button {
      background: #f59e0b;
      color: white;
      border: none;
    }
    
    .edit-button:hover {
      background: #d97706;
    }
    
    .delete-button {
      background: #ef4444;
      color: white;
      border: none;
    }
    
    .delete-button:hover {
      background: #dc2626;
    }
  `]
})
export class ProductsPageComponent implements OnInit {
  private communicationService = inject(MfeCommunicationService);
  
  productsMfeConfig: MfeConfig = {
    name: 'products',
    displayName: 'Products',
    routePath: '/products',
    remoteEntry: 'http://localhost:4202/remoteEntry.js',
    exposedModule: './ProductsModule'
  };

  products = [
    {
      id: 1,
      name: 'Laptop Pro',
      description: 'High-performance laptop for professionals',
      price: 1299.99,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 2,
      name: 'Wireless Headphones',
      description: 'Premium noise-cancelling headphones',
      price: 299.99,
      image: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 3,
      name: 'Smart Watch',
      description: 'Advanced fitness and health tracking',
      price: 399.99,
      image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  ngOnInit(): void {
    // Listen for messages from other MFEs
    this.communicationService.onMessage().subscribe(message => {
      console.log('Products received message:', message);
      
      if (message.type === 'DASHBOARD_DATA_UPDATED') {
        console.log('Dashboard data updated, refreshing products view');
      }
    });
  }

  addProduct(): void {
    this.communicationService.broadcastNotification('New product added!', 'success');
    
    this.communicationService.sendMessage('PRODUCT_ADDED', {
      productId: Date.now(),
      name: 'New Product',
      timestamp: Date.now()
    }, 'products');
  }

  editProduct(product: any): void {
    console.log('Editing product:', product);
    this.communicationService.broadcastNotification(`Editing ${product.name}`, 'info');
  }

  deleteProduct(product: any): void {
    console.log('Deleting product:', product);
    this.products = this.products.filter(p => p.id !== product.id);
    
    this.communicationService.broadcastNotification(`${product.name} deleted`, 'warning');
    this.communicationService.sendMessage('PRODUCT_DELETED', {
      productId: product.id,
      timestamp: Date.now()
    }, 'products');
  }

  refreshProducts(): void {
    this.communicationService.broadcastNotification('Products refreshed', 'info');
  }
}
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MfeWrapperComponent } from '../components/mfe-wrapper.component';
import { MfeConfig } from '../../shared/models/communication.types';
import { MfeCommunicationService } from '../../shared/services/mfe-communication.service';

@Component({
  selector: 'app-dashboard-page',
  standalone: true,
  imports: [CommonModule, MfeWrapperComponent],
  template: `
    <div class="dashboard-page">
      <div class="page-header">
        <h2>Dashboard</h2>
        <p>Welcome to your microfrontend dashboard</p>
      </div>
      
      <!-- Fallback content when MFE is not available -->
      <div class="fallback-dashboard">
        <div class="dashboard-grid">
          <div class="dashboard-card">
            <h3>Welcome</h3>
            <p>This is a fallback dashboard component. In production, this would be replaced by a remote MFE.</p>
            <button (click)="simulateDataUpdate()" class="action-button">
              Simulate Data Update
            </button>
          </div>
          
          <div class="dashboard-card">
            <h3>Quick Stats</h3>
            <div class="stats">
              <div class="stat">
                <span class="stat-value">42</span>
                <span class="stat-label">Active Users</span>
              </div>
              <div class="stat">
                <span class="stat-value">128</span>
                <span class="stat-label">Total Orders</span>
              </div>
            </div>
          </div>
          
          <div class="dashboard-card">
            <h3>Recent Activity</h3>
            <ul class="activity-list">
              <li>User John Doe logged in</li>
              <li>Order #1234 was processed</li>
              <li>New product added to catalog</li>
            </ul>
          </div>
        </div>
      </div>
      
      <!-- Uncomment when you have a real MFE -->
      <!-- <app-mfe-wrapper [mfeConfig]="dashboardMfeConfig"></app-mfe-wrapper> -->
    </div>
  `,
  styles: [`
    .dashboard-page {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .page-header {
      margin-bottom: 2rem;
    }
    
    .page-header h2 {
      color: #1f2937;
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
    }
    
    .page-header p {
      color: #6b7280;
      margin: 0;
    }
    
    .dashboard-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }
    
    .dashboard-card {
      background: white;
      border-radius: 8px;
      padding: 1.5rem;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      border: 1px solid #e5e7eb;
    }
    
    .dashboard-card h3 {
      color: #1f2937;
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0 0 1rem 0;
    }
    
    .action-button {
      background: #3b82f6;
      color: white;
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      transition: background 0.2s ease;
    }
    
    .action-button:hover {
      background: #2563eb;
    }
    
    .stats {
      display: flex;
      gap: 2rem;
    }
    
    .stat {
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    
    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: #3b82f6;
    }
    
    .stat-label {
      font-size: 0.875rem;
      color: #6b7280;
    }
    
    .activity-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .activity-list li {
      padding: 0.5rem 0;
      color: #4b5563;
      border-bottom: 1px solid #f3f4f6;
    }
    
    .activity-list li:last-child {
      border-bottom: none;
    }
  `]
})
export class DashboardPageComponent implements OnInit {
  private communicationService = inject(MfeCommunicationService);
  
  dashboardMfeConfig: MfeConfig = {
    name: 'dashboard',
    displayName: 'Dashboard',
    routePath: '/dashboard',
    remoteEntry: 'http://localhost:4201/remoteEntry.js',
    exposedModule: './DashboardModule'
  };

  ngOnInit(): void {
    // Listen for messages from MFEs
    this.communicationService.onMessage().subscribe(message => {
      console.log('Dashboard received message:', message);
    });
  }

  simulateDataUpdate(): void {
    this.communicationService.broadcastNotification(
      'Dashboard data has been updated!', 
      'success'
    );
    
    // Simulate sending data to other MFEs
    this.communicationService.sendMessage('DASHBOARD_DATA_UPDATED', {
      timestamp: Date.now(),
      data: { activeUsers: 45, totalOrders: 132 }
    }, 'dashboard');
  }
}
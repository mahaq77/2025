import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MfeWrapperComponent } from '../components/mfe-wrapper.component';
import { MfeConfig } from '../../shared/models/communication.types';
import { MfeCommunicationService } from '../../shared/services/mfe-communication.service';

@Component({
  selector: 'app-orders-page',
  standalone: true,
  imports: [CommonModule, MfeWrapperComponent],
  template: `
    <div class="orders-page">
      <div class="page-header">
        <h2>Orders</h2>
        <p>Track and manage customer orders</p>
      </div>
      
      <!-- Fallback content when MFE is not available -->
      <div class="fallback-orders">
        <div class="orders-filters">
          <select (change)="filterOrders($event)" class="filter-select">
            <option value="">All Orders</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          
          <button (click)="createOrder()" class="primary-button">Create Order</button>
        </div>
        
        <div class="orders-table">
          <table>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Status</th>
                <th>Total</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let order of filteredOrders">
                <td class="order-id">#{{ order.id }}</td>
                <td>{{ order.customer }}</td>
                <td>{{ order.date | date:'short' }}</td>
                <td>
                  <span [class]="'status-badge ' + order.status">
                    {{ order.status | titlecase }}
                  </span>
                </td>
                <td class="order-total">${{ order.total }}</td>
                <td class="actions">
                  <button (click)="viewOrder(order)" class="view-button">View</button>
                  <button (click)="updateStatus(order)" class="update-button">Update</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      
      <!-- Uncomment when you have a real MFE -->
      <!-- <app-mfe-wrapper [mfeConfig]="ordersMfeConfig"></app-mfe-wrapper> -->
    </div>
  `,
  styles: [`
    .orders-page {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .page-header {
      margin-bottom: 2rem;
    }
    
    .page-header h2 {
      color: #1f2937;
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
    }
    
    .page-header p {
      color: #6b7280;
      margin: 0;
    }
    
    .orders-filters {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }
    
    .filter-select {
      padding: 0.5rem;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      background: white;
    }
    
    .primary-button {
      background: #3b82f6;
      color: white;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    
    .primary-button:hover {
      background: #2563eb;
    }
    
    .orders-table {
      background: white;
      border-radius: 8px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      border: 1px solid #e5e7eb;
      overflow: hidden;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
    }
    
    th, td {
      padding: 1rem;
      text-align: left;
      border-bottom: 1px solid #f3f4f6;
    }
    
    th {
      background: #f9fafb;
      font-weight: 600;
      color: #374151;
    }
    
    .order-id {
      font-family: monospace;
      font-weight: 600;
      color: #3b82f6;
    }
    
    .order-total {
      font-weight: 600;
      color: #059669;
    }
    
    .status-badge {
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 500;
    }
    
    .status-badge.pending {
      background: #fef3c7;
      color: #92400e;
    }
    
    .status-badge.processing {
      background: #dbeafe;
      color: #1e40af;
    }
    
    .status-badge.completed {
      background: #d1fae5;
      color: #065f46;
    }
    
    .status-badge.cancelled {
      background: #fee2e2;
      color: #991b1b;
    }
    
    .actions {
      display: flex;
      gap: 0.5rem;
    }
    
    .view-button, .update-button {
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .view-button {
      background: #6b7280;
      color: white;
      border: none;
    }
    
    .view-button:hover {
      background: #4b5563;
    }
    
    .update-button {
      background: #f59e0b;
      color: white;
      border: none;
    }
    
    .update-button:hover {
      background: #d97706;
    }
  `]
})
export class OrdersPageComponent implements OnInit {
  private communicationService = inject(MfeCommunicationService);
  
  ordersMfeConfig: MfeConfig = {
    name: 'orders',
    displayName: 'Orders',
    routePath: '/orders',
    remoteEntry: 'http://localhost:4203/remoteEntry.js',
    exposedModule: './OrdersModule'
  };

  orders = [
    { id: 1001, customer: 'Alice Johnson', date: new Date('2024-01-15'), status: 'completed', total: 299.99 },
    { id: 1002, customer: 'Bob Smith', date: new Date('2024-01-16'), status: 'processing', total: 159.50 },
    { id: 1003, customer: 'Carol Davis', date: new Date('2024-01-17'), status: 'pending', total: 89.99 },
    { id: 1004, customer: 'David Wilson', date: new Date('2024-01-18'), status: 'cancelled', total: 199.99 },
  ];

  filteredOrders = [...this.orders];

  ngOnInit(): void {
    // Listen for messages from other MFEs
    this.communicationService.onMessage().subscribe(message => {
      console.log('Orders received message:', message);
      
      if (message.type === 'PRODUCT_ADDED' || message.type === 'PRODUCT_DELETED') {
        console.log('Product changes detected, may need to update orders');
      }
    });
  }

  filterOrders(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const status = target.value;
    
    if (status) {
      this.filteredOrders = this.orders.filter(order => order.status === status);
    } else {
      this.filteredOrders = [...this.orders];
    }
    
    this.communicationService.broadcastNotification(`Filtered orders by: ${status || 'all'}`, 'info');
  }

  createOrder(): void {
    const newOrder = {
      id: Math.max(...this.orders.map(o => o.id)) + 1,
      customer: 'New Customer',
      date: new Date(),
      status: 'pending',
      total: 99.99
    };
    
    this.orders.unshift(newOrder);
    this.filteredOrders = [...this.orders];
    
    this.communicationService.broadcastNotification('New order created!', 'success');
    this.communicationService.sendMessage('ORDER_CREATED', {
      orderId: newOrder.id,
      customer: newOrder.customer,
      total: newOrder.total,
      timestamp: Date.now()
    }, 'orders');
  }

  viewOrder(order: any): void {
    console.log('Viewing order:', order);
    this.communicationService.broadcastNotification(`Viewing order #${order.id}`, 'info');
  }

  updateStatus(order: any): void {
    const statuses = ['pending', 'processing', 'completed', 'cancelled'];
    const currentIndex = statuses.indexOf(order.status);
    const nextIndex = (currentIndex + 1) % statuses.length;
    const newStatus = statuses[nextIndex];
    
    order.status = newStatus;
    
    this.communicationService.broadcastNotification(
      `Order #${order.id} status updated to ${newStatus}`, 
      'success'
    );
    
    this.communicationService.sendMessage('ORDER_STATUS_UPDATED', {
      orderId: order.id,
      oldStatus: statuses[currentIndex],
      newStatus: newStatus,
      timestamp: Date.now()
    }, 'orders');
  }
}
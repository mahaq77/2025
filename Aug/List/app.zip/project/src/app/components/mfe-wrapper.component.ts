import { Component, Input, OnInit, OnDestroy, ViewChild, ViewContainerRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { MfeConfig } from '../../shared/models/communication.types';
import { AppStore } from '../../shared/store/app.store';

@Component({
  selector: 'app-mfe-wrapper',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="mfe-wrapper" [class.loading]="isLoading">
      <div *ngIf="isLoading" class="loading-indicator">
        <div class="spinner"></div>
        <p>Loading {{ mfeConfig?.displayName }}...</p>
      </div>
      
      <div *ngIf="error" class="error-container">
        <h3>Failed to load {{ mfeConfig?.displayName }}</h3>
        <p>{{ error }}</p>
        <button (click)="retryLoad()" class="retry-button">Retry</button>
      </div>
      
      <div #mfeContainer class="mfe-content" [style.display]="isLoading || error ? 'none' : 'block'"></div>
    </div>
  `,
  styles: [`
    .mfe-wrapper {
      width: 100%;
      min-height: 400px;
      position: relative;
    }
    
    .loading-indicator {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 300px;
      color: #6b7280;
    }
    
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #f3f4f6;
      border-top: 4px solid #3b82f6;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 1rem;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    .error-container {
      text-align: center;
      padding: 2rem;
      color: #dc2626;
    }
    
    .retry-button {
      background: #3b82f6;
      color: white;
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      cursor: pointer;
      margin-top: 1rem;
    }
    
    .retry-button:hover {
      background: #2563eb;
    }
    
    .mfe-content {
      width: 100%;
    }
  `]
})
export class MfeWrapperComponent implements OnInit, OnDestroy {
  @Input() mfeConfig!: MfeConfig;
  @ViewChild('mfeContainer', { read: ViewContainerRef }) mfeContainer!: ViewContainerRef;
  
  private appStore = inject(AppStore);
  
  isLoading = true;
  error: string | null = null;

  ngOnInit(): void {
    this.loadMfe();
  }

  ngOnDestroy(): void {
    // Cleanup if needed
  }

  async loadMfe(): Promise<void> {
    if (!this.mfeConfig) {
      this.error = 'MFE configuration is missing';
      this.isLoading = false;
      return;
    }

    try {
      this.isLoading = true;
      this.error = null;

      // Load the remote module
      const module = await loadRemoteModule({
        remoteEntry: this.mfeConfig.remoteEntry,
        exposedModule: this.mfeConfig.exposedModule
      });

      // Create component instance
      const componentRef = this.mfeContainer.createComponent(module.default || module);
      
      // Pass shared state to MFE if component supports it
      if (componentRef.instance && 'setSharedState' in componentRef.instance) {
        (componentRef.instance as any).setSharedState({
          user: this.appStore.currentUser(),
          theme: this.appStore.theme(),
          notifications: this.appStore.notifications()
        });
      }

      this.isLoading = false;
    } catch (err) {
      console.error('Failed to load MFE:', err);
      this.error = `Failed to load microfrontend: ${err}`;
      this.isLoading = false;
    }
  }

  retryLoad(): void {
    this.loadMfe();
  }
}
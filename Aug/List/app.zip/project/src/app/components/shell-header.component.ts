import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AppStore } from '../../shared/store/app.store';
import { MfeCommunicationService } from '../../shared/services/mfe-communication.service';

@Component({
  selector: 'app-shell-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header [class]="'shell-header ' + (appStore.theme() === 'dark' ? 'dark' : 'light')">
      <div class="header-content">
        <div class="logo-section">
          <h1 class="logo">MicroFrontend Shell</h1>
        </div>
        
        <nav class="navigation">
          <button 
            *ngFor="let mfe of mfeRoutes" 
            class="nav-button"
            [class.active]="isActiveRoute(mfe.routePath)"
            (click)="navigateToMfe(mfe.routePath)">
            {{ mfe.displayName }}
          </button>
        </nav>
        
        <div class="user-section">
          <div class="notifications" *ngIf="appStore.unreadNotifications().length > 0">
            <button class="notification-button" (click)="showNotifications()">
              🔔 {{ appStore.unreadNotifications().length }}
            </button>
          </div>
          
          <button class="theme-toggle" (click)="toggleTheme()">
            {{ appStore.theme() === 'light' ? '🌙' : '☀️' }}
          </button>
          
          <div class="user-info" *ngIf="appStore.isAuthenticated()">
            <span>{{ appStore.currentUser()?.name }}</span>
            <button class="logout-button" (click)="logout()">Logout</button>
          </div>
          
          <button *ngIf="!appStore.isAuthenticated()" class="login-button" (click)="login()">
            Login
          </button>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .shell-header {
      background: var(--header-bg);
      border-bottom: 1px solid var(--border-color);
      padding: 0 2rem;
      height: 60px;
      display: flex;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 1000;
      transition: all 0.3s ease;
    }
    
    .shell-header.light {
      --header-bg: #ffffff;
      --border-color: #e5e7eb;
      --text-color: #1f2937;
      --button-bg: #f3f4f6;
      --button-hover: #e5e7eb;
    }
    
    .shell-header.dark {
      --header-bg: #1f2937;
      --border-color: #374151;
      --text-color: #f9fafb;
      --button-bg: #374151;
      --button-hover: #4b5563;
    }
    
    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }
    
    .logo {
      color: var(--text-color);
      font-size: 1.5rem;
      font-weight: 700;
      margin: 0;
    }
    
    .navigation {
      display: flex;
      gap: 1rem;
    }
    
    .nav-button {
      background: var(--button-bg);
      color: var(--text-color);
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s ease;
      font-weight: 500;
    }
    
    .nav-button:hover, .nav-button.active {
      background: var(--button-hover);
      transform: translateY(-1px);
    }
    
    .user-section {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    
    .notification-button, .theme-toggle, .login-button, .logout-button {
      background: var(--button-bg);
      color: var(--text-color);
      border: none;
      padding: 0.5rem;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .notification-button:hover, .theme-toggle:hover, 
    .login-button:hover, .logout-button:hover {
      background: var(--button-hover);
      transform: translateY(-1px);
    }
    
    .user-info {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: var(--text-color);
    }
    
    @media (max-width: 768px) {
      .shell-header {
        padding: 0 1rem;
      }
      
      .navigation {
        display: none;
      }
    }
  `]
})
export class ShellHeaderComponent {
  appStore = inject(AppStore);
  private router = inject(Router);
  private communicationService = inject(MfeCommunicationService);
  
  mfeRoutes = [
    { displayName: 'Dashboard', routePath: '/dashboard' },
    { displayName: 'Products', routePath: '/products' },
    { displayName: 'Orders', routePath: '/orders' }
  ];

  isActiveRoute(route: string): boolean {
    return this.router.url.startsWith(route);
  }

  navigateToMfe(route: string): void {
    this.router.navigate([route]);
  }

  toggleTheme(): void {
    this.appStore.toggleTheme();
    this.communicationService.broadcastThemeChange(this.appStore.theme());
  }

  showNotifications(): void {
    // Toggle notifications panel or navigate to notifications
    console.log('Show notifications:', this.appStore.unreadNotifications());
  }

  login(): void {
    // Simulate login
    const mockUser = {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      role: 'admin',
      isAuthenticated: true
    };
    
    this.appStore.setUser(mockUser);
    this.communicationService.broadcastUserUpdate(mockUser);
    this.communicationService.broadcastNotification('Welcome back!', 'success');
  }

  logout(): void {
    this.appStore.setUser(null);
    this.communicationService.broadcastUserUpdate(null);
    this.communicationService.broadcastNotification('You have been logged out', 'info');
  }
}
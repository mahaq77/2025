import { computed, inject } from '@angular/core';
import { signalStore, withState, withMethods, withComputed } from '@ngrx/signals';
import { rxMethod } from '@ngrx/signals/rxjs-interop';
import { pipe, tap, switchMap, catchError, of } from 'rxjs';
import { AppState, UserState, Notification, MfeMessage } from '../models/communication.types';

const initialState: AppState = {
  currentUser: null,
  notifications: [],
  theme: 'light',
  loading: false
};

export const AppStore = signalStore(
  { providedIn: 'root' },
  withState(initialState),
  withComputed((store) => ({
    isAuthenticated: computed(() => !!store.currentUser()?.isAuthenticated),
    unreadNotifications: computed(() => 
      store.notifications().filter(n => !n.read)
    ),
    userRole: computed(() => store.currentUser()?.role || 'guest')
  })),
  withMethods((store) => ({
    // User methods
    setUser: (user: UserState | null) => {
      store.update(state => ({ ...state, currentUser: user }));
    },
    
    updateUserProfile: (updates: Partial<UserState>) => {
      const currentUser = store.currentUser();
      if (currentUser) {
        store.update(state => ({
          ...state,
          currentUser: { ...currentUser, ...updates }
        }));
      }
    },
    
    // Notification methods
    addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => {
      const newNotification: Notification = {
        ...notification,
        id: crypto.randomUUID(),
        timestamp: Date.now()
      };
      
      store.update(state => ({
        ...state,
        notifications: [...state.notifications, newNotification]
      }));
    },
    
    markNotificationAsRead: (id: string) => {
      store.update(state => ({
        ...state,
        notifications: state.notifications.map(n =>
          n.id === id ? { ...n, read: true } : n
        )
      }));
    },
    
    removeNotification: (id: string) => {
      store.update(state => ({
        ...state,
        notifications: state.notifications.filter(n => n.id !== id)
      }));
    },
    
    // Theme methods
    toggleTheme: () => {
      store.update(state => ({
        ...state,
        theme: state.theme === 'light' ? 'dark' : 'light'
      }));
    },
    
    setTheme: (theme: 'light' | 'dark') => {
      store.update(state => ({ ...state, theme }));
    },
    
    // Loading methods
    setLoading: (loading: boolean) => {
      store.update(state => ({ ...state, loading }));
    },
    
    // Communication methods
    broadcastMessage: rxMethod<MfeMessage>(
      pipe(
        tap(message => {
          // Broadcast to all MFEs via custom events
          window.dispatchEvent(new CustomEvent('mfe-message', {
            detail: message
          }));
          console.log('Broadcasting message:', message);
        }),
        catchError(error => {
          console.error('Error broadcasting message:', error);
          return of(null);
        })
      )
    )
  }))
);
import { Injectable, inject } from '@angular/core';
import { Subject, Observable, fromEvent, filter, map } from 'rxjs';
import { AppStore } from '../store/app.store';
import { MfeMessage } from '../models/communication.types';

@Injectable({
  providedIn: 'root'
})
export class MfeCommunicationService {
  private appStore = inject(AppStore);
  private messageSubject = new Subject<MfeMessage>();
  
  constructor() {
    this.setupMessageListener();
  }

  private setupMessageListener(): void {
    // Listen for custom events from other MFEs
    fromEvent<CustomEvent<MfeMessage>>(window, 'mfe-message')
      .pipe(
        map(event => event.detail),
        filter(message => !!message)
      )
      .subscribe(message => {
        this.messageSubject.next(message);
        this.handleIncomingMessage(message);
      });
  }

  private handleIncomingMessage(message: MfeMessage): void {
    switch (message.type) {
      case 'USER_UPDATED':
        this.appStore.setUser(message.payload);
        break;
      case 'NOTIFICATION':
        this.appStore.addNotification({
          type: message.payload.type || 'info',
          message: message.payload.message,
          read: false
        });
        break;
      case 'THEME_CHANGED':
        this.appStore.setTheme(message.payload.theme);
        break;
      default:
        console.log('Unhandled message type:', message.type);
    }
  }

  // Send message to all MFEs
  sendMessage(type: string, payload: any, source: string = 'shell'): void {
    const message: MfeMessage = {
      type,
      payload,
      source,
      timestamp: Date.now()
    };

    this.appStore.broadcastMessage(message);
  }

  // Listen for specific message types
  onMessage(messageType?: string): Observable<MfeMessage> {
    if (messageType) {
      return this.messageSubject.asObservable().pipe(
        filter(message => message.type === messageType)
      );
    }
    return this.messageSubject.asObservable();
  }

  // Send user update to all MFEs
  broadcastUserUpdate(user: any): void {
    this.sendMessage('USER_UPDATED', user, 'shell');
  }

  // Send notification to all MFEs
  broadcastNotification(message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info'): void {
    this.sendMessage('NOTIFICATION', { message, type }, 'shell');
  }

  // Send theme change to all MFEs
  broadcastThemeChange(theme: 'light' | 'dark'): void {
    this.sendMessage('THEME_CHANGED', { theme }, 'shell');
  }
}
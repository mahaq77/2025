export interface MfeMessage {
  type: string;
  payload: any;
  source: string;
  timestamp: number;
}

export interface UserState {
  id: string;
  name: string;
  email: string;
  role: string;
  isAuthenticated: boolean;
}

export interface AppState {
  currentUser: UserState | null;
  notifications: Notification[];
  theme: 'light' | 'dark';
  loading: boolean;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
  timestamp: number;
  read: boolean;
}

export interface MfeConfig {
  name: string;
  displayName: string;
  routePath: string;
  remoteEntry: string;
  exposedModule: string;
  icon?: string;
}
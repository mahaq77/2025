# Angular 20 Microfrontends with Native Federation

This project demonstrates a complete microfrontend architecture using Angular 20, native federation, esbuild, and SignalStore for state management and inter-MFE communication.

## Architecture Overview

### Shell Application
- **Main container** that loads and orchestrates multiple microfrontends
- **Shared state management** using @ngrx/signals SignalStore
- **Communication hub** for inter-MFE messaging
- **Common navigation** and layout components

### Microfrontends (MFEs)
- **Dashboard MFE**: User analytics and overview
- **Products MFE**: Product catalog management
- **Orders MFE**: Order processing and tracking

## Key Features

### 🚀 Native Federation
- Uses `@angular-architects/native-federation` for module federation
- No webpack configuration required
- esbuild-based builds for faster development
- Independent deployment of each MFE

### 🔄 SignalStore Communication
- Centralized state management with @ngrx/signals
- Real-time communication between shell and MFEs
- Event-driven architecture with custom events
- Type-safe message passing

### 🎨 Modern UI/UX
- Responsive design with mobile-first approach
- Dark/light theme support
- Smooth animations and micro-interactions
- Professional design system

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn
- Angular CLI 20+

### Installation
```bash
npm install
```

### Development
```bash
# Start the shell application
npm start

# The application will be available at http://localhost:4200
```

## Project Structure

```
src/
├── shared/
│   ├── models/
│   │   └── communication.types.ts    # TypeScript interfaces
│   ├── store/
│   │   └── app.store.ts              # SignalStore implementation
│   └── services/
│       └── mfe-communication.service.ts # Inter-MFE communication
├── app/
│   ├── components/
│   │   ├── shell-header.component.ts  # Main navigation
│   │   └── mfe-wrapper.component.ts   # MFE loader component
│   └── pages/
│       ├── dashboard-page.component.ts # Dashboard page
│       ├── products-page.component.ts  # Products page
│       └── orders-page.component.ts    # Orders page
└── main.ts                            # Application bootstrap
```

## Communication Patterns

### 1. Shell to MFE Communication
```typescript
// Send message from shell to all MFEs
this.communicationService.sendMessage('USER_UPDATED', userData, 'shell');
```

### 2. MFE to Shell Communication
```typescript
// Listen for messages in MFE
this.communicationService.onMessage('DASHBOARD_DATA_UPDATED').subscribe(message => {
  console.log('Received update:', message.payload);
});
```

### 3. MFE to MFE Communication
```typescript
// Broadcast from one MFE to others
this.communicationService.sendMessage('PRODUCT_ADDED', productData, 'products');
```

## State Management

### SignalStore Features
- **Reactive state**: Automatic UI updates when state changes
- **Computed values**: Derived state with automatic recalculation
- **Type safety**: Full TypeScript support
- **Performance**: Optimized change detection

### State Structure
```typescript
interface AppState {
  currentUser: UserState | null;
  notifications: Notification[];
  theme: 'light' | 'dark';
  loading: boolean;
}
```

## Adding New MFEs

### 1. Create MFE Configuration
```typescript
const newMfeConfig: MfeConfig = {
  name: 'reports',
  displayName: 'Reports',
  routePath: '/reports',
  remoteEntry: 'http://localhost:4204/remoteEntry.js',
  exposedModule: './ReportsModule'
};
```

### 2. Add Route
```typescript
// In main.ts
{ path: 'reports', component: ReportsPageComponent }
```

### 3. Implement Communication
```typescript
// Listen for messages
this.communicationService.onMessage().subscribe(message => {
  // Handle incoming messages
});

// Send messages
this.communicationService.sendMessage('REPORT_GENERATED', data, 'reports');
```

## Development Guidelines

### Code Organization
- Keep components under 300 lines
- Separate concerns with dedicated services
- Use TypeScript interfaces for type safety
- Follow Angular 20 standalone component patterns

### Communication Best Practices
- Use descriptive message types
- Include timestamps in messages
- Handle errors gracefully
- Log important communications for debugging

### Performance Considerations
- Lazy load MFEs only when needed
- Use OnPush change detection where possible
- Implement proper cleanup in OnDestroy
- Monitor bundle sizes

## Deployment

### Production Build
```bash
npm run build
```

### MFE Deployment Strategy
1. Deploy each MFE independently
2. Update remote entry URLs in production
3. Use versioning for breaking changes
4. Implement feature flags for gradual rollouts

## Troubleshooting

### Common Issues
1. **Module loading errors**: Check remote entry URLs
2. **Communication failures**: Verify message types and payloads
3. **State inconsistencies**: Ensure proper SignalStore updates
4. **Build failures**: Verify federation configuration

### Debugging
- Use browser dev tools to inspect custom events
- Check console for communication logs
- Use Angular DevTools for state inspection
- Monitor network requests for MFE loading

## Contributing

1. Follow the existing code structure
2. Add proper TypeScript types
3. Include error handling
4. Update documentation for new features
5. Test communication patterns thoroughly

## License

MIT License - see LICENSE file for details
/**
 * Never use require or synchronous functions for production code
 *
 * Since this code is run only as a build step, and does not require
 * high performance, I am using synchronous code in this instance.
 *
 * Do not use the below code in a production environment.
 */

const shell = require("shelljs");
shell.config.fatal = true;

shell.exec(
  `npx sass src/index.scss dist/common-style-lib/common-style-lib-original.css`
);

const filename = "dist/common-style-lib/common-style-lib-original.css";
const newtext = new Date().toString();
const fs = require("fs");
fs.appendFile(filename, newtext, function (err) {
  if (err) throw err;
  console.log("Saved!");
});

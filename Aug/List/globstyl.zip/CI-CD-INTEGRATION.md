# CI/CD Integration Guide

## 🚀 **No Changes Required for CI/CD Pipeline**

Your existing CI/CD pipeline will continue to work without any modifications. The build output path remains the same:

```
dist/common-style-lib/common-style-lib.css
```

## 📋 **What Changed**

### Build Command Behavior
- **Before**: `npm run build` compiled `src/index.scss` → `dist/common-style-lib/common-style-lib.css`
- **After**: `npm run build` compiles `src/index-optimized.scss` → `dist/common-style-lib/common-style-lib.css`

### New Features in Build Output
The same file path now includes:
- ✅ **Angular Material 20 compatibility**
- ✅ **Dynamic theming** (light/dark mode support)
- ✅ **Enhanced accessibility** features
- ✅ **Comprehensive utility classes**
- ✅ **Performance optimizations**
- ✅ **All legacy styles preserved** (100% backward compatible)

## 🔧 **Available Build Commands**

```bash
# Main build (recommended) - outputs to dist/common-style-lib/common-style-lib.css
npm run build

# Alternative builds (for testing/comparison)
npm run build:legacy      # Legacy version → dist/common-style-lib/common-style-lib-legacy.css
npm run build:original    # Original script → dist/common-style-lib/common-style-lib-original.css

# Development
npm run watch            # Watch mode for development
npm run lint:scss        # Code quality checks
```

## 📊 **Build Output Comparison**

| Build Type | Output File | Size (approx) | Features |
|------------|-------------|---------------|----------|
| **Main** (recommended) | `common-style-lib.css` | ~45KB gzipped | All new features + legacy compatibility |
| Legacy | `common-style-lib-legacy.css` | ~78KB gzipped | Original styles only |
| Original | `common-style-lib-original.css` | ~78KB gzipped | Original build script (with timestamp) |

## ✅ **CI/CD Checklist**

- [ ] **No pipeline changes needed** - same build command (`npm run build`)
- [ ] **Same output path** - `dist/common-style-lib/common-style-lib.css`
- [ ] **Backward compatible** - existing applications will work unchanged
- [ ] **Enhanced features** - new capabilities available for future use
- [ ] **Performance improved** - smaller bundle size with more features

## 🧪 **Testing Recommendations**

### Automated Testing
```bash
# In your CI/CD pipeline
npm install
npm run build
npm run lint:scss

# Verify output file exists
test -f dist/common-style-lib/common-style-lib.css
```

### Manual Testing (Optional)
1. **Visual regression testing** - Compare before/after in your applications
2. **Theme switching** - Test light/dark mode if implementing
3. **Accessibility testing** - Verify enhanced a11y features
4. **Performance testing** - Measure bundle size improvements

## 🔄 **Rollback Plan**

If any issues arise, you can easily rollback:

```bash
# Use legacy build temporarily
npm run build:legacy
# Then copy common-style-lib-legacy.css to common-style-lib.css
```

Or revert to original build script:
```bash
npm run build:original
# Then copy common-style-lib-original.css to common-style-lib.css
```

## 📞 **Support**

- **Documentation**: See `README.md` for full feature documentation
- **Migration Guide**: See `MIGRATION-GUIDE.md` for application updates
- **Angular Material Setup**: See `ANGULAR-MATERIAL-SETUP.md` for advanced features

## 🎯 **Key Benefits for CI/CD**

1. **Zero Disruption**: No pipeline changes required
2. **Improved Performance**: Smaller, optimized CSS output
3. **Future Ready**: Angular Material 20 compatibility built-in
4. **Maintainable**: Better organized, documented codebase
5. **Flexible**: Multiple build options for different needs

---

**Your CI/CD pipeline will continue to work seamlessly while delivering enhanced styles to your applications! 🚀**
# Angular Material 20 Integration Setup

This guide explains how to enable full Angular Material 20 integration after installing the required dependencies.

## 🚀 Quick Setup

### 1. Install Angular Material Dependencies

```bash
npm install @angular/material @angular/cdk @angular/core
```

### 2. Enable Angular Material Integration

Once Angular Material is installed, uncomment the following lines in these files:

#### `src/themes/light-theme.scss`
```scss
// Change this:
// @use '@angular/material' as mat; // Uncomment when Angular Material is available

// To this:
@use '@angular/material' as mat;
```

```scss
// Change this:
// $light-theme: mat.define-theme((
//   color: (
//     theme-type: light,
//     primary: mat.$azure-palette,
//     tertiary: mat.$blue-palette,
//     use-system-variables: true,
//   ),
//   typography: (
//     brand-family: 'Whitney, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
//     plain-family: 'Whitney Light, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
//     bold-weight: 600,
//     medium-weight: 500,
//     regular-weight: 400,
//     use-system-variables: true,
//   ),
//   density: (
//     scale: 0,
//   )
// ));

// To this:
$light-theme: mat.define-theme((
  color: (
    theme-type: light,
    primary: mat.$azure-palette,
    tertiary: mat.$blue-palette,
    use-system-variables: true,
  ),
  typography: (
    brand-family: 'Whitney, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    plain-family: 'Whitney Light, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    bold-weight: 600,
    medium-weight: 500,
    regular-weight: 400,
    use-system-variables: true,
  ),
  density: (
    scale: 0,
  )
));
```

```scss
// Change this:
@mixin light-theme {
  // @include mat.all-component-themes($light-theme); // Uncomment when Angular Material is available

// To this:
@mixin light-theme {
  @include mat.all-component-themes($light-theme);
```

#### `src/themes/dark-theme.scss`
Make the same changes as above, but for the dark theme:

```scss
@use '@angular/material' as mat;

$dark-theme: mat.define-theme((
  color: (
    theme-type: dark,
    primary: mat.$azure-palette,
    tertiary: mat.$blue-palette,
    use-system-variables: true,
  ),
  typography: (
    brand-family: 'Whitney, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    plain-family: 'Whitney Light, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    bold-weight: 600,
    medium-weight: 500,
    regular-weight: 400,
    use-system-variables: true,
  ),
  density: (
    scale: 0,
  )
));

@mixin dark-theme {
  @include mat.all-component-themes($dark-theme);
  // ... rest of the mixin
}
```

#### `src/material/_index.scss`
```scss
// Change this:
// @use '@angular/material' as mat; // Uncomment when Angular Material is available

// To this:
@use '@angular/material' as mat;
```

### 3. Rebuild the Styles

After making these changes, rebuild the optimized styles:

```bash
npm run build:optimized
```

## 🎨 What This Enables

Once Angular Material is integrated, you'll get:

- **Full Material Design 3 theming** with automatic color generation
- **Typography system integration** with Material's type scale
- **Component theme inheritance** - all Material components automatically use your theme
- **System variable support** for dynamic theming
- **Density configuration** for compact/comfortable layouts

## 🔧 Advanced Configuration

### Custom Color Palettes

You can define custom palettes by modifying the theme configuration:

```scss
// Define custom palette
$custom-primary: mat.define-palette(mat.$indigo-palette);
$custom-accent: mat.define-palette(mat.$pink-palette, A200, A100, A400);

// Use in theme
$light-theme: mat.define-theme((
  color: (
    theme-type: light,
    primary: $custom-primary,
    tertiary: $custom-accent,
    use-system-variables: true,
  ),
  // ... rest of config
));
```

### Typography Customization

```scss
$custom-typography: mat.define-typography-config(
  $font-family: 'Whitney, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  $headline-1: mat.define-typography-level(2rem, 2.5rem, 300),
  $headline-2: mat.define-typography-level(1.75rem, 2.25rem, 400),
  // ... other levels
);

$light-theme: mat.define-theme((
  typography: $custom-typography,
  // ... rest of config
));
```

### Density Configuration

```scss
$light-theme: mat.define-theme((
  density: (
    scale: -1, // More compact
  ),
  // ... rest of config
));
```

## 🧪 Testing the Integration

After enabling Angular Material integration:

1. **Build the styles**: `npm run build:optimized`
2. **Check for errors**: Ensure no compilation errors
3. **Test in your app**: Import the built CSS and verify Material components are themed correctly
4. **Test theme switching**: Verify light/dark theme switching works with Material components

## 📚 Additional Resources

- [Angular Material Theming Guide](https://material.angular.io/guide/theming)
- [Material Design 3 Color System](https://m3.material.io/styles/color/system/overview)
- [Angular Material Typography](https://material.angular.io/guide/typography)

## ⚠️ Important Notes

- **Version Compatibility**: Ensure your Angular Material version supports the `define-theme` API (v15+)
- **Build Performance**: Full Material integration may increase build time
- **Bundle Size**: Consider using only the Material components you need to optimize bundle size
- **Custom Properties**: The integration works best with `use-system-variables: true`

---

**Ready to use Angular Material 20 with your optimized theme system! 🎉**
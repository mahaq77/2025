# Migration Guide: Angular Material 20 Style Library

This guide helps you migrate from the legacy style system to the new Angular Material 20 optimized structure.

## 🚀 What's New

### 1. **Modern Theme System**
- CSS Custom Properties for dynamic theming
- Light/Dark theme support with automatic switching
- System preference detection
- Improved accessibility and contrast support

### 2. **Angular Material 20 Compatibility**
- Full support for Material Design 3
- Updated component overrides using new MDC-based components
- Enhanced typography system
- Improved focus management and accessibility

### 3. **Organized File Structure**
```
src/
├── themes/           # Theme configuration
│   ├── _variables.scss
│   ├── _mixins.scss
│   ├── light-theme.scss
│   └── dark-theme.scss
├── material/         # Angular Material overrides
│   ├── _mat-button.scss
│   ├── _mat-form-field.scss
│   ├── _mat-card.scss
│   ├── _mat-table.scss
│   ├── _mat-dialog.scss
│   └── _index.scss
├── core/            # Core utilities and base styles
│   ├── _utilities.scss
│   └── _index.scss
└── index-optimized.scss  # New main entry point
```

### 4. **Enhanced Utility System**
- Comprehensive utility classes
- Responsive design utilities
- Flexbox and grid utilities
- Spacing and typography utilities

## 📋 Migration Steps

### Step 1: Update Dependencies

```json
{
  "dependencies": {
    "@angular/material": "^20.0.0",
    "@angular/cdk": "^20.0.0",
    "@angular/core": "^20.0.0"
  }
}
```

### Step 2: Update Import Statement

**Before:**
```scss
@import '~common-style-lib/src/index.scss';
```

**After:**
```scss
@import '~common-style-lib/src/index-optimized.scss';
```

### Step 3: Update Angular Material Imports

**Before:**
```typescript
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
```

**After:**
```typescript
// Same imports, but components now use MDC-based implementations
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
```

### Step 4: Update Component Templates

#### Buttons
**Before:**
```html
<button mat-button class="mytest-btn mytest-btn-primary">Primary</button>
<button mat-button class="mytest-btn mytest-btn-secondary">Secondary</button>
```

**After (Recommended):**
```html
<button mat-raised-button color="primary">Primary</button>
<button mat-outlined-button color="primary">Secondary</button>
```

**Legacy Support (Still Works):**
```html
<button mat-raised-button class="mytest-btn mytest-btn-primary">Primary</button>
```

#### Form Fields
**Before:**
```html
<mat-form-field class="mytest-input-txt-fields" appearance="fill">
  <mat-label class="mytest-label-txt">Label</mat-label>
  <input matInput class="mytest-input-txt">
</mat-form-field>
```

**After (Recommended):**
```html
<mat-form-field appearance="outline">
  <mat-label>Label</mat-label>
  <input matInput>
</mat-form-field>
```

#### Cards
**Before:**
```html
<mat-card class="mytest-card">
  <div class="mytest-card--header">
    <h2>Title</h2>
  </div>
  <div class="mytest-card--body">
    Content
  </div>
</mat-card>
```

**After (Recommended):**
```html
<mat-card>
  <mat-card-header>
    <mat-card-title>Title</mat-card-title>
  </mat-card-header>
  <mat-card-content>
    Content
  </mat-card-content>
</mat-card>
```

### Step 5: Implement Theme Switching

Add theme switching capability:

```typescript
// theme.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private currentTheme: 'light' | 'dark' = 'light';

  toggleTheme(): void {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', this.currentTheme);
  }

  setTheme(theme: 'light' | 'dark'): void {
    this.currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
  }

  getCurrentTheme(): 'light' | 'dark' {
    return this.currentTheme;
  }
}
```

```html
<!-- theme-toggle.component.html -->
<button mat-icon-button (click)="toggleTheme()" class="theme-toggle">
  <mat-icon>{{ isDark ? 'light_mode' : 'dark_mode' }}</mat-icon>
</button>
```

### Step 6: Update Custom Styles

#### Using CSS Custom Properties
**Before:**
```scss
.my-component {
  color: #2e2e2e;
  background-color: #ffffff;
  border: 1px solid #e4e4e6;
}
```

**After:**
```scss
.my-component {
  color: var(--text-primary);
  background-color: var(--bg-primary);
  border: 1px solid var(--border-primary);
}
```

#### Using Utility Classes
**Before:**
```scss
.my-component {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 1rem;
  margin-bottom: 1rem;
}
```

**After:**
```html
<div class="d-flex justify-content-center align-items-center p-4 mb-4">
  <!-- content -->
</div>
```

### Step 6: Update Build Process

The main build command now outputs the optimized version to the same path your CI/CD expects:

```bash
# Build optimized CSS (outputs to dist/common-style-lib/common-style-lib.css)
npm run build

# Your CI/CD pipeline can continue using the same path:
# dist/common-style-lib/common-style-lib.css
```

**Available Build Commands:**
- `npm run build` - Optimized build (recommended)
- `npm run build:legacy` - Legacy build without new features
- `npm run build:original` - Original build script (for comparison)

## 🎨 Theme Customization

### Custom Color Palette
```scss
// Override theme variables
:root {
  --brand-cyan: #your-primary-color;
  --brand-cyan-hover: #your-primary-hover-color;
  --text-primary: #your-text-color;
}
```

### Custom Component Styling
```scss
// Use mixins for consistent styling
.my-custom-button {
  @include button-variant(
    var(--brand-cyan),
    var(--text-on-primary),
    var(--brand-cyan-hover)
  );
  @include border-radius(lg);
  @include elevation(2);
}
```

## 🔧 Utility Classes Reference

### Display
- `.d-none`, `.d-block`, `.d-flex`, `.d-grid`
- Responsive: `.d-md-block`, `.d-lg-flex`

### Flexbox
- `.justify-content-center`, `.align-items-center`
- `.flex-column`, `.flex-wrap`

### Spacing
- Margin: `.m-0` to `.m-24`, `.mx-auto`, `.my-4`
- Padding: `.p-0` to `.p-24`, `.px-4`, `.py-2`

### Typography
- Sizes: `.text-xs` to `.text-6xl`
- Weights: `.fw-light` to `.fw-bold`
- Alignment: `.text-left`, `.text-center`, `.text-right`

### Colors
- Text: `.text-primary`, `.text-secondary`, `.text-error`
- Background: `.bg-primary`, `.bg-secondary`, `.bg-success`

## ⚠️ Breaking Changes

### 1. Material Component Classes
- `mat-button` → `mat-mdc-button`
- `mat-form-field` → `mat-mdc-form-field`
- `mat-card` → `mat-mdc-card`

### 2. CSS Custom Properties
- Some hardcoded colors may need updating to use CSS custom properties
- Check for any `!important` declarations that might override theme colors

### 3. Typography
- Font weights may appear different due to updated typography scale
- Line heights have been standardized

## 🧪 Testing Your Migration

### 1. Visual Regression Testing
- Compare components before and after migration
- Test both light and dark themes
- Verify responsive behavior

### 2. Accessibility Testing
- Test keyboard navigation
- Verify focus indicators
- Check color contrast ratios

### 3. Performance Testing
- Measure bundle size impact
- Test loading performance
- Verify critical CSS loading

## 📚 Additional Resources

- [Angular Material 20 Documentation](https://material.angular.io)
- [Material Design 3 Guidelines](https://m3.material.io)
- [CSS Custom Properties Guide](https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties)

## 🆘 Troubleshooting

### Common Issues

1. **Styles not applying**: Ensure you're importing `index-optimized.scss`
2. **Theme not switching**: Check that `data-theme` attribute is being set
3. **Legacy classes not working**: Verify legacy compatibility layer is included
4. **Performance issues**: Consider lazy-loading non-critical styles

### Getting Help

- Check the component documentation in each SCSS file
- Review the utility classes in `core/_utilities.scss`
- Examine theme variables in `themes/_variables.scss`

---

**Happy migrating! 🎉**

The new system provides better performance, accessibility, and maintainability while preserving backward compatibility with your existing code.
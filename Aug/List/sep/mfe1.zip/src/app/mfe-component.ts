import { Component } from '@angular/core';

@Component({
  selector: 'mfe1-component',
  standalone: true,
  template: `
    <div class="mfe1-container">
      <h2>MFE1 Component</h2>
      <p>This is content from MFE1 running on port 4207</p>
      <div class="mfe1-content">
        <div class="pill-group">
          <div class="pill">
            MFE1 Feature 1
          </div>
          <div class="pill">
            MFE1 Feature 2
          </div>
          <div class="pill">
            MFE1 Feature 3
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .mfe1-container {
      padding: 20px;
      border: 2px solid #7702FF;
      border-radius: 8px;
      margin: 10px;
      background: linear-gradient(135deg, #f0f0f0 0%, #e8e8e8 100%);
    }
    
    .mfe1-container h2 {
      color: #7702FF;
      margin-bottom: 10px;
    }
    
    .mfe1-content {
      margin-top: 15px;
    }
    
    .pill-group {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    
    .pill {
      display: inline-block;
      background: color-mix(in srgb, #7702FF 10%, transparent);
      color: #7702FF;
      padding: 8px 16px;
      border-radius: 20px;
      border: 1px solid #7702FF;
      font-size: 14px;
      font-weight: 500;
      transition: all 0.3s ease;
      cursor: pointer;
    }
    
    .pill:hover {
      background: color-mix(in srgb, #7702FF 20%, transparent);
      transform: translateY(-2px);
    }
  `]
})
export class MfeComponent {
  constructor() {
    console.log('MFE1 Component loaded successfully!');
  }
}

// Also export as default for easier importing
export default MfeComponent;
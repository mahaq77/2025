import { Component } from '@angular/core';

@Component({
  selector: 'app-mfe-fallback',
  standalone: true,
  template: `
    <div class="fallback-container">
      <h2>MFE1 Loading...</h2>
      <p>The micro frontend is being loaded from <strong>http://localhost:4207</strong></p>
      <p>Please make sure the MFE1 application is running on port 4207.</p>
      <div class="loading-spinner"></div>
    </div>
  `,
  styles: [`
    .fallback-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 400px;
      text-align: center;
      padding: 2rem;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    h2 {
      color: #1976d2;
      margin-bottom: 1rem;
    }

    p {
      color: #666;
      margin-bottom: 0.5rem;
    }

    .loading-spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #1976d2;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-top: 1rem;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `]
})
export class MfeFallbackComponent {}
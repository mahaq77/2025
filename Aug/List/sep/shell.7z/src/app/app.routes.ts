import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { MfeFallbackComponent } from './mfe-fallback.component';
import { TestFederationComponent } from './test-federation.component';
import { SimpleTestComponent } from './simple-test.component';

export const routes: Routes = [
  {
    path: 'mfe1',
    loadComponent: () =>
      loadRemoteModule('mfe1', './Component')
        .then((m) => {
          console.log('Loaded remote module:', m);
          console.log('Available exports:', Object.keys(m));
          
          // Try different export names in priority order
          if (m.MfeComponent) {
            console.log('✅ Using MfeComponent export');
            return m.MfeComponent;
          } else if (m.AppComponent) {
            console.log('✅ Using AppComponent export');
            return m.AppComponent;
          } else if (m.App) {
            console.log('⚠️ Using App export (consider adding alias)');
            return m.App;
          } else if (m.default) {
            console.log('⚠️ Using default export (consider named export)');
            return m.default;
          } else {
            console.error('❌ No valid component export found');
            throw new Error(`No valid component export found. Available: ${Object.keys(m).join(', ')}`);
          }
        })
        .catch((error) => {
          console.error('Error loading remote module:', error);
          return MfeFallbackComponent;
        }),
  },
  {
    path: 'mfe1-fallback',
    component: MfeFallbackComponent
  },
  {
    path: 'test',
    component: TestFederationComponent
  },
  {
    path: 'simple',
    component: SimpleTestComponent
  },
  {
    path: '',
    redirectTo: '/mfe1',
    pathMatch: 'full'
  }
];

import { Component } from '@angular/core';

@Component({
  selector: 'app-simple-test',
  standalone: true,
  template: `
    <div style="padding: 20px; background: lightgreen; margin: 20px; border-radius: 8px;">
      <h2>✅ Simple Test Component</h2>
      <p>If you can see this, routing is working!</p>
      <p>Current time: {{ currentTime }}</p>
    </div>
  `
})
export class SimpleTestComponent {
  currentTime = new Date().toLocaleTimeString();
}
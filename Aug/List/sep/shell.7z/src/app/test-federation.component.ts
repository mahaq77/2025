import { Component } from '@angular/core';
import { JsonPipe } from '@angular/common';
import { loadRemoteModule } from '@angular-architects/native-federation';

@Component({
  selector: 'app-test-federation',
  standalone: true,
  imports: [JsonPipe],
  template: `
    <div class="test-container">
      <h2>🔍 Federation Test</h2>
      <button (click)="testRemoteLoading()" class="test-btn">Test Remote Loading</button>
      <div class="results">
        <h3>Results:</h3>
        <pre>{{ results | json }}</pre>
      </div>
    </div>
  `,
  styles: [`
    .test-container {
      padding: 20px;
      border: 2px solid #007acc;
      margin: 20px;
      border-radius: 8px;
    }
    .test-btn {
      background: #007acc;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin: 10px 0;
    }
    .test-btn:hover {
      background: #005a9e;
    }
    .results {
      margin-top: 20px;
      padding: 10px;
      background: #f5f5f5;
      border-radius: 4px;
    }
    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
    }
  `]
})
export class TestFederationComponent {
  results: any = {};

  private getRecommendation(status: string, exports: string[]): string {
    if (status === 'Success') {
      return 'Component export is correctly configured!';
    }
    
    if (exports.includes('App')) {
      return 'Add this line to MFE1: export { App as MfeComponent };';
    }
    
    if (exports.includes('default')) {
      return 'Change default export to named export: export class MfeComponent { ... }';
    }
    
    if (exports.length === 0) {
      return 'No exports found. Ensure component is properly exported.';
    }
    
    return `Available exports: ${exports.join(', ')}. Rename one to MfeComponent or add alias.`;
  }

  async testRemoteLoading() {
    console.log('🔍 Testing remote module loading...');
    this.results = { status: 'Loading...', timestamp: new Date().toISOString() };

    try {
      // Test 1: Check if remote entry is accessible
      const response = await fetch('http://localhost:4207/remoteEntry.json');
      const remoteEntry = await response.json();
      console.log('✅ Remote entry loaded:', remoteEntry);
      
      this.results.remoteEntry = {
        status: 'Success',
        name: remoteEntry.name,
        exposes: remoteEntry.exposes
      };

      // Test 2: Try to load the remote module
      const module = await loadRemoteModule('mfe1', './Component');
      console.log('✅ Remote module loaded:', module);
      console.log('Available exports:', Object.keys(module));
      
      // Check all possible exports
      const exports = Object.keys(module);
      const exportDetails: any = {};
      exports.forEach(key => {
        exportDetails[key] = {
          type: typeof module[key],
          isComponent: typeof module[key] === 'function' && module[key].prototype && module[key].prototype.constructor === module[key]
        };
      });

      this.results.moduleLoading = {
        status: 'Success',
        totalExports: exports.length,
        exports: exports,
        exportDetails: exportDetails,
        hasMfeComponent: 'MfeComponent' in module,
        hasApp: 'App' in module,
        hasAppComponent: 'AppComponent' in module,
        hasDefault: 'default' in module
      };

      // Test 3: Validate component exports
      let validComponent = null;
      let componentStatus = 'Error';
      let componentMessage = 'No valid component export found';

      // Priority order: MfeComponent > AppComponent > App > default
      if (module.MfeComponent) {
        validComponent = module.MfeComponent;
        componentStatus = 'Success';
        componentMessage = 'MfeComponent found (preferred export)';
        console.log('✅ MfeComponent found:', module.MfeComponent);
      } else if (module.AppComponent) {
        validComponent = module.AppComponent;
        componentStatus = 'Success';
        componentMessage = 'AppComponent found (valid export)';
        console.log('✅ AppComponent found:', module.AppComponent);
      } else if (module.App) {
        validComponent = module.App;
        componentStatus = 'Warning';
        componentMessage = 'App found (needs alias: export { App as MfeComponent })';
        console.log('⚠️ App component found:', module.App);
      } else if (module.default) {
        validComponent = module.default;
        componentStatus = 'Warning';
        componentMessage = 'Default export found (should be named export)';
        console.log('⚠️ Default export found:', module.default);
      }

      this.results.componentValidation = {
        status: componentStatus,
        message: componentMessage,
        componentName: validComponent?.name || 'Unknown',
        isFunction: typeof validComponent === 'function',
        hasStandalone: validComponent?.ɵcmp?.standalone === true,
        recommendation: this.getRecommendation(componentStatus, exports)
      };

    } catch (error: any) {
      console.error('❌ Error during testing:', error);
      this.results.error = {
        status: 'Error',
        message: error?.message || 'Unknown error',
        stack: error?.stack || 'No stack trace'
      };
    }
  }
}
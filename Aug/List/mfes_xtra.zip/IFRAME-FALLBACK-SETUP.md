# 🖼️ Iframe Fallback Setup for MFE3

## **Quick Integration Option**

If setting up Native Federation for your existing Angular app is complex, you can use this iframe-based approach as an immediate solution:

### **Step 1: Update Shell Routes**

Replace the current MFE3 route in `shell/src/app/app.routes.ts`:

```typescript
import { Routes } from '@angular/router';
import { HomeComponent } from './home/home';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { IframeComponent } from './iframe/iframe.component';

export const routes: Routes = [
  {
    path: 'mfe1',
    loadChildren: () => loadRemoteModule('mfe1', './Module').then(m => m.RemoteEntryModule)
  },
  {
    path: 'mfe2',
    loadChildren: () => loadRemoteModule('mfe2', './Module').then(m => m.RemoteEntryModule)
  },
  {
    path: 'mfe3',
    component: IframeComponent,
    data: { url: 'http://localhost:4207' }
  },
  {
    path: '',
    component: HomeComponent
  }
];
```

### **Step 2: Import IframeComponent**

Update `shell/src/app/app.ts` to import the IframeComponent:

```typescript
import { IframeComponent } from './iframe/iframe.component';

// Add to imports array if needed
```

### **Step 3: Test Integration**

1. **Ensure your app is running** on `http://localhost:4207`
2. **Restart shell**: `npm start`
3. **Click MFE3** in navigation
4. **Your app should load** in an iframe within the shell

### **Pros of Iframe Approach:**
✅ **No changes needed** to your existing Angular app  
✅ **Immediate integration** - works right away  
✅ **Maintains shell navigation** and layout  
✅ **Preserves existing app functionality**  

### **Cons of Iframe Approach:**
❌ **No shared state** with signal store  
❌ **Limited communication** between shell and MFE3  
❌ **Potential styling conflicts**  
❌ **Security restrictions** (CORS, etc.)  

### **When to Use:**
- Quick proof of concept
- Legacy app integration
- When Native Federation setup is not feasible
- Temporary solution while planning proper federation

### **Upgrade Path:**
Once you're ready, you can always upgrade to full Native Federation by following the main integration guide in `MFE3-INTEGRATION-GUIDE.md`.

## **Current Status with Iframe:**

✅ **Shell Ready**: All configurations complete  
✅ **Iframe Component**: Created and ready  
✅ **Route Configured**: Points to your app at port 4207  
⏳ **Testing**: Ready to test once route is updated  

Just update the route as shown above and your app will be integrated! 🚀
# 🔗 MFE3 Integration Guide

## ✅ **Shell Configuration Complete!**

I've already configured the shell to integrate your Angular app at `http://localhost:4207` as **MFE3**:

### **Shell Changes Made:**
- ✅ Added `mfe3: 'http://localhost:4207/remoteEntry.json'` to federation config
- ✅ Added `/mfe3` route in app.routes.ts
- ✅ Added "MFE3" navigation button
- ✅ Added MFE3 communication controls
- ✅ Updated route tracking to detect MFE3

## 🛠️ **Required: Configure Your Angular App (Port 4207)**

To make your existing Angular app work as MFE3, you need to add Native Federation support:

### **Step 1: Install Native Federation**
```bash
cd /path/to/your/angular/app
npm install @angular-architects/native-federation
```

### **Step 2: Add Federation Config**
Create `federation.config.js` in your app root:
```javascript
const { withNativeFederation, shareAll } = require('@angular-architects/native-federation/config');

module.exports = withNativeFederation({
  name: 'mfe3',
  
  exposes: {
    './Module': './src/app/remote-entry/entry.module.ts',
  },

  shared: {
    ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' }),
  },

  skip: [
    'rxjs/ajax',
    'rxjs/fetch', 
    'rxjs/testing',
    'rxjs/webSocket',
  ],
});
```

### **Step 3: Create Remote Entry Module**
Create `src/app/remote-entry/entry.module.ts`:
```typescript
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { App } from '../app'; // Your main component

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: App, // Your main component
      }
    ])
  ]
})
export class RemoteEntryModule {}
```

### **Step 4: Update Angular.json**
Update your `angular.json` build configuration:
```json
{
  "build": {
    "builder": "@angular-architects/native-federation:build",
    "options": {
      "target": "target",
      "rebuildDelay": 0,
      "dev": true
    }
  },
  "serve": {
    "builder": "@angular-architects/native-federation:build",
    "options": {
      "target": "target",
      "rebuildDelay": 0,
      "dev": true,
      "port": 4207
    }
  }
}
```

### **Step 5: Update Package.json Scripts**
```json
{
  "scripts": {
    "build": "ng build",
    "serve": "ng serve",
    "start": "ng serve"
  }
}
```

## 🚀 **Alternative: Quick Integration (If Federation Setup is Complex)**

If setting up Native Federation is complex for your existing app, here's a simpler approach:

### **Option A: Iframe Integration**
Update the shell route to use an iframe:
```typescript
// In shell/src/app/app.routes.ts
{
  path: 'mfe3',
  component: IframeComponent, // Create this component
  data: { url: 'http://localhost:4207' }
}
```

### **Option B: Proxy Integration**
Configure Angular CLI proxy in shell:
```json
// proxy.conf.json
{
  "/mfe3/*": {
    "target": "http://localhost:4207",
    "secure": true,
    "changeOrigin": true,
    "logLevel": "debug"
  }
}
```

## 🔧 **Signal Store Integration (Optional)**

If you want your MFE3 to participate in the signal store communication:

### **Step 1: Install Signal Store**
```bash
npm install @ngrx/signals
```

### **Step 2: Copy Federation Files**
Copy these files from the shell to your MFE3:
- `src/app/shared/store/federation.store.ts`
- `src/app/shared/services/federation.service.ts`

### **Step 3: Update Your Component**
```typescript
import { Component, inject, OnInit } from '@angular/core';
import { FederationService } from './shared/services/federation.service';
import { injectFederationStore } from './shared/store/federation.store';

@Component({
  // your component config
})
export class YourComponent implements OnInit {
  private federationService = inject(FederationService);
  private federationStore = injectFederationStore();
  
  // Access shared state
  currentUser = this.federationStore.user;
  currentTheme = this.federationStore.theme;
  sharedData = this.federationStore.sharedData;

  ngOnInit() {
    // Subscribe to messages
    this.federationService.subscribeToMessages('mfe3', (message) => {
      console.log('MFE3 received:', message);
    });

    // Send ready message
    this.federationService.sendToMfe('shell', 'mfe-ready', {
      mfe: 'mfe3',
      message: 'MFE3 is ready!'
    });
  }

  // Communication methods
  sendToShell() {
    this.federationService.sendToMfe('shell', 'mfe3-update', {
      message: 'Update from MFE3'
    });
  }
}
```

## 🧪 **Testing the Integration**

### **After Setup:**
1. **Start your MFE3**: Ensure it's running on port 4207
2. **Restart Shell**: `npm start` in shell directory
3. **Test Navigation**: Click "MFE3" button in shell
4. **Test Communication**: Use "→ MFE3" button in shell

### **Expected Behavior:**
- ✅ MFE3 button appears in shell navigation
- ✅ Clicking MFE3 loads your app in shell container
- ✅ Shell content hides when on MFE3 route
- ✅ MFE indicator shows "mfe3" when active
- ✅ Communication buttons work (if signal store added)

## 🆘 **Need Help?**

If you encounter issues:

1. **Check Console**: Look for federation loading errors
2. **Verify Port**: Ensure your app is actually running on 4207
3. **Check remoteEntry.json**: Should be accessible at `http://localhost:4207/remoteEntry.json`
4. **CORS Issues**: May need to configure CORS in your app

Let me know what type of Angular app you have and I can provide more specific guidance!

## 📋 **Current Status**

✅ **Shell Ready**: All shell configurations complete  
⏳ **MFE3 Setup**: Needs Native Federation configuration  
⏳ **Testing**: Ready once MFE3 is configured  

Your shell is now ready to integrate MFE3! 🚀
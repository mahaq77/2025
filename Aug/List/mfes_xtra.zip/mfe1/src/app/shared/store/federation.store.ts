import { patchState, signalStore, withMethods, withState } from '@ngrx/signals';
import { inject } from '@angular/core';

// Define the state interface
export interface FederationState {
  // User information
  user: {
    id: string | null;
    name: string | null;
    email: string | null;
    role: string | null;
  };
  
  // Application state
  currentMfe: string | null;
  theme: 'light' | 'dark';
  
  // Shared data between MFEs
  sharedData: Record<string, any>;
  
  // Communication messages
  messages: Array<{
    id: string;
    from: string;
    to: string;
    type: string;
    payload: any;
    timestamp: Date;
  }>;
  
  // Loading states
  loading: {
    user: boolean;
    data: boolean;
  };
  
  // Error states
  errors: {
    user: string | null;
    data: string | null;
  };
}

// Initial state
const initialState: FederationState = {
  user: {
    id: null,
    name: null,
    email: null,
    role: null,
  },
  currentMfe: null,
  theme: 'light',
  sharedData: {},
  messages: [],
  loading: {
    user: false,
    data: false,
  },
  errors: {
    user: null,
    data: null,
  },
};

// Create the signal store
export const FederationStore = signalStore(
  { providedIn: 'root' },
  withState(initialState),
  withMethods((store) => ({
    // User management methods
    setUser(user: Partial<FederationState['user']>) {
      patchState(store, (state) => ({
        user: { ...state.user, ...user },
        errors: { ...state.errors, user: null },
      }));
    },

    clearUser() {
      patchState(store, {
        user: { id: null, name: null, email: null, role: null },
      });
    },

    setUserLoading(loading: boolean) {
      patchState(store, (state) => ({
        loading: { ...state.loading, user: loading },
      }));
    },

    setUserError(error: string | null) {
      patchState(store, (state) => ({
        errors: { ...state.errors, user: error },
        loading: { ...state.loading, user: false },
      }));
    },

    // MFE navigation methods
    setCurrentMfe(mfe: string | null) {
      patchState(store, { currentMfe: mfe });
    },

    // Theme management
    setTheme(theme: 'light' | 'dark') {
      patchState(store, { theme });
      // Persist theme to localStorage
      localStorage.setItem('federation-theme', theme);
    },

    loadTheme() {
      const savedTheme = localStorage.getItem('federation-theme') as 'light' | 'dark';
      if (savedTheme) {
        patchState(store, { theme: savedTheme });
      }
    },

    // Shared data management
    setSharedData(key: string, value: any) {
      patchState(store, (state) => ({
        sharedData: { ...state.sharedData, [key]: value },
      }));
    },

    getSharedData(key: string) {
      return store.sharedData()[key];
    },

    removeSharedData(key: string) {
      patchState(store, (state) => {
        const newSharedData = { ...state.sharedData };
        delete newSharedData[key];
        return { sharedData: newSharedData };
      });
    },

    clearSharedData() {
      patchState(store, { sharedData: {} });
    },

    // Message communication between MFEs
    sendMessage(from: string, to: string, type: string, payload: any) {
      const message = {
        id: crypto.randomUUID(),
        from,
        to,
        type,
        payload,
        timestamp: new Date(),
      };
      
      patchState(store, (state) => ({
        messages: [...state.messages, message],
      }));
      
      return message.id;
    },

    getMessagesFor(recipient: string) {
      return store.messages().filter(msg => msg.to === recipient || msg.to === 'all');
    },

    markMessageAsRead(messageId: string) {
      patchState(store, (state) => ({
        messages: state.messages.filter(msg => msg.id !== messageId),
      }));
    },

    clearMessages() {
      patchState(store, { messages: [] });
    },

    // Data loading states
    setDataLoading(loading: boolean) {
      patchState(store, (state) => ({
        loading: { ...state.loading, data: loading },
      }));
    },

    setDataError(error: string | null) {
      patchState(store, (state) => ({
        errors: { ...state.errors, data: error },
        loading: { ...state.loading, data: false },
      }));
    },

    // Utility methods
    reset() {
      patchState(store, initialState);
    },

    // Advanced communication patterns
    broadcast(from: string, type: string, payload: any) {
      return this.sendMessage(from, 'all', type, payload);
    },

    // State persistence
    saveState() {
      const stateToSave = {
        user: store.user(),
        theme: store.theme(),
        sharedData: store.sharedData(),
      };
      localStorage.setItem('federation-state', JSON.stringify(stateToSave));
    },

    loadState() {
      const savedState = localStorage.getItem('federation-state');
      if (savedState) {
        try {
          const parsedState = JSON.parse(savedState);
          patchState(store, {
            user: parsedState.user || initialState.user,
            theme: parsedState.theme || initialState.theme,
            sharedData: parsedState.sharedData || initialState.sharedData,
          });
        } catch (error) {
          console.error('Failed to load saved state:', error);
        }
      }
    },
  }))
);

// Export type for injection
export type FederationStoreType = InstanceType<typeof FederationStore>;

// Helper function to inject the store
export function injectFederationStore() {
  return inject(FederationStore);
}
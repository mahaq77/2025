import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FederationService } from './shared/services/federation.service';
import { injectFederationStore } from './shared/store/federation.store';

@Component({
  selector: 'app-root',
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit, OnDestroy {
  protected title = 'mfe1';
  protected Object = Object; // For template access
  
  private federationService = inject(FederationService);
  private federationStore = injectFederationStore();
  private messageSubscription?: () => void;

  // Reactive properties
  currentUser = this.federationStore.user;
  currentTheme = this.federationStore.theme;
  sharedData = this.federationStore.sharedData;
  messages: any[] = [];
  
  // Local state
  localCounter = 0;
  receivedMessages: string[] = [];

  ngOnInit() {
    // Subscribe to messages from shell and other MFEs
    this.messageSubscription = this.federationService.subscribeToMessages('mfe1', (message) => {
      this.handleMessage(message);
    });

    // Also check for 'all' messages (broadcasts)
    this.federationService.subscribeToMessages('all', (message) => {
      this.handleMessage(message);
    });

    // Send initial greeting to shell
    this.federationService.sendToMfe('shell', 'mfe-ready', {
      mfe: 'mfe1',
      message: 'MFE1 is ready!',
      timestamp: new Date()
    });
  }

  ngOnDestroy() {
    if (this.messageSubscription) {
      this.messageSubscription();
    }
  }

  private handleMessage(message: any) {
    console.log('MFE1 received message:', message);
    this.receivedMessages.unshift(`${message.from}: ${message.type} - ${JSON.stringify(message.payload)}`);
    
    // Keep only last 10 messages
    if (this.receivedMessages.length > 10) {
      this.receivedMessages = this.receivedMessages.slice(0, 10);
    }
  }

  // Methods for template
  incrementCounter() {
    this.localCounter++;
    
    // Share the counter with other MFEs
    this.federationService.shareData('mfe1-counter', this.localCounter);
  }

  sendToShell() {
    this.federationService.sendToMfe('shell', 'mfe1-update', {
      message: 'Update from MFE1',
      counter: this.localCounter,
      timestamp: new Date()
    });
  }

  sendToMfe2() {
    this.federationService.sendToMfe('mfe2', 'mfe1-greeting', {
      message: 'Hello from MFE1!',
      counter: this.localCounter,
      timestamp: new Date()
    });
  }

  broadcastData() {
    this.federationService.broadcastToAll('mfe1-broadcast', {
      message: 'Broadcast from MFE1',
      data: { counter: this.localCounter, random: Math.random() },
      timestamp: new Date()
    });
  }

  updateUserFromMfe() {
    const newEmail = prompt('Enter new email:', this.currentUser().email || '');
    if (newEmail) {
      this.federationService.updateUser({ email: newEmail });
    }
  }

  clearMessages() {
    this.receivedMessages = [];
  }
}

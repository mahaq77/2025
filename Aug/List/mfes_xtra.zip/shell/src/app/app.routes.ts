import { Routes } from '@angular/router';
import { HomeComponent } from './home/home';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { EnhancedLoaderComponent } from './dynamic-loader/enhanced-loader.component';

export const routes: Routes = [
  {
    path: 'mfe1',
    loadChildren: () => loadRemoteModule('mfe1', './Module').then(m => m.RemoteEntryModule)
  },
  {
    path: 'mfe2',
    loadChildren: () => loadRemoteModule('mfe2', './Module').then(m => m.RemoteEntryModule)
  },
    {
    path: 'mfe3',
    component: EnhancedLoaderComponent,
    data: {
      remoteUrl: 'http://172.31.32.1:8080/'
    }
  },
/*   {
    path: 'mfe3',
    component: EnhancedLoaderComponent
  }, */
  {
    path: '',
    component: HomeComponent
  }
];

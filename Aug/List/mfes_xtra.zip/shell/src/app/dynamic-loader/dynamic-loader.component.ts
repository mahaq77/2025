import { Component, OnInit, OnDestroy, ElementRef, inject, Renderer2, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dynamic-loader',
  standalone: true,
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <div class="dynamic-app-container" style="width: 100%; height: 100vh; padding-top: 80px;">
      <div id="mfe3-container" style="width: 100%; height: calc(100vh - 80px); padding: 20px;">
        <div id="mfe3-loading" *ngIf="isLoading" style="text-align: center; padding: 50px;">
          <h2>Loading MFE3...</h2>
          <p>Please wait while we load the micro frontend.</p>
        </div>
        <div id="mfe3-content" [style.display]="isLoading ? 'none' : 'block'">
          <!-- MFE3 content will be injected here -->
        </div>
      </div>
    </div>
  `
})
export class DynamicLoaderComponent implements OnInit, OnDestroy {
  private elementRef = inject(ElementRef);
  private renderer = inject(Renderer2);
  private loadedScripts: HTMLElement[] = [];
  private loadedStyles: HTMLElement[] = [];
  
  isLoading = true;

  ngOnInit() {
    this.loadMfe3Assets();
  }

  ngOnDestroy() {
    this.cleanupAssets();
  }

  private async loadMfe3Assets() {
    try {
      // Load CSS first
      await this.loadStylesheet('/assets/mfe3/styles-5INURTSO.css');
      
      // Create the app-root element for MFE3
      this.createMfe3AppRoot();
      
      // Load polyfills
      await this.loadScript('/assets/mfe3/polyfills-B6TNHZQ6.js', true);
      
      // Load main application
      await this.loadScript('/assets/mfe3/main-ANW65TMV.js', true);
      
      // Wait a bit for Angular to bootstrap
      setTimeout(() => {
        this.isLoading = false;
        console.log('MFE3 assets loaded successfully');
      }, 1000);
      
    } catch (error) {
      console.error('Failed to load MFE3 assets:', error);
      this.isLoading = false;
    }
  }

  private createMfe3AppRoot() {
    const container = document.getElementById('mfe3-content');
    if (container) {
      // Add the content that was in the original index.html
      container.innerHTML = `
        <h1>MFETEST Standalone</h1>
        <app-root></app-root>
      `;
    }
  }

  private loadStylesheet(href: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const link = this.renderer.createElement('link');
      this.renderer.setAttribute(link, 'rel', 'stylesheet');
      this.renderer.setAttribute(link, 'href', href);
      
      link.onload = () => {
        console.log(`Loaded stylesheet: ${href}`);
        resolve();
      };
      
      link.onerror = () => {
        console.error(`Failed to load stylesheet: ${href}`);
        reject(new Error(`Failed to load stylesheet: ${href}`));
      };
      
      this.renderer.appendChild(document.head, link);
      this.loadedStyles.push(link);
    });
  }

  private loadScript(src: string, isModule: boolean = false): Promise<void> {
    return new Promise((resolve, reject) => {
      const script = this.renderer.createElement('script');
      this.renderer.setAttribute(script, 'src', src);
      
      if (isModule) {
        this.renderer.setAttribute(script, 'type', 'module');
      }
      
      script.onload = () => {
        console.log(`Loaded script: ${src}`);
        resolve();
      };
      
      script.onerror = () => {
        console.error(`Failed to load script: ${src}`);
        reject(new Error(`Failed to load script: ${src}`));
      };
      
      this.renderer.appendChild(document.head, script);
      this.loadedScripts.push(script);
    });
  }

  private cleanupAssets() {
    // Remove loaded scripts
    this.loadedScripts.forEach(script => {
      if (script.parentNode) {
        this.renderer.removeChild(script.parentNode, script);
      }
    });
    
    // Remove loaded styles
    this.loadedStyles.forEach(style => {
      if (style.parentNode) {
        this.renderer.removeChild(style.parentNode, style);
      }
    });
    
    this.loadedScripts = [];
    this.loadedStyles = [];
    
    console.log('MFE3 assets cleaned up');
  }
}
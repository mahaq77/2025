import { Component, OnInit, OnDestroy, ElementRef, inject, Renderer2, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-enhanced-loader',
  standalone: true,
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <div class="enhanced-app-container" style="width: 100%; height: 100vh; padding-top: 80px;">
      <div id="mfe3-wrapper" style="width: 100%; height: calc(100vh - 80px); padding: 20px;">
        <div id="mfe3-loading" *ngIf="isLoading" style="text-align: center; padding: 50px;">
          <h2>🚀 Loading MFE3...</h2>
          <p>Dynamically loading your Angular application...</p>
          <div style="margin-top: 20px;">
            <div style="display: inline-block; width: 20px; height: 20px; border: 3px solid #f3f3f3; border-top: 3px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite;"></div>
          </div>
        </div>
        
        <div id="mfe3-error" *ngIf="hasError" style="text-align: center; padding: 50px; color: #dc3545;">
          <h2>❌ Loading Failed</h2>
          <p>Failed to load MFE3. Please check the console for details.</p>
          <button (click)="retryLoad()" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">
            Retry
          </button>
        </div>
        
        <div id="mfe3-content" [style.display]="isLoading || hasError ? 'none' : 'block'">
          <!-- MFE3 content will be injected here -->
        </div>
      </div>
    </div>
    
    <style>
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    </style>
  `
})
export class EnhancedLoaderComponent implements OnInit, OnDestroy {
  private elementRef = inject(ElementRef);
  private renderer = inject(Renderer2);
  private loadedScripts: HTMLElement[] = [];
  private loadedStyles: HTMLElement[] = [];
  
  isLoading = true;
  private baseUrl!: string;
  hasError = false;
  private loadAttempts = 0;
  private maxAttempts = 3;
  private route = inject(ActivatedRoute);

  ngOnInit() {
    this.baseUrl = this.route.snapshot.data['remoteUrl'] || 'http://172.31.32.1:8080';
    this.loadMfe3Assets();
  }

  ngOnDestroy() {
    this.cleanupAssets();
  }

  retryLoad() {
    this.hasError = false;
    this.isLoading = true;
    this.loadAttempts = 0;
    this.cleanupAssets();
    this.loadMfe3Assets();
  }

  private async loadMfe3Assets() {
    this.loadAttempts++;
    
    try {
      console.log(`Loading MFE3 assets from ${this.baseUrl} (attempt ${this.loadAttempts}/${this.maxAttempts})`);
      
      // Step 1: Load CSS
      console.log('Loading CSS...');
      await this.loadStylesheet(`${this.baseUrl}styles.css`);
      
      // Step 2: Prepare container
      console.log('Preparing container...');
      this.prepareMfe3Container();
      
      // Step 3: Load polyfills and main bundle
      console.log('Loading scripts...');
      await this.loadScript(`${this.baseUrl}polyfills.js`, true);
      await this.loadScript(`${this.baseUrl}main.js`, true);
      
      // Step 4: Wait for Angular to bootstrap
      console.log('Waiting for Angular bootstrap...');
      await this.waitForAngularBootstrap();
      
      this.isLoading = false;
      console.log('✅ MFE3 loaded successfully!');
      
      
    } catch (error) {
      console.error(`❌ Failed to load MFE3 (attempt ${this.loadAttempts}):`, error);
      
      if (this.loadAttempts < this.maxAttempts) {
        console.log(`Retrying in 2 seconds...`);
        setTimeout(() => {
          this.cleanupAssets();
          this.loadMfe3Assets();
        }, 2000);
      } else {
        this.isLoading = false;
        this.hasError = true;
      }
    }
  }

  private prepareMfe3Container() {
    const container = document.getElementById('mfe3-content');
    if (container) {
      // Create a unique container for this MFE to avoid conflicts
      container.innerHTML = `
        <div id="mfe3-app-container" style="width: 100%; height: 100%;">
          <h1 style="color: #007bff; margin-bottom: 20px;">🎯 MFETEST Standalone</h1>
          <div id="mfe3-app-root">
            <app-root></app-root>
          </div>
        </div>
      `;
    }
  }

  private waitForAngularBootstrap(): Promise<void> {
    return new Promise((resolve, reject) => {
      let attempts = 0;
      const maxBootstrapAttempts = 50; // 5 seconds max
      
      const checkBootstrap = () => {
        attempts++;
        
        // Check if Angular has bootstrapped by looking for Angular-specific elements
        const appRoot = document.querySelector('#mfe3-content app-root');
        const hasAngularContent = appRoot && (
          appRoot.children.length > 0 || 
          appRoot.innerHTML.trim() !== '' ||
          appRoot.textContent?.trim() !== ''
        );
        
        if (hasAngularContent) {
          console.log('✅ Angular app detected and bootstrapped');
          resolve();
        } else if (attempts >= maxBootstrapAttempts) {
          console.log('⚠️ Angular bootstrap timeout, but continuing...');
          resolve(); // Don't fail, just continue
        } else {
          setTimeout(checkBootstrap, 100);
        }
      };
      
      // Start checking after a short delay
      setTimeout(checkBootstrap, 500);
    });
  }

  private loadStylesheet(href: string): Promise<void> {
    return new Promise((resolve, reject) => {
      // Check if already loaded
      const existing = document.querySelector(`link[href="${href}"]`);
      if (existing) {
        console.log(`Stylesheet already loaded: ${href}`);
        resolve();
        return;
      }
      
      const link = this.renderer.createElement('link');
      this.renderer.setAttribute(link, 'rel', 'stylesheet');
      this.renderer.setAttribute(link, 'href', href);
      this.renderer.setAttribute(link, 'data-mfe3', 'true'); // Mark for cleanup
      
      link.onload = () => {
        console.log(`✅ Loaded stylesheet: ${href}`);
        resolve();
      };
      
      link.onerror = () => {
        const error = new Error(`Failed to load stylesheet: ${href}`);
        console.error('❌', error.message);
        reject(error);
      };
      
      this.renderer.appendChild(document.head, link);
      this.loadedStyles.push(link);
    });
  }

  private loadScript(src: string, isModule: boolean = false): Promise<void> {
    return new Promise((resolve, reject) => {
      // Check if already loaded
      const existing = document.querySelector(`script[src="${src}"]`);
      if (existing) {
        console.log(`Script already loaded: ${src}`);
        resolve();
        return;
      }
      
      const script = this.renderer.createElement('script');
      this.renderer.setAttribute(script, 'src', src);
      this.renderer.setAttribute(script, 'data-mfe3', 'true'); // Mark for cleanup
      
      if (isModule) {
        this.renderer.setAttribute(script, 'type', 'module');
      }
      
      script.onload = () => {
        console.log(`✅ Loaded script: ${src}`);
        resolve();
      };
      
      script.onerror = () => {
        const error = new Error(`Failed to load script: ${src}`);
        console.error('❌', error.message);
        reject(error);
      };
      
      this.renderer.appendChild(document.head, script);
      this.loadedScripts.push(script);
    });
  }

  private cleanupAssets() {
    console.log('🧹 Cleaning up MFE3 assets...');
    
    // Remove loaded scripts
    this.loadedScripts.forEach(script => {
      if (script.parentNode) {
        this.renderer.removeChild(script.parentNode, script);
      }
    });
    
    // Remove loaded styles
    this.loadedStyles.forEach(style => {
      if (style.parentNode) {
        this.renderer.removeChild(style.parentNode, style);
      }
    });
    
    // Also remove any elements marked with data-mfe3
    const mfe3Elements = document.querySelectorAll('[data-mfe3="true"]');
    mfe3Elements.forEach(element => {
      if (element.parentNode) {
        element.parentNode.removeChild(element);
      }
    });
    
    this.loadedScripts = [];
    this.loadedStyles = [];
    
    console.log('✅ MFE3 assets cleaned up');
  }
}
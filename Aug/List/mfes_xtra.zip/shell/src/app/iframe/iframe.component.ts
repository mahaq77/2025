import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-iframe',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="iframe-container" style="width: 100%; height: 100vh; padding-top: 80px;">
      <iframe 
        [src]="safeUrl" 
        style="width: 100%; height: calc(100vh - 80px); border: none;"
        frameborder="0">
      </iframe>
    </div>
  `
})
export class IframeComponent {
  private route = inject(ActivatedRoute);
  private sanitizer = inject(DomSanitizer);
  
  safeUrl: SafeResourceUrl;

  constructor() {
    const url = this.route.snapshot.data['url'] || 'http://localhost:4207';
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FederationService } from './shared/services/federation.service';
import { injectFederationStore } from './shared/store/federation.store';

@Component({
  selector: 'app-root',
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit, OnDestroy {
  protected title = 'mfe2';
  protected Object = Object; // For template access
  
  private federationService = inject(FederationService);
  private federationStore = injectFederationStore();
  private messageSubscription?: () => void;

  // Reactive properties
  currentUser = this.federationStore.user;
  currentTheme = this.federationStore.theme;
  sharedData = this.federationStore.sharedData;
  
  // Local state
  localData = {
    tasks: ['Task 1', 'Task 2', 'Task 3'],
    selectedTask: null as string | null,
    completedTasks: 0
  };
  receivedMessages: string[] = [];

  ngOnInit() {
    // Subscribe to messages from shell and other MFEs
    this.messageSubscription = this.federationService.subscribeToMessages('mfe2', (message) => {
      this.handleMessage(message);
    });

    // Also check for 'all' messages (broadcasts)
    this.federationService.subscribeToMessages('all', (message) => {
      this.handleMessage(message);
    });

    // Send initial greeting to shell
    this.federationService.sendToMfe('shell', 'mfe-ready', {
      mfe: 'mfe2',
      message: 'MFE2 is ready!',
      timestamp: new Date()
    });
  }

  ngOnDestroy() {
    if (this.messageSubscription) {
      this.messageSubscription();
    }
  }

  private handleMessage(message: any) {
    console.log('MFE2 received message:', message);
    this.receivedMessages.unshift(`${message.from}: ${message.type} - ${JSON.stringify(message.payload)}`);
    
    // Keep only last 10 messages
    if (this.receivedMessages.length > 10) {
      this.receivedMessages = this.receivedMessages.slice(0, 10);
    }
  }

  // Methods for template
  addTask() {
    const newTask = prompt('Enter new task:');
    if (newTask) {
      this.localData.tasks.push(newTask);
      this.shareTaskData();
    }
  }

  completeTask(task: string) {
    this.localData.tasks = this.localData.tasks.filter(t => t !== task);
    this.localData.completedTasks++;
    this.shareTaskData();
  }

  shareTaskData() {
    this.federationService.shareData('mfe2-tasks', {
      tasks: this.localData.tasks,
      completedTasks: this.localData.completedTasks,
      timestamp: new Date()
    });
  }

  sendToShell() {
    this.federationService.sendToMfe('shell', 'mfe2-update', {
      message: 'Update from MFE2',
      taskCount: this.localData.tasks.length,
      completedTasks: this.localData.completedTasks,
      timestamp: new Date()
    });
  }

  sendToMfe1() {
    this.federationService.sendToMfe('mfe1', 'mfe2-greeting', {
      message: 'Hello from MFE2!',
      taskData: this.localData,
      timestamp: new Date()
    });
  }

  broadcastTaskUpdate() {
    this.federationService.broadcastToAll('mfe2-task-update', {
      message: 'Task update from MFE2',
      data: this.localData,
      timestamp: new Date()
    });
  }

  updateUserRole() {
    const newRole = prompt('Enter new role:', this.currentUser().role || '');
    if (newRole) {
      this.federationService.updateUser({ role: newRole });
    }
  }

  clearMessages() {
    this.receivedMessages = [];
  }
}

import { Injectable, inject, effect } from '@angular/core';
import { Router } from '@angular/router';
import { FederationStore } from '../store/federation.store';

@Injectable({
  providedIn: 'root'
})
export class FederationService {
  private store = inject(FederationStore);
  private router = inject(Router);

  constructor() {
    // Initialize the store
    this.initializeStore();
    
    // Set up effects for route changes
    this.setupRouteTracking();
    
    // Set up theme effects
    this.setupThemeEffects();
  }

  private initializeStore() {
    // Load saved state
    this.store.loadState();
    this.store.loadTheme();
    
    // Initialize with demo user (in real app, this would come from auth service)
    this.store.setUser({
      id: 'user-123',
      name: 'John Doe',
      email: 'john.doe@example.com',
      role: 'admin'
    });
  }

  private setupRouteTracking() {
    // Track current MFE based on route
    effect(() => {
      const url = this.router.url;
      let currentMfe = null;
      
      if (url.includes('/mfe1')) {
        currentMfe = 'mfe1';
      } else if (url.includes('/mfe2')) {
        currentMfe = 'mfe2';
      } else if (url === '/' || url === '') {
        currentMfe = 'shell';
      }
      
      if (currentMfe !== this.store.currentMfe()) {
        this.store.setCurrentMfe(currentMfe);
        
        // Broadcast navigation event
        if (currentMfe) {
          this.store.broadcast('shell', 'navigation', {
            from: this.store.currentMfe(),
            to: currentMfe,
            url: url,
            timestamp: new Date()
          });
        }
      }
    });
  }

  private setupThemeEffects() {
    // Apply theme changes to document
    effect(() => {
      const theme = this.store.theme();
      document.documentElement.setAttribute('data-theme', theme);
      document.body.className = theme === 'dark' ? 'dark-theme' : 'light-theme';
    });
  }

  // Public API methods
  
  // User management
  getCurrentUser() {
    return this.store.user;
  }

  updateUser(userData: Partial<{ id: string; name: string; email: string; role: string }>) {
    this.store.setUser(userData);
    this.store.saveState();
    
    // Broadcast user update
    this.store.broadcast('shell', 'user-updated', userData);
  }

  logout() {
    this.store.clearUser();
    this.store.clearSharedData();
    this.store.clearMessages();
    localStorage.removeItem('federation-state');
    
    // Broadcast logout event
    this.store.broadcast('shell', 'user-logout', {});
  }

  // Theme management
  toggleTheme() {
    const newTheme = this.store.theme() === 'light' ? 'dark' : 'light';
    this.store.setTheme(newTheme);
    
    // Broadcast theme change
    this.store.broadcast('shell', 'theme-changed', { theme: newTheme });
  }

  getCurrentTheme() {
    return this.store.theme;
  }

  // Data sharing
  shareData(key: string, data: any, targetMfe?: string) {
    this.store.setSharedData(key, data);
    this.store.saveState();
    
    // Notify specific MFE or broadcast to all
    const target = targetMfe || 'all';
    this.store.sendMessage('shell', target, 'data-shared', {
      key,
      data,
      timestamp: new Date()
    });
  }

  getData(key: string) {
    return this.store.getSharedData(key);
  }

  // Communication
  sendToMfe(mfe: string, type: string, payload: any) {
    return this.store.sendMessage('shell', mfe, type, payload);
  }

  broadcastToAll(type: string, payload: any) {
    return this.store.broadcast('shell', type, payload);
  }

  getMessagesForMfe(mfe: string) {
    return this.store.getMessagesFor(mfe);
  }

  // Navigation helpers
  getCurrentMfe() {
    return this.store.currentMfe;
  }

  navigateToMfe(mfe: string, path?: string) {
    const route = path ? `/${mfe}/${path}` : `/${mfe}`;
    this.router.navigate([route]);
  }

  // State management
  getFullState() {
    return {
      user: this.store.user(),
      currentMfe: this.store.currentMfe(),
      theme: this.store.theme(),
      sharedData: this.store.sharedData(),
      messages: this.store.messages(),
      loading: this.store.loading(),
      errors: this.store.errors(),
    };
  }

  resetState() {
    this.store.reset();
    localStorage.removeItem('federation-state');
    localStorage.removeItem('federation-theme');
  }

  // Advanced features
  
  // Cross-MFE data synchronization
  syncData(key: string, data: any) {
    this.shareData(key, data);
    
    // Also store in a special sync namespace
    this.store.setSharedData(`sync:${key}`, {
      data,
      timestamp: new Date(),
      version: Date.now()
    });
  }

  // Event subscription helper
  subscribeToMessages(mfe: string, callback: (message: any) => void) {
    // This would be enhanced with RxJS observables in a real implementation
    const checkMessages = () => {
      const messages = this.getMessagesForMfe(mfe);
      messages.forEach(message => {
        callback(message);
        this.store.markMessageAsRead(message.id);
      });
    };
    
    // Check for messages periodically (in real app, use observables)
    const interval = setInterval(checkMessages, 100);
    
    // Return cleanup function
    return () => clearInterval(interval);
  }
}
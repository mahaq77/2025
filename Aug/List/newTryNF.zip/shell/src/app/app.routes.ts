import { Routes } from '@angular/router';
import { HomeComponent } from './home/home';
import { loadRemoteModule } from '@angular-architects/native-federation';

export const routes: Routes = [
  {
    path: 'mfe1',
    loadChildren: () => loadRemoteModule('mfe1', './Module').then(m => m.RemoteEntryModule)
  },
  {
    path: 'mfe2',
    loadChildren: () => loadRemoteModule('mfe2', './Module').then(m => m.RemoteEntryModule)
  },
  {
    path: '',
    component: HomeComponent
  }
];

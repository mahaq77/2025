import { Component, inject, computed } from '@angular/core';
import { RouterOutlet, RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FederationService } from './shared/services/federation.service';
import { injectFederationStore } from './shared/store/federation.store';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'shell';
  
  private federationService = inject(FederationService);
  private federationStore = injectFederationStore();
  public router = inject(Router);

  // Computed properties for template
  currentUser = this.federationStore.user;
  currentTheme = this.federationStore.theme;
  currentMfe = this.federationStore.currentMfe;
  sharedData = this.federationStore.sharedData;

  get isHomeRoute(): boolean {
    return this.router.url === '/' || this.router.url === '';
  }

  // Methods for template
  toggleTheme() {
    this.federationService.toggleTheme();
  }

  updateUserName() {
    const newName = prompt('Enter new name:', this.currentUser().name || '');
    if (newName) {
      this.federationService.updateUser({ name: newName });
    }
  }

  shareDataWithMfes() {
    const data = {
      message: 'Hello from Shell!',
      timestamp: new Date(),
      counter: Math.floor(Math.random() * 100)
    };
    this.federationService.shareData('shell-message', data);
  }

  sendMessageToMfe1() {
    this.federationService.sendToMfe('mfe1', 'greeting', {
      message: 'Hello MFE1 from Shell!',
      timestamp: new Date()
    });
  }

  sendMessageToMfe2() {
    this.federationService.sendToMfe('mfe2', 'greeting', {
      message: 'Hello MFE2 from Shell!',
      timestamp: new Date()
    });
  }

  broadcastToAll() {
    this.federationService.broadcastToAll('announcement', {
      message: 'Important announcement from Shell!',
      priority: 'high',
      timestamp: new Date()
    });
  }

  logout() {
    this.federationService.logout();
  }
}

# DAF Tracker - Advanced User Interaction Tracking Library

A comprehensive Angular library for tracking user interactions, analytics, performance monitoring, and GDPR-compliant data collection.

## Features

### 🎯 Core Tracking
- **Click Tracking**: Automatic and manual click event tracking
- **Page Views**: Track page visits and navigation
- **Scroll Tracking**: Monitor scroll behavior and engagement
- **Form Interactions**: Track form submissions and field changes
- **Hover Events**: Track user hover patterns
- **Custom Events**: Define and track custom user interactions

### 📊 Analytics & Reporting
- **Real-time Analytics**: Live tracking data and metrics
- **Funnel Analysis**: Track user conversion funnels
- **Cohort Analysis**: Analyze user retention over time
- **User Journey Mapping**: Track complete user paths
- **Session Analytics**: Detailed session-level insights

### 🔥 Heatmaps
- **Click Heatmaps**: Visual representation of click patterns
- **Hover Heatmaps**: Track mouse movement and hover areas
- **Scroll Heatmaps**: Visualize scroll behavior
- **Element-specific Heatmaps**: Focus on specific page elements

### ⚡ Performance Monitoring
- **Core Web Vitals**: LCP, FID, CLS tracking
- **Resource Performance**: Monitor loading times
- **Long Task Detection**: Identify performance bottlenecks
- **Custom Performance Metrics**: Track application-specific metrics

### 🔒 Privacy & Compliance
- **GDPR Compliance**: Built-in consent management
- **Data Anonymization**: Automatic PII protection
- **Do Not Track**: Respect user privacy preferences
- **Data Subject Rights**: Handle access, deletion, and portability requests

### 💾 Flexible Storage
- **Multiple Storage Backends**: localStorage, sessionStorage, IndexedDB, memory
- **Custom Storage Providers**: Implement your own storage solution
- **Data Compression**: Efficient storage utilization
- **Automatic Cleanup**: Manage storage limits and expiration

## Installation

```bash
npm install daf-track
```

## Quick Start

### 1. Import the Module

```typescript
import { NgModule } from '@angular/core';
import { DafTrackModule } from 'daf-track';

@NgModule({
  imports: [
    DafTrackModule.forRoot({
      enabled: true,
      debug: true,
      storageType: 'localStorage',
      requireConsent: true,
      respectDoNotTrack: true
    })
  ]
})
export class AppModule { }
```

### 2. Basic Usage

```typescript
import { Component, OnInit } from '@angular/core';
import { DafTracker, EventType } from 'daf-track';

@Component({
  selector: 'app-home',
  template: `
    <button dafTrack="click" 
            dafTrackCategory="navigation" 
            dafTrackAction="header-cta">
      Get Started
    </button>
    
    <div dafTrack="view" 
         dafTrackCategory="content" 
         dafTrackAction="hero-section">
      Hero Content
    </div>
  `
})
export class HomeComponent implements OnInit {
  constructor(private tracker: DafTracker) {}

  ngOnInit() {
    // Track page view
    this.tracker.trackView('/home');
    
    // Track custom event
    this.tracker.trackCustom('feature_used', 'engagement', {
      feature: 'search',
      value: 'angular components'
    });
  }
}
```

## Configuration

### Complete Configuration Options

```typescript
const config: DafTrackerConfig = {
  // Basic settings
  enabled: true,
  debug: false,
  
  // Storage settings
  storageType: StorageType.LOCAL_STORAGE,
  storageKey: 'daf_tracker_events',
  maxStorageSize: 10000,
  
  // Privacy settings
  respectDoNotTrack: true,
  requireConsent: false,
  anonymizeData: false,
  
  // Sampling and filtering
  sampleRate: 1.0, // Track 100% of events
  excludeEvents: [EventType.SCROLL], // Don't track scroll events
  includeEvents: [], // If specified, only track these events
  
  // Batch processing
  batchSize: 50,
  batchTimeout: 5000, // 5 seconds
  
  // API settings (optional)
  apiEndpoint: 'https://api.example.com/tracking',
  apiKey: 'your-api-key',
  
  // Custom settings
  customFields: {
    appVersion: '1.0.0',
    environment: 'production'
  }
};
```

## Directive Usage

### Basic Tracking

```html
<!-- Track clicks -->
<button dafTrack="click">Click Me</button>

<!-- Track views with Intersection Observer -->
<div dafTrack="view">Content Section</div>

<!-- Track multiple events -->
<input dafTrack 
       dafTrackEvents="focus,blur,change"
       dafTrackCategory="form"
       dafTrackAction="email-input">
```

### Advanced Tracking

```html
<!-- Conditional tracking -->
<button dafTrack="click"
        [dafTrackCondition]="shouldTrack"
        dafTrackOnce="true"
        dafTrackDebounce="300">
  Submit Form
</button>

<!-- Custom data -->
<div dafTrack="view"
     [dafTrackData]="{ section: 'pricing', plan: 'premium' }">
  Pricing Section
</div>
```

## Service Usage

### Analytics Service

```typescript
import { AnalyticsService } from 'daf-track';

constructor(private analytics: AnalyticsService) {}

async generateReport() {
  const report = await this.analytics.generateReport({
    startDate: new Date('2024-01-01'),
    endDate: new Date(),
    eventTypes: [EventType.CLICK, EventType.VIEW]
  });
  
  console.log('Total events:', report.data.totalEvents);
  console.log('Top pages:', report.data.topPages);
}

async analyzeFunnel() {
  const funnel = await this.analytics.getFunnelAnalysis([
    { name: 'Landing', eventType: EventType.VIEW, eventAction: 'page_view', required: true },
    { name: 'Signup', eventType: EventType.CLICK, eventAction: 'signup_click', required: true },
    { name: 'Complete', eventType: EventType.FORM_SUBMIT, eventAction: 'signup_submit', required: true }
  ]);
  
  console.log('Conversion rate:', funnel.overallConversionRate);
}
```

### Consent Service

```typescript
import { ConsentService } from 'daf-track';

constructor(private consent: ConsentService) {}

async handleConsent() {
  // Grant consent for specific categories
  await this.consent.grantConsent(['analytics', 'marketing']);
  
  // Check consent status
  const hasAnalyticsConsent = this.consent.hasConsent('analytics');
  
  // Handle data subject request
  const requestId = await this.consent.submitDataSubjectRequest({
    type: 'erasure',
    userId: 'user123',
    email: 'user@example.com'
  });
}
```

### Heatmap Service

```typescript
import { HeatmapService } from 'daf-track';

constructor(private heatmap: HeatmapService) {}

async generateHeatmap() {
  // Configure heatmap tracking
  this.heatmap.configure({
    enabled: true,
    trackClicks: true,
    trackHovers: true,
    sampleRate: 0.1 // Track 10% of interactions
  });
  
  // Start tracking
  this.heatmap.startTracking();
  
  // Generate heatmap image
  const heatmapImage = await this.heatmap.generateHeatmapImage(1920, 1080);
  
  // Get element-specific data
  const buttonHeatmap = await this.heatmap.getElementHeatmap('button');
}
```

### Performance Service

```typescript
import { PerformanceService } from 'daf-track';

constructor(private performance: PerformanceService) {}

async analyzePerformance() {
  const report = await this.performance.getPerformanceReport();
  
  console.log('Performance score:', report.score);
  console.log('Core Web Vitals:', report.metrics);
  console.log('Slow resources:', report.resources);
  
  // Get detailed resource analysis
  const resourceAnalysis = await this.performance.getResourceAnalysis();
  console.log('Total resources:', resourceAnalysis.totalResources);
  console.log('Average load time:', resourceAnalysis.averageLoadTime);
}
```

## Storage Providers

### Using Different Storage Types

```typescript
import { StorageService, StorageType } from 'daf-track';

constructor(private storage: StorageService) {}

// Switch to IndexedDB
this.storage.setProvider(StorageType.INDEXED_DB, {
  encrypt: true,
  compress: true,
  ttl: 30 * 24 * 60 * 60 * 1000 // 30 days
});

// Use custom storage provider
class CustomStorageProvider implements StorageProvider {
  async store(key: string, data: any): Promise<void> {
    // Custom storage implementation
  }
  
  async retrieve(key: string): Promise<any> {
    // Custom retrieval implementation
  }
  
  // ... other methods
}

this.storage.setCustomProvider(new CustomStorageProvider());
```

## Event Types

```typescript
enum EventType {
  CLICK = 'click',
  VIEW = 'view',
  SCROLL = 'scroll',
  HOVER = 'hover',
  FOCUS = 'focus',
  BLUR = 'blur',
  FORM_SUBMIT = 'form_submit',
  FORM_FIELD_CHANGE = 'form_field_change',
  PAGE_LOAD = 'page_load',
  PAGE_UNLOAD = 'page_unload',
  CUSTOM = 'custom',
  ERROR = 'error',
  PERFORMANCE = 'performance'
}
```

## Data Export

```typescript
// Export tracking data
const jsonData = await this.tracker.exportData('json');
const csvData = await this.tracker.exportData('csv');

// Export heatmap data
const heatmapJson = await this.heatmap.exportHeatmapData('json');
const heatmapCsv = await this.heatmap.exportHeatmapData('csv');
```

## Best Practices

### 1. Privacy First
- Always implement consent management for GDPR compliance
- Use data anonymization for sensitive information
- Respect Do Not Track headers
- Implement data retention policies

### 2. Performance Optimization
- Use sampling for high-traffic applications
- Configure appropriate batch sizes
- Monitor storage usage
- Clean up expired data regularly

### 3. Data Quality
- Validate tracking events before sending
- Use consistent naming conventions
- Implement proper error handling
- Test tracking in different environments

### 4. Security
- Encrypt sensitive data in storage
- Use HTTPS for API endpoints
- Implement proper authentication
- Regularly audit tracking data

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
- GitHub Issues: [Create an issue](https://github.com/your-repo/daf-track/issues)
- Documentation: [Full documentation](https://your-docs-site.com)
- Examples: [Example applications](https://github.com/your-repo/daf-track-examples)
import { Injectable } from '@angular/core';
import { BehaviorSubject, fromEvent } from 'rxjs';
import { throttleTime, takeUntil } from 'rxjs/operators';

import { HeatmapData, TrackingEvent, EventType } from '../models';
import { StorageService } from '../storage/storage.service';

export interface HeatmapPoint {
    x: number;
    y: number;
    intensity: number;
    eventType: EventType;
    timestamp: number;
}

export interface HeatmapConfig {
    enabled: boolean;
    trackClicks: boolean;
    trackHovers: boolean;
    trackScrolls: boolean;
    sampleRate: number;
    maxPoints: number;
    hoverThreshold: number; // minimum hover duration in ms
}

@Injectable({
    providedIn: 'root'
})
export class HeatmapService {
    private config: HeatmapConfig = {
        enabled: true,
        trackClicks: true,
        trackHovers: true,
        trackScrolls: true,
        sampleRate: 0.1, // Track 10% of interactions
        maxPoints: 10000,
        hoverThreshold: 500
    };

    private heatmapPoints: HeatmapPoint[] = [];
    private heatmapSubject = new BehaviorSubject<HeatmapPoint[]>([]);
    public heatmap$ = this.heatmapSubject.asObservable();

    private isTracking = false;
    private hoverStartTime: number = 0;
    private hoverStartPosition: { x: number; y: number } | null = null;

    constructor(private storageService: StorageService) {
        this.loadHeatmapData();
    }

    configure(config: Partial<HeatmapConfig>): void {
        this.config = { ...this.config, ...config };
        
        if (this.config.enabled && !this.isTracking) {
            this.startTracking();
        } else if (!this.config.enabled && this.isTracking) {
            this.stopTracking();
        }
    }

    startTracking(): void {
        if (this.isTracking || typeof window === 'undefined') return;
        
        this.isTracking = true;

        // Track clicks
        if (this.config.trackClicks) {
            fromEvent<MouseEvent>(document, 'click')
                .pipe(throttleTime(100))
                .subscribe(event => this.recordClick(event));
        }

        // Track hovers
        if (this.config.trackHovers) {
            fromEvent<MouseEvent>(document, 'mousemove')
                .pipe(throttleTime(100))
                .subscribe(event => this.trackHover(event));

            fromEvent<MouseEvent>(document, 'mouseenter')
                .subscribe(event => this.startHover(event));

            fromEvent<MouseEvent>(document, 'mouseleave')
                .subscribe(event => this.endHover(event));
        }

        // Track scrolls
        if (this.config.trackScrolls) {
            fromEvent<Event>(window, 'scroll')
                .pipe(throttleTime(500))
                .subscribe(() => this.recordScroll());
        }
    }

    stopTracking(): void {
        this.isTracking = false;
        // Event listeners will be automatically cleaned up by RxJS
    }

    private recordClick(event: MouseEvent): void {
        if (!this.shouldSample()) return;

        const point: HeatmapPoint = {
            x: event.clientX + window.scrollX,
            y: event.clientY + window.scrollY,
            intensity: 1,
            eventType: EventType.CLICK,
            timestamp: Date.now()
        };

        this.addHeatmapPoint(point);
    }

    private startHover(event: MouseEvent): void {
        this.hoverStartTime = Date.now();
        this.hoverStartPosition = {
            x: event.clientX + window.scrollX,
            y: event.clientY + window.scrollY
        };
    }

    private trackHover(event: MouseEvent): void {
        // This method can be used for continuous hover tracking if needed
    }

    private endHover(event: MouseEvent): void {
        if (!this.shouldSample() || !this.hoverStartPosition) return;

        const hoverDuration = Date.now() - this.hoverStartTime;
        
        if (hoverDuration >= this.config.hoverThreshold) {
            const point: HeatmapPoint = {
                x: this.hoverStartPosition.x,
                y: this.hoverStartPosition.y,
                intensity: Math.min(hoverDuration / 1000, 10), // Max intensity of 10
                eventType: EventType.HOVER,
                timestamp: Date.now()
            };

            this.addHeatmapPoint(point);
        }

        this.hoverStartPosition = null;
    }

    private recordScroll(): void {
        if (!this.shouldSample()) return;

        const point: HeatmapPoint = {
            x: window.innerWidth / 2, // Center of viewport
            y: window.scrollY + (window.innerHeight / 2),
            intensity: 0.5,
            eventType: EventType.SCROLL,
            timestamp: Date.now()
        };

        this.addHeatmapPoint(point);
    }

    private addHeatmapPoint(point: HeatmapPoint): void {
        this.heatmapPoints.push(point);

        // Limit the number of points
        if (this.heatmapPoints.length > this.config.maxPoints) {
            this.heatmapPoints.shift();
        }

        this.heatmapSubject.next([...this.heatmapPoints]);
        this.saveHeatmapData();
    }

    private shouldSample(): boolean {
        return Math.random() < this.config.sampleRate;
    }

    async getHeatmapData(filter?: {
        eventTypes?: EventType[];
        startDate?: Date;
        endDate?: Date;
        minIntensity?: number;
    }): Promise<HeatmapPoint[]> {
        let points = [...this.heatmapPoints];

        if (filter) {
            if (filter.eventTypes) {
                points = points.filter(p => filter.eventTypes!.includes(p.eventType));
            }

            if (filter.startDate) {
                points = points.filter(p => p.timestamp >= filter.startDate!.getTime());
            }

            if (filter.endDate) {
                points = points.filter(p => p.timestamp <= filter.endDate!.getTime());
            }

            if (filter.minIntensity) {
                points = points.filter(p => p.intensity >= filter.minIntensity!);
            }
        }

        return points;
    }

    async generateHeatmapImage(
        width: number = 1920,
        height: number = 1080,
        options: {
            radius?: number;
            blur?: number;
            maxIntensity?: number;
            gradient?: Record<number, string>;
        } = {}
    ): Promise<string> {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
            throw new Error('Could not get canvas context');
        }

        const radius = options.radius || 25;
        const blur = options.blur || 15;
        const maxIntensity = options.maxIntensity || 10;
        const gradient = options.gradient || {
            0.0: 'rgba(0, 0, 255, 0)',
            0.2: 'rgba(0, 0, 255, 0.5)',
            0.4: 'rgba(0, 255, 255, 0.8)',
            0.6: 'rgba(0, 255, 0, 0.8)',
            0.8: 'rgba(255, 255, 0, 0.8)',
            1.0: 'rgba(255, 0, 0, 1)'
        };

        // Create gradient
        const gradientCanvas = document.createElement('canvas');
        gradientCanvas.width = 256;
        gradientCanvas.height = 1;
        const gradientCtx = gradientCanvas.getContext('2d');

        if (gradientCtx) {
            const gradientObj = gradientCtx.createLinearGradient(0, 0, 256, 0);
            Object.entries(gradient).forEach(([stop, color]) => {
                gradientObj.addColorStop(parseFloat(stop), color);
            });
            gradientCtx.fillStyle = gradientObj;
            gradientCtx.fillRect(0, 0, 256, 1);
        }

        // Draw heatmap points
        const points = await this.getHeatmapData();
        
        // Create intensity map
        const intensityData = ctx.createImageData(width, height);
        
        points.forEach(point => {
            const x = Math.round(point.x);
            const y = Math.round(point.y);
            
            if (x >= 0 && x < width && y >= 0 && y < height) {
                // Draw circle with intensity
                for (let i = -radius; i <= radius; i++) {
                    for (let j = -radius; j <= radius; j++) {
                        const px = x + i;
                        const py = y + j;
                        
                        if (px >= 0 && px < width && py >= 0 && py < height) {
                            const distance = Math.sqrt(i * i + j * j);
                            if (distance <= radius) {
                                const intensity = point.intensity * (1 - distance / radius);
                                const index = (py * width + px) * 4;
                                
                                // Add to alpha channel (we'll use this for intensity)
                                intensityData.data[index + 3] = Math.min(255, 
                                    intensityData.data[index + 3] + intensity * 25
                                );
                            }
                        }
                    }
                }
            }
        });

        // Apply gradient based on intensity
        for (let i = 0; i < intensityData.data.length; i += 4) {
            const intensity = intensityData.data[i + 3];
            if (intensity > 0) {
                const normalizedIntensity = Math.min(intensity / 255, 1);
                const gradientIndex = Math.floor(normalizedIntensity * 255);
                
                if (gradientCtx) {
                    const gradientData = gradientCtx.getImageData(gradientIndex, 0, 1, 1);
                    intensityData.data[i] = gradientData.data[0];     // R
                    intensityData.data[i + 1] = gradientData.data[1]; // G
                    intensityData.data[i + 2] = gradientData.data[2]; // B
                    intensityData.data[i + 3] = gradientData.data[3]; // A
                }
            }
        }

        ctx.putImageData(intensityData, 0, 0);

        // Apply blur if specified
        if (blur > 0) {
            ctx.filter = `blur(${blur}px)`;
            ctx.drawImage(canvas, 0, 0);
        }

        return canvas.toDataURL();
    }

    async getElementHeatmap(selector: string): Promise<HeatmapData[]> {
        const elements = document.querySelectorAll(selector);
        const elementData: HeatmapData[] = [];

        elements.forEach((element, index) => {
            const rect = element.getBoundingClientRect();
            const elementPoints = this.heatmapPoints.filter(point => {
                return point.x >= rect.left + window.scrollX &&
                       point.x <= rect.right + window.scrollX &&
                       point.y >= rect.top + window.scrollY &&
                       point.y <= rect.bottom + window.scrollY;
            });

            const clicks = elementPoints.filter(p => p.eventType === EventType.CLICK).length;
            const hovers = elementPoints.filter(p => p.eventType === EventType.HOVER).length;
            const views = elementPoints.filter(p => p.eventType === EventType.VIEW).length;

            elementData.push({
                element: element.tagName.toLowerCase(),
                selector: `${selector}:nth-child(${index + 1})`,
                clicks,
                hovers,
                views,
                position: {
                    x: rect.left + window.scrollX,
                    y: rect.top + window.scrollY,
                    width: rect.width,
                    height: rect.height
                }
            });
        });

        return elementData;
    }

    async clearHeatmapData(): Promise<void> {
        this.heatmapPoints = [];
        this.heatmapSubject.next([]);
        await this.storageService.remove('heatmap_data');
    }

    async exportHeatmapData(format: 'json' | 'csv' = 'json'): Promise<string> {
        const points = await this.getHeatmapData();

        if (format === 'csv') {
            const headers = ['x', 'y', 'intensity', 'eventType', 'timestamp'];
            const rows = points.map(point => [
                point.x,
                point.y,
                point.intensity,
                point.eventType,
                new Date(point.timestamp).toISOString()
            ]);

            return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
        }

        return JSON.stringify(points, null, 2);
    }

    private async loadHeatmapData(): Promise<void> {
        const data = await this.storageService.retrieve('heatmap_data');
        if (Array.isArray(data)) {
            this.heatmapPoints = data;
            this.heatmapSubject.next([...this.heatmapPoints]);
        }
    }

    private async saveHeatmapData(): Promise<void> {
        await this.storageService.store('heatmap_data', this.heatmapPoints);
    }

    destroy(): void {
        this.stopTracking();
    }
}
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { 
    ConsentInfo, 
    ConsentCategory, 
    ConsentMethod, 
    PrivacySettings,
    DataSubjectRequest,
    ComplianceReport
} from '../models';
import { StorageService } from '../storage/storage.service';

@Injectable({
    providedIn: 'root'
})
export class ConsentService {
    private consentSubject = new BehaviorSubject<ConsentInfo | null>(null);
    private privacySettingsSubject = new BehaviorSubject<PrivacySettings | null>(null);
    
    public consent$ = this.consentSubject.asObservable();
    public privacySettings$ = this.privacySettingsSubject.asObservable();

    private defaultCategories: ConsentCategory[] = [
        {
            id: 'necessary',
            name: 'Necessary',
            description: 'Essential cookies required for basic site functionality',
            required: true,
            granted: true
        },
        {
            id: 'analytics',
            name: 'Analytics',
            description: 'Cookies used to understand how visitors interact with the website',
            required: false,
            granted: false
        },
        {
            id: 'marketing',
            name: 'Marketing',
            description: 'Cookies used for advertising and marketing purposes',
            required: false,
            granted: false
        },
        {
            id: 'personalization',
            name: 'Personalization',
            description: 'Cookies used to personalize content and user experience',
            required: false,
            granted: false
        }
    ];

    private defaultPrivacySettings: PrivacySettings = {
        anonymizeIp: true,
        anonymizeUserAgent: false,
        respectDoNotTrack: true,
        dataRetentionDays: 365,
        allowCrossSiteTracking: false,
        enableFingerprinting: false
    };

    constructor(private storageService: StorageService) {
        this.loadConsentInfo();
        this.loadPrivacySettings();
    }

    async grantConsent(
        categories: string[] = [],
        method: ConsentMethod = ConsentMethod.EXPLICIT,
        version: string = '1.0'
    ): Promise<void> {
        const consentCategories = this.defaultCategories.map(category => ({
            ...category,
            granted: category.required || categories.includes(category.id)
        }));

        const consentInfo: ConsentInfo = {
            granted: true,
            timestamp: Date.now(),
            version,
            categories: consentCategories,
            ipAddress: await this.getClientIP(),
            userAgent: navigator.userAgent,
            method
        };

        await this.storageService.store('consent_info', consentInfo);
        this.consentSubject.next(consentInfo);

        // Log consent event
        await this.logConsentEvent('granted', consentInfo);
    }

    async revokeConsent(): Promise<void> {
        const currentConsent = this.consentSubject.value;
        
        const consentInfo: ConsentInfo = {
            granted: false,
            timestamp: Date.now(),
            version: currentConsent?.version || '1.0',
            categories: this.defaultCategories.map(cat => ({
                ...cat,
                granted: cat.required // Only keep necessary cookies
            })),
            method: ConsentMethod.EXPLICIT
        };

        await this.storageService.store('consent_info', consentInfo);
        this.consentSubject.next(consentInfo);

        // Clear non-essential data
        await this.clearNonEssentialData();

        // Log consent event
        await this.logConsentEvent('revoked', consentInfo);
    }

    async updateConsentCategories(categories: string[]): Promise<void> {
        const currentConsent = this.consentSubject.value;
        if (!currentConsent) {
            throw new Error('No existing consent found');
        }

        const updatedCategories = currentConsent.categories.map(category => ({
            ...category,
            granted: category.required || categories.includes(category.id)
        }));

        const updatedConsent: ConsentInfo = {
            ...currentConsent,
            categories: updatedCategories,
            timestamp: Date.now()
        };

        await this.storageService.store('consent_info', updatedConsent);
        this.consentSubject.next(updatedConsent);

        // Log consent event
        await this.logConsentEvent('updated', updatedConsent);
    }

    getConsent(): ConsentInfo | null {
        return this.consentSubject.value;
    }

    hasConsent(categoryId?: string): boolean {
        const consent = this.consentSubject.value;
        if (!consent || !consent.granted) return false;

        if (categoryId) {
            const category = consent.categories.find(cat => cat.id === categoryId);
            return category?.granted || false;
        }

        return consent.granted;
    }

    getConsentCategories(): ConsentCategory[] {
        const consent = this.consentSubject.value;
        return consent?.categories || this.defaultCategories;
    }

    async updatePrivacySettings(settings: Partial<PrivacySettings>): Promise<void> {
        const currentSettings = this.privacySettingsSubject.value || this.defaultPrivacySettings;
        const updatedSettings = { ...currentSettings, ...settings };

        await this.storageService.store('privacy_settings', updatedSettings);
        this.privacySettingsSubject.next(updatedSettings);
    }

    getPrivacySettings(): PrivacySettings {
        return this.privacySettingsSubject.value || this.defaultPrivacySettings;
    }

    async submitDataSubjectRequest(request: Omit<DataSubjectRequest, 'requestDate' | 'status'>): Promise<string> {
        const requestId = this.generateRequestId();
        const fullRequest: DataSubjectRequest = {
            ...request,
            requestDate: Date.now(),
            status: 'pending'
        };

        // Store the request
        const existingRequests = await this.storageService.retrieve('data_subject_requests') || [];
        existingRequests.push({ id: requestId, ...fullRequest });
        await this.storageService.store('data_subject_requests', existingRequests);

        // Log the request
        await this.logDataSubjectRequest(requestId, fullRequest);

        return requestId;
    }

    async getDataSubjectRequests(): Promise<Array<DataSubjectRequest & { id: string }>> {
        return await this.storageService.retrieve('data_subject_requests') || [];
    }

    async processDataSubjectRequest(requestId: string, status: DataSubjectRequest['status'], reason?: string): Promise<void> {
        const requests = await this.getDataSubjectRequests();
        const requestIndex = requests.findIndex(req => req.id === requestId);
        
        if (requestIndex === -1) {
            throw new Error('Request not found');
        }

        requests[requestIndex].status = status;
        if (reason) {
            requests[requestIndex].reason = reason;
        }

        await this.storageService.store('data_subject_requests', requests);

        // Execute the request if approved
        if (status === 'completed') {
            await this.executeDataSubjectRequest(requests[requestIndex]);
        }
    }

    async generateComplianceReport(startDate: Date, endDate: Date): Promise<ComplianceReport> {
        const consentLogs = await this.getConsentLogs(startDate, endDate);
        const dataSubjectRequests = await this.getDataSubjectRequests();
        const filteredRequests = dataSubjectRequests.filter(req => 
            req.requestDate >= startDate.getTime() && req.requestDate <= endDate.getTime()
        );

        const totalUsers = new Set(consentLogs.map(log => log.userId || log.sessionId)).size;
        const consentedUsers = consentLogs.filter(log => log.action === 'granted').length;

        const requestsByType: Record<string, number> = {};
        filteredRequests.forEach(req => {
            requestsByType[req.type] = (requestsByType[req.type] || 0) + 1;
        });

        return {
            period: {
                start: startDate.getTime(),
                end: endDate.getTime()
            },
            totalUsers,
            consentedUsers,
            consentRate: totalUsers > 0 ? (consentedUsers / totalUsers) * 100 : 0,
            dataSubjectRequests: {
                total: filteredRequests.length,
                byType: requestsByType,
                processed: filteredRequests.filter(req => req.status === 'completed').length,
                pending: filteredRequests.filter(req => req.status === 'pending').length
            },
            dataRetention: {
                totalRecords: 0, // Would need to implement record counting
                expiredRecords: 0,
                deletedRecords: 0
            },
            violations: [] // Would need to implement violation tracking
        };
    }

    async checkConsentExpiry(): Promise<boolean> {
        const consent = this.consentSubject.value;
        if (!consent) return true;

        const expiryDays = 365; // Configurable
        const expiryTime = consent.timestamp + (expiryDays * 24 * 60 * 60 * 1000);
        
        return Date.now() > expiryTime;
    }

    async renewConsent(): Promise<void> {
        const currentConsent = this.consentSubject.value;
        if (!currentConsent) {
            throw new Error('No existing consent to renew');
        }

        const renewedConsent: ConsentInfo = {
            ...currentConsent,
            timestamp: Date.now(),
            method: ConsentMethod.EXPLICIT
        };

        await this.storageService.store('consent_info', renewedConsent);
        this.consentSubject.next(renewedConsent);

        await this.logConsentEvent('renewed', renewedConsent);
    }

    private async loadConsentInfo(): Promise<void> {
        const consent = await this.storageService.retrieve('consent_info');
        if (consent) {
            this.consentSubject.next(consent);
        }
    }

    private async loadPrivacySettings(): Promise<void> {
        const settings = await this.storageService.retrieve('privacy_settings');
        this.privacySettingsSubject.next(settings || this.defaultPrivacySettings);
    }

    private async logConsentEvent(action: string, consentInfo: ConsentInfo): Promise<void> {
        const log = {
            action,
            timestamp: Date.now(),
            consentInfo,
            userId: null, // Would be set if user is identified
            sessionId: this.generateSessionId()
        };

        const existingLogs = await this.storageService.retrieve('consent_logs') || [];
        existingLogs.push(log);
        
        // Keep only last 1000 logs
        if (existingLogs.length > 1000) {
            existingLogs.splice(0, existingLogs.length - 1000);
        }

        await this.storageService.store('consent_logs', existingLogs);
    }

    private async logDataSubjectRequest(requestId: string, request: DataSubjectRequest): Promise<void> {
        const log = {
            requestId,
            request,
            timestamp: Date.now()
        };

        const existingLogs = await this.storageService.retrieve('dsr_logs') || [];
        existingLogs.push(log);
        await this.storageService.store('dsr_logs', existingLogs);
    }

    private async getConsentLogs(startDate: Date, endDate: Date): Promise<any[]> {
        const logs = await this.storageService.retrieve('consent_logs') || [];
        return logs.filter((log: any) => 
            log.timestamp >= startDate.getTime() && log.timestamp <= endDate.getTime()
        );
    }

    private async clearNonEssentialData(): Promise<void> {
        // Clear analytics data
        const events = await this.storageService.retrieve('daf_tracker_events') || [];
        const essentialEvents = events.filter((event: any) => 
            event.eventCategory === 'essential' || event.eventType === 'error'
        );
        await this.storageService.store('daf_tracker_events', essentialEvents);

        // Clear other non-essential stored data
        await this.storageService.remove('analytics_cache');
        await this.storageService.remove('user_preferences');
    }

    private async executeDataSubjectRequest(request: DataSubjectRequest & { id: string }): Promise<void> {
        switch (request.type) {
            case 'erasure':
                await this.executeErasureRequest(request);
                break;
            case 'access':
                await this.executeAccessRequest(request);
                break;
            case 'portability':
                await this.executePortabilityRequest(request);
                break;
            // Add other request types as needed
        }
    }

    private async executeErasureRequest(request: DataSubjectRequest & { id: string }): Promise<void> {
        // Remove all data associated with the user
        if (request.userId) {
            const events = await this.storageService.retrieve('daf_tracker_events') || [];
            const filteredEvents = events.filter((event: any) => event.userId !== request.userId);
            await this.storageService.store('daf_tracker_events', filteredEvents);
        }

        if (request.sessionId) {
            const events = await this.storageService.retrieve('daf_tracker_events') || [];
            const filteredEvents = events.filter((event: any) => event.sessionId !== request.sessionId);
            await this.storageService.store('daf_tracker_events', filteredEvents);
        }
    }

    private async executeAccessRequest(request: DataSubjectRequest & { id: string }): Promise<void> {
        // Compile all data for the user
        const userData: any = {};

        if (request.userId) {
            const events = await this.storageService.retrieve('daf_tracker_events') || [];
            userData.events = events.filter((event: any) => event.userId === request.userId);
        }

        // Store the compiled data for retrieval
        await this.storageService.store(`access_request_${request.id}`, userData);
    }

    private async executePortabilityRequest(request: DataSubjectRequest & { id: string }): Promise<void> {
        // Similar to access request but in a portable format
        await this.executeAccessRequest(request);
    }

    private async getClientIP(): Promise<string | undefined> {
        try {
            // This would typically be done server-side
            // Client-side IP detection is limited and not reliable
            return undefined;
        } catch {
            return undefined;
        }
    }

    private generateRequestId(): string {
        return `dsr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    private generateSessionId(): string {
        return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
}
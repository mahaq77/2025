import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { map, filter } from 'rxjs/operators';

import { 
    TrackingEvent, 
    EventType, 
    AnalyticsData, 
    AnalyticsQuery, 
    AnalyticsResult,
    FunnelAnalysis,
    FunnelStep,
    CohortAnalysis,
    HeatmapData
} from '../models';
import { StorageService } from '../storage/storage.service';

@Injectable({
    providedIn: 'root'
})
export class AnalyticsService {
    private analyticsSubject = new BehaviorSubject<AnalyticsData | null>(null);
    public analytics$ = this.analyticsSubject.asObservable();

    constructor(private storageService: StorageService) {}

    async generateReport(query: AnalyticsQuery = {}): Promise<AnalyticsResult> {
        const startTime = Date.now();
        const events = await this.getEvents();
        const filteredEvents = this.filterEvents(events, query);
        const data = this.calculateAnalytics(filteredEvents, query);

        const result: AnalyticsResult = {
            query,
            data,
            generatedAt: Date.now()
        };

        this.analyticsSubject.next(data);
        return result;
    }

    async getFunnelAnalysis(steps: FunnelStep[]): Promise<FunnelAnalysis> {
        const events = await this.getEvents();
        const userJourneys = this.groupEventsByUser(events);
        
        const results: Array<{
            step: FunnelStep;
            users: number;
            conversionRate: number;
            dropoffRate: number;
        }> = [];

        steps.forEach((step, index) => {
            let users = 0;
            const previousStepUsers = index === 0 ? Object.keys(userJourneys).length : results[index - 1].users;

            Object.values(userJourneys).forEach((userEvents: TrackingEvent[]) => {
                const hasStep = userEvents.some(event => 
                    event.eventType === step.eventType &&
                    (!step.eventAction || event.eventAction === step.eventAction)
                );
                
                if (hasStep) {
                    users++;
                }
            });

            results.push({
                step,
                users,
                conversionRate: previousStepUsers > 0 ? (users / previousStepUsers) * 100 : 0,
                dropoffRate: previousStepUsers > 0 ? ((previousStepUsers - users) / previousStepUsers) * 100 : 0
            });
        });

        const totalUsers = Object.keys(userJourneys).length;
        const finalStepUsers = results[results.length - 1]?.users || 0;

        return {
            steps,
            results,
            totalUsers,
            overallConversionRate: totalUsers > 0 ? (finalStepUsers / totalUsers) * 100 : 0,
            generatedAt: Date.now()
        };
    }

    async getCohortAnalysis(cohortType: 'daily' | 'weekly' | 'monthly', periods: number = 12): Promise<CohortAnalysis> {
        const events = await this.getEvents();
        const userFirstSeen = new Map<string, number>();
        
        // Find first seen date for each user
        events.forEach(event => {
            if (event.userId && (!userFirstSeen.has(event.userId) || event.timestamp < userFirstSeen.get(event.userId)!)) {
                userFirstSeen.set(event.userId, event.timestamp);
            }
        });

        const cohorts = new Map<string, Set<string>>();
        const cohortData: Array<{ cohort: string; size: number; retention: number[] }> = [];

        // Group users by cohort
        userFirstSeen.forEach((firstSeen, userId) => {
            const cohortKey = this.getCohortKey(firstSeen, cohortType);
            if (!cohorts.has(cohortKey)) {
                cohorts.set(cohortKey, new Set());
            }
            cohorts.get(cohortKey)!.add(userId);
        });

        // Calculate retention for each cohort
        cohorts.forEach((users, cohortKey) => {
            const retention: number[] = [];
            const cohortStart = this.parseCohortKey(cohortKey, cohortType);
            
            for (let period = 0; period < periods; period++) {
                const periodStart = this.addPeriod(cohortStart, period, cohortType);
                const periodEnd = this.addPeriod(periodStart, 1, cohortType);
                
                const activeUsers = new Set<string>();
                events.forEach(event => {
                    if (event.userId && 
                        users.has(event.userId) && 
                        event.timestamp >= periodStart && 
                        event.timestamp < periodEnd) {
                        activeUsers.add(event.userId);
                    }
                });
                
                retention.push((activeUsers.size / users.size) * 100);
            }
            
            cohortData.push({
                cohort: cohortKey,
                size: users.size,
                retention
            });
        });

        return {
            cohorts: cohortData.map(item => ({
                cohortId: item.cohort,
                period: cohortType,
                users: item.size,
                retention: item.retention.reduce((acc, rate, index) => {
                    acc[`period_${index}`] = rate;
                    return acc;
                }, {} as Record<string, number>)
            })).sort((a, b) => a.cohortId.localeCompare(b.cohortId)),
            generatedAt: Date.now()
        };
    }

    async getHeatmapData(selector?: string): Promise<HeatmapData[]> {
        const events = await this.getEvents();
        const elementInteractions = new Map<string, {
            clicks: number;
            hovers: number;
            views: number;
            element: string;
            selector: string;
            positions: Array<{ x: number; y: number; width: number; height: number }>;
        }>();

        events.forEach(event => {
            if (event.customData && event.customData['elementInfo']) {
                const elementInfo = event.customData['elementInfo'];
                const elementSelector = elementInfo.id ? `#${elementInfo.id}` : 
                                     elementInfo.className ? `.${elementInfo.className.split(' ').join('.')}` :
                                     elementInfo.tagName;

                if (selector && !elementSelector.includes(selector)) {
                    return;
                }

                if (!elementInteractions.has(elementSelector)) {
                    elementInteractions.set(elementSelector, {
                        clicks: 0,
                        hovers: 0,
                        views: 0,
                        element: elementInfo.tagName,
                        selector: elementSelector,
                        positions: []
                    });
                }

                const interaction = elementInteractions.get(elementSelector)!;
                
                switch (event.eventType) {
                    case EventType.CLICK:
                        interaction.clicks++;
                        break;
                    case EventType.HOVER:
                        interaction.hovers++;
                        break;
                    case EventType.VIEW:
                        interaction.views++;
                        break;
                }

                if (elementInfo.position && elementInfo.size) {
                    interaction.positions.push({
                        x: elementInfo.position.x,
                        y: elementInfo.position.y,
                        width: elementInfo.size.width,
                        height: elementInfo.size.height
                    });
                }
            }
        });

        return Array.from(elementInteractions.entries()).map(([selector, data]) => {
            // Calculate average position
            const avgPosition = data.positions.length > 0 ? {
                x: data.positions.reduce((sum, pos) => sum + pos.x, 0) / data.positions.length,
                y: data.positions.reduce((sum, pos) => sum + pos.y, 0) / data.positions.length,
                width: data.positions.reduce((sum, pos) => sum + pos.width, 0) / data.positions.length,
                height: data.positions.reduce((sum, pos) => sum + pos.height, 0) / data.positions.length
            } : { x: 0, y: 0, width: 0, height: 0 };

            return {
                element: data.element,
                selector: data.selector,
                clicks: data.clicks,
                hovers: data.hovers,
                views: data.views,
                position: avgPosition
            };
        });
    }

    async getTopPages(limit: number = 10): Promise<Array<{ page: string; views: number; uniqueUsers: number }>> {
        const events = await this.getEvents();
        const pageStats = new Map<string, { views: number; users: Set<string> }>();

        events.filter(e => e.eventType === EventType.VIEW).forEach(event => {
            const page = event.contentPage;
            if (!pageStats.has(page)) {
                pageStats.set(page, { views: 0, users: new Set() });
            }
            
            const stats = pageStats.get(page)!;
            stats.views++;
            if (event.userId) {
                stats.users.add(event.userId);
            }
        });

        return Array.from(pageStats.entries())
            .map(([page, stats]) => ({
                page,
                views: stats.views,
                uniqueUsers: stats.users.size
            }))
            .sort((a, b) => b.views - a.views)
            .slice(0, limit);
    }

    async getUserJourney(userId: string): Promise<TrackingEvent[]> {
        const events = await this.getEvents();
        return events
            .filter(event => event.userId === userId)
            .sort((a, b) => a.timestamp - b.timestamp);
    }

    async getSessionAnalytics(sessionId: string): Promise<{
        events: TrackingEvent[];
        duration: number;
        pageViews: number;
        interactions: number;
        bounceRate: boolean;
    }> {
        const events = await this.getEvents();
        const sessionEvents = events
            .filter(event => event.sessionId === sessionId)
            .sort((a, b) => a.timestamp - b.timestamp);

        if (sessionEvents.length === 0) {
            return {
                events: [],
                duration: 0,
                pageViews: 0,
                interactions: 0,
                bounceRate: true
            };
        }

        const duration = sessionEvents[sessionEvents.length - 1].timestamp - sessionEvents[0].timestamp;
        const pageViews = sessionEvents.filter(e => e.eventType === EventType.VIEW).length;
        const interactions = sessionEvents.filter(e => 
            [EventType.CLICK, EventType.FORM_SUBMIT, EventType.SCROLL].includes(e.eventType)
        ).length;

        return {
            events: sessionEvents,
            duration,
            pageViews,
            interactions,
            bounceRate: pageViews <= 1 && interactions === 0
        };
    }

    private async getEvents(): Promise<TrackingEvent[]> {
        const events = await this.storageService.retrieve('daf_tracker_events');
        return Array.isArray(events) ? events : [];
    }

    private filterEvents(events: TrackingEvent[], query: AnalyticsQuery): TrackingEvent[] {
        return events.filter(event => {
            if (query.startDate && event.timestamp < query.startDate.getTime()) return false;
            if (query.endDate && event.timestamp > query.endDate.getTime()) return false;
            if (query.eventTypes && !query.eventTypes.includes(event.eventType)) return false;
            if (query.eventCategories && !query.eventCategories.includes(event.eventCategory)) return false;
            if (query.userId && event.userId !== query.userId) return false;
            if (query.sessionId && event.sessionId !== query.sessionId) return false;
            
            return true;
        });
    }

    private calculateAnalytics(events: TrackingEvent[], query: AnalyticsQuery): AnalyticsData {
        const eventsByType: Record<string, number> = {};
        const eventsByCategory: Record<string, number> = {};
        const pages: Record<string, number> = {};
        const actions: Record<string, number> = {};
        const sessions = new Set<string>();
        const users = new Set<string>();
        const sessionDurations: number[] = [];

        // Group events by session to calculate durations
        const sessionEvents = new Map<string, TrackingEvent[]>();
        
        events.forEach(event => {
            eventsByType[event.eventType] = (eventsByType[event.eventType] || 0) + 1;
            eventsByCategory[event.eventCategory] = (eventsByCategory[event.eventCategory] || 0) + 1;
            pages[event.contentPage] = (pages[event.contentPage] || 0) + 1;
            actions[event.eventAction] = (actions[event.eventAction] || 0) + 1;
            sessions.add(event.sessionId);
            if (event.userId) users.add(event.userId);

            if (!sessionEvents.has(event.sessionId)) {
                sessionEvents.set(event.sessionId, []);
            }
            sessionEvents.get(event.sessionId)!.push(event);
        });

        // Calculate session durations
        sessionEvents.forEach(sessionEventList => {
            if (sessionEventList.length > 1) {
                sessionEventList.sort((a, b) => a.timestamp - b.timestamp);
                const duration = sessionEventList[sessionEventList.length - 1].timestamp - sessionEventList[0].timestamp;
                sessionDurations.push(duration);
            }
        });

        const averageSessionDuration = sessionDurations.length > 0 
            ? sessionDurations.reduce((sum, duration) => sum + duration, 0) / sessionDurations.length 
            : 0;

        const topPages = Object.entries(pages)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([page, count]) => ({ 
                page, 
                count, 
                percentage: (count / events.length) * 100 
            }));

        const topActions = Object.entries(actions)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([action, count]) => ({ 
                action, 
                count, 
                percentage: (count / events.length) * 100 
            }));

        // Generate trends if we have enough data
        const trends = this.generateTrends(events);

        return {
            totalEvents: events.length,
            eventsByType: eventsByType as any,
            eventsByCategory,
            uniqueUsers: users.size,
            uniqueSessions: sessions.size,
            averageSessionDuration,
            topPages,
            topActions,
            timeRange: {
                start: events.length > 0 ? Math.min(...events.map(e => e.timestamp)) : 0,
                end: events.length > 0 ? Math.max(...events.map(e => e.timestamp)) : 0
            },
            trends
        };
    }

    private generateTrends(events: TrackingEvent[]): any {
        if (events.length === 0) return undefined;

        const daily = new Map<string, number>();
        const hourly = new Map<number, number>();

        events.forEach(event => {
            const date = new Date(event.timestamp);
            const dayKey = date.toISOString().split('T')[0];
            const hour = date.getHours();

            daily.set(dayKey, (daily.get(dayKey) || 0) + 1);
            hourly.set(hour, (hourly.get(hour) || 0) + 1);
        });

        return {
            daily: Array.from(daily.entries())
                .sort(([a], [b]) => a.localeCompare(b))
                .map(([date, count]) => ({ date, count })),
            hourly: Array.from(hourly.entries())
                .sort(([a], [b]) => a - b)
                .map(([hour, count]) => ({ hour, count }))
        };
    }

    private groupEventsByUser(events: TrackingEvent[]): Record<string, TrackingEvent[]> {
        const userEvents: Record<string, TrackingEvent[]> = {};
        
        events.forEach(event => {
            if (event.userId) {
                if (!userEvents[event.userId]) {
                    userEvents[event.userId] = [];
                }
                userEvents[event.userId].push(event);
            }
        });

        return userEvents;
    }

    private getCohortKey(timestamp: number, cohortType: 'daily' | 'weekly' | 'monthly'): string {
        const date = new Date(timestamp);
        
        switch (cohortType) {
            case 'daily':
                return date.toISOString().split('T')[0];
            case 'weekly':
                const weekStart = new Date(date);
                weekStart.setDate(date.getDate() - date.getDay());
                return weekStart.toISOString().split('T')[0];
            case 'monthly':
                return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            default:
                return date.toISOString().split('T')[0];
        }
    }

    private parseCohortKey(cohortKey: string, cohortType: 'daily' | 'weekly' | 'monthly'): number {
        switch (cohortType) {
            case 'daily':
            case 'weekly':
                return new Date(cohortKey).getTime();
            case 'monthly':
                const [year, month] = cohortKey.split('-');
                return new Date(parseInt(year), parseInt(month) - 1, 1).getTime();
            default:
                return new Date(cohortKey).getTime();
        }
    }

    private addPeriod(timestamp: number, periods: number, cohortType: 'daily' | 'weekly' | 'monthly'): number {
        const date = new Date(timestamp);
        
        switch (cohortType) {
            case 'daily':
                date.setDate(date.getDate() + periods);
                break;
            case 'weekly':
                date.setDate(date.getDate() + (periods * 7));
                break;
            case 'monthly':
                date.setMonth(date.getMonth() + periods);
                break;
        }
        
        return date.getTime();
    }
}
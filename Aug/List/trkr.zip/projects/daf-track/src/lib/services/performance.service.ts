import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, fromEvent } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';

import { PerformanceMetrics, TrackingEvent, EventType } from '../models';
import { StorageService } from '../storage/storage.service';

@Injectable({
    providedIn: 'root'
})
export class PerformanceService {
    private metricsSubject = new BehaviorSubject<PerformanceMetrics | null>(null);
    public metrics$ = this.metricsSubject.asObservable();

    private observer?: PerformanceObserver;
    private vitalsData: Map<string, number> = new Map();

    constructor(private storageService: StorageService) {
        this.initializePerformanceTracking();
    }

    private initializePerformanceTracking(): void {
        if (typeof window === 'undefined' || !window.performance) {
            return;
        }

        // Track basic navigation timing
        this.trackNavigationTiming();

        // Track Core Web Vitals
        this.trackCoreWebVitals();

        // Track resource loading
        this.trackResourceTiming();

        // Track long tasks
        this.trackLongTasks();
    }

    private trackNavigationTiming(): void {
        window.addEventListener('load', () => {
            setTimeout(() => {
                const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
                if (navigation) {
                    const metrics = this.calculateNavigationMetrics(navigation);
                    this.metricsSubject.next(metrics);
                    this.storeMetrics(metrics);
                }
            }, 0);
        });
    }

    private trackCoreWebVitals(): void {
        // Largest Contentful Paint (LCP)
        this.observePerformanceEntries('largest-contentful-paint', (entries) => {
            const lastEntry = entries[entries.length - 1] as any;
            this.vitalsData.set('lcp', lastEntry.startTime);
        });

        // First Input Delay (FID)
        this.observePerformanceEntries('first-input', (entries) => {
            const firstEntry = entries[0] as any;
            this.vitalsData.set('fid', firstEntry.processingStart - firstEntry.startTime);
        });

        // Cumulative Layout Shift (CLS)
        this.observePerformanceEntries('layout-shift', (entries) => {
            let clsValue = 0;
            entries.forEach((entry: any) => {
                if (!entry.hadRecentInput) {
                    clsValue += entry.value;
                }
            });
            this.vitalsData.set('cls', clsValue);
        });

        // First Contentful Paint (FCP)
        this.observePerformanceEntries('paint', (entries) => {
            entries.forEach((entry: any) => {
                if (entry.name === 'first-contentful-paint') {
                    this.vitalsData.set('fcp', entry.startTime);
                }
            });
        });
    }

    private trackResourceTiming(): void {
        this.observePerformanceEntries('resource', (entries) => {
            entries.forEach((entry: any) => {
                this.analyzeResourcePerformance(entry);
            });
        });
    }

    private trackLongTasks(): void {
        this.observePerformanceEntries('longtask', (entries) => {
            entries.forEach((entry: any) => {
                this.recordLongTask(entry);
            });
        });
    }

    private observePerformanceEntries(entryType: string, callback: (entries: PerformanceEntry[]) => void): void {
        try {
            if ('PerformanceObserver' in window) {
                const observer = new PerformanceObserver((list) => {
                    callback(list.getEntries());
                });
                observer.observe({ entryTypes: [entryType] });
            }
        } catch (error) {
            console.warn(`Failed to observe ${entryType}:`, error);
        }
    }

    private calculateNavigationMetrics(navigation: PerformanceNavigationTiming): PerformanceMetrics {
        const paint = performance.getEntriesByType('paint');
        
        return {
            loadTime: navigation.loadEventEnd - navigation.loadEventStart,
            domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
            firstPaint: paint.find(p => p.name === 'first-paint')?.startTime || 0,
            firstContentfulPaint: this.vitalsData.get('fcp') || 0,
            largestContentfulPaint: this.vitalsData.get('lcp') || 0,
            cumulativeLayoutShift: this.vitalsData.get('cls') || 0,
            firstInputDelay: this.vitalsData.get('fid') || 0
        };
    }

    private analyzeResourcePerformance(entry: PerformanceResourceTiming): void {
        const resourceData = {
            name: entry.name,
            type: this.getResourceType(entry.name),
            duration: entry.duration,
            size: entry.transferSize || 0,
            cached: entry.transferSize === 0 && entry.decodedBodySize > 0,
            timing: {
                dns: entry.domainLookupEnd - entry.domainLookupStart,
                tcp: entry.connectEnd - entry.connectStart,
                ssl: entry.secureConnectionStart > 0 ? entry.connectEnd - entry.secureConnectionStart : 0,
                ttfb: entry.responseStart - entry.requestStart,
                download: entry.responseEnd - entry.responseStart
            }
        };

        // Store resource performance data
        this.storeResourceData(resourceData);

        // Check for performance issues
        this.checkResourcePerformanceIssues(resourceData);
    }

    private recordLongTask(entry: PerformanceEntry): void {
        const longTaskData = {
            startTime: entry.startTime,
            duration: entry.duration,
            name: entry.name,
            timestamp: Date.now()
        };

        this.storeLongTaskData(longTaskData);
    }

    private getResourceType(url: string): string {
        const extension = url.split('.').pop()?.toLowerCase();
        
        if (['js', 'mjs'].includes(extension || '')) return 'script';
        if (['css'].includes(extension || '')) return 'stylesheet';
        if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension || '')) return 'image';
        if (['woff', 'woff2', 'ttf', 'otf'].includes(extension || '')) return 'font';
        if (url.includes('api/') || url.includes('/api/')) return 'xhr';
        
        return 'other';
    }

    private checkResourcePerformanceIssues(resourceData: any): void {
        const issues: string[] = [];

        // Check for slow resources
        if (resourceData.duration > 3000) {
            issues.push('slow_loading');
        }

        // Check for large resources
        if (resourceData.size > 1024 * 1024) { // 1MB
            issues.push('large_size');
        }

        // Check for slow DNS
        if (resourceData.timing.dns > 200) {
            issues.push('slow_dns');
        }

        // Check for slow TTFB
        if (resourceData.timing.ttfb > 600) {
            issues.push('slow_ttfb');
        }

        if (issues.length > 0) {
            this.recordPerformanceIssue({
                type: 'resource_performance',
                resource: resourceData.name,
                issues,
                timestamp: Date.now()
            });
        }
    }

    async getPerformanceReport(): Promise<{
        metrics: PerformanceMetrics | null;
        resources: any[];
        longTasks: any[];
        issues: any[];
        score: number;
    }> {
        const metrics = this.metricsSubject.value;
        const resources = await this.getStoredResourceData();
        const longTasks = await this.getStoredLongTaskData();
        const issues = await this.getStoredPerformanceIssues();
        const score = this.calculatePerformanceScore(metrics);

        return {
            metrics,
            resources,
            longTasks,
            issues,
            score
        };
    }

    async getResourceAnalysis(): Promise<{
        totalResources: number;
        totalSize: number;
        averageLoadTime: number;
        resourcesByType: Record<string, number>;
        slowestResources: Array<{ name: string; duration: number }>;
        largestResources: Array<{ name: string; size: number }>;
    }> {
        const resources = await this.getStoredResourceData();
        
        const totalResources = resources.length;
        const totalSize = resources.reduce((sum, r) => sum + r.size, 0);
        const averageLoadTime = resources.length > 0 
            ? resources.reduce((sum, r) => sum + r.duration, 0) / resources.length 
            : 0;

        const resourcesByType: Record<string, number> = {};
        resources.forEach(r => {
            resourcesByType[r.type] = (resourcesByType[r.type] || 0) + 1;
        });

        const slowestResources = resources
            .sort((a, b) => b.duration - a.duration)
            .slice(0, 10)
            .map(r => ({ name: r.name, duration: r.duration }));

        const largestResources = resources
            .sort((a, b) => b.size - a.size)
            .slice(0, 10)
            .map(r => ({ name: r.name, size: r.size }));

        return {
            totalResources,
            totalSize,
            averageLoadTime,
            resourcesByType,
            slowestResources,
            largestResources
        };
    }

    async getCoreWebVitalsHistory(): Promise<Array<{
        timestamp: number;
        lcp: number;
        fid: number;
        cls: number;
        fcp: number;
    }>> {
        return await this.storageService.retrieve('core_web_vitals_history') || [];
    }

    private calculatePerformanceScore(metrics: PerformanceMetrics | null): number {
        if (!metrics) return 0;

        let score = 100;

        // LCP scoring (0-2.5s = good, 2.5-4s = needs improvement, >4s = poor)
        if (metrics.largestContentfulPaint > 4000) score -= 30;
        else if (metrics.largestContentfulPaint > 2500) score -= 15;

        // FID scoring (0-100ms = good, 100-300ms = needs improvement, >300ms = poor)
        if (metrics.firstInputDelay > 300) score -= 25;
        else if (metrics.firstInputDelay > 100) score -= 10;

        // CLS scoring (0-0.1 = good, 0.1-0.25 = needs improvement, >0.25 = poor)
        if (metrics.cumulativeLayoutShift > 0.25) score -= 25;
        else if (metrics.cumulativeLayoutShift > 0.1) score -= 10;

        // FCP scoring (0-1.8s = good, 1.8-3s = needs improvement, >3s = poor)
        if (metrics.firstContentfulPaint > 3000) score -= 20;
        else if (metrics.firstContentfulPaint > 1800) score -= 10;

        return Math.max(0, score);
    }

    private async storeMetrics(metrics: PerformanceMetrics): Promise<void> {
        await this.storageService.store('performance_metrics', metrics);
        
        // Store historical data
        const history = await this.getCoreWebVitalsHistory();
        history.push({
            timestamp: Date.now(),
            lcp: metrics.largestContentfulPaint,
            fid: metrics.firstInputDelay,
            cls: metrics.cumulativeLayoutShift,
            fcp: metrics.firstContentfulPaint
        });

        // Keep only last 100 entries
        if (history.length > 100) {
            history.splice(0, history.length - 100);
        }

        await this.storageService.store('core_web_vitals_history', history);
    }

    private async storeResourceData(resourceData: any): Promise<void> {
        const resources = await this.getStoredResourceData();
        resources.push(resourceData);

        // Keep only last 500 resources
        if (resources.length > 500) {
            resources.splice(0, resources.length - 500);
        }

        await this.storageService.store('resource_performance', resources);
    }

    private async storeLongTaskData(longTaskData: any): Promise<void> {
        const longTasks = await this.getStoredLongTaskData();
        longTasks.push(longTaskData);

        // Keep only last 100 long tasks
        if (longTasks.length > 100) {
            longTasks.splice(0, longTasks.length - 100);
        }

        await this.storageService.store('long_tasks', longTasks);
    }

    private async recordPerformanceIssue(issue: any): Promise<void> {
        const issues = await this.getStoredPerformanceIssues();
        issues.push(issue);

        // Keep only last 200 issues
        if (issues.length > 200) {
            issues.splice(0, issues.length - 200);
        }

        await this.storageService.store('performance_issues', issues);
    }

    private async getStoredResourceData(): Promise<any[]> {
        return await this.storageService.retrieve('resource_performance') || [];
    }

    private async getStoredLongTaskData(): Promise<any[]> {
        return await this.storageService.retrieve('long_tasks') || [];
    }

    private async getStoredPerformanceIssues(): Promise<any[]> {
        return await this.storageService.retrieve('performance_issues') || [];
    }

    destroy(): void {
        if (this.observer) {
            this.observer.disconnect();
        }
    }
}
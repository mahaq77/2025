import { Injectable, Inject, Optional } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { BehaviorSubject, Observable, Subject, fromEvent, merge, timer } from 'rxjs';
import { debounceTime, throttleTime, filter, map, takeUntil } from 'rxjs/operators';

import { 
    TrackingEvent, 
    EventType, 
    DafTrackerConfig, 
    StorageType, 
    ViewportInfo,
    PerformanceMetrics,
    ErrorInfo,
    ConsentInfo,
    ConsentCategory,
    ConsentMethod,
    AnalyticsData
} from './models/daf-tracker-interface';
import { StorageService } from './storage/storage.service';

// Default configuration
const DEFAULT_CONFIG: DafTrackerConfig = {
    enabled: true,
    debug: false,
    storageType: StorageType.LOCAL_STORAGE,
    storageKey: 'daf_tracker_events',
    maxStorageSize: 10000,
    respectDoNotTrack: true,
    requireConsent: false,
    anonymizeData: false,
    sampleRate: 1.0,
    excludeEvents: [],
    includeEvents: [],
    batchSize: 50,
    batchTimeout: 5000,
    customFields: {}
};

@Injectable({
    providedIn: 'root'
})
export class DafTracker {
    private config: DafTrackerConfig;
    private sessionId: string;
    private deviceId: string;
    private userId?: string;
    private consentInfo?: ConsentInfo;
    
    private defaultCategories: ConsentCategory[] = [
        {
            id: 'necessary',
            name: 'Necessary',
            description: 'Essential cookies required for basic site functionality',
            required: true,
            granted: true
        },
        {
            id: 'analytics',
            name: 'Analytics',
            description: 'Cookies used to understand how visitors interact with the website',
            required: false,
            granted: false
        },
        {
            id: 'marketing',
            name: 'Marketing',
            description: 'Cookies used for advertising and marketing purposes',
            required: false,
            granted: false
        }
    ];
    
    private eventQueue: TrackingEvent[] = [];
    private batchTimer?: any;
    private destroy$ = new Subject<void>();
    
    // Observables
    private eventSubject = new Subject<TrackingEvent>();
    private configSubject = new BehaviorSubject<DafTrackerConfig>(DEFAULT_CONFIG);
    private consentSubject = new BehaviorSubject<boolean>(false);
    
    public events$ = this.eventSubject.asObservable();
    public config$ = this.configSubject.asObservable();
    public consent$ = this.consentSubject.asObservable();

    constructor(
        private storageService: StorageService,
        @Inject(DOCUMENT) private document: Document,
        @Optional() @Inject('DAF_TRACKER_CONFIG') config?: Partial<DafTrackerConfig>
    ) {
        this.config = { ...DEFAULT_CONFIG, ...config };
        this.sessionId = this.generateSessionId();
        this.deviceId = this.getOrCreateDeviceId();
        
        this.initialize();
    }

    private async initialize(): Promise<void> {
        // Configure storage
        this.storageService.setProvider(this.config.storageType);
        
        // Check for existing consent
        await this.loadConsentInfo();
        
        // Set up automatic event listeners if enabled
        if (this.config.enabled && this.hasConsent()) {
            this.setupAutoTracking();
            this.setupPerformanceTracking();
            this.setupErrorTracking();
        }
        
        // Set up batch processing
        this.setupBatchProcessing();
        
        // Load existing events from storage
        await this.loadEventsFromStorage();
        
        if (this.config.debug) {
            console.log('DafTracker initialized', {
                sessionId: this.sessionId,
                deviceId: this.deviceId,
                config: this.config
            });
        }
    }

    // Configuration methods
    configure(config: Partial<DafTrackerConfig>): void {
        this.config = { ...this.config, ...config };
        this.configSubject.next(this.config);
        
        if (config.storageType) {
            this.storageService.setProvider(config.storageType);
        }
        
        if (this.config.debug) {
            console.log('DafTracker configuration updated', this.config);
        }
    }

    getConfig(): DafTrackerConfig {
        return { ...this.config };
    }

    // Consent management
    async setConsent(granted: boolean, categories: string[] = [], version: string = '1.0'): Promise<void> {
        this.consentInfo = {
            granted,
            timestamp: Date.now(),
            version,
            categories: this.defaultCategories.map(cat => ({
                ...cat,
                granted: cat.required || categories.includes(cat.id)
            })),
            method: ConsentMethod.EXPLICIT
        };
        
        await this.storageService.store('consent_info', this.consentInfo);
        this.consentSubject.next(granted);
        
        if (granted && this.config.enabled) {
            this.setupAutoTracking();
        } else if (!granted) {
            this.stopAutoTracking();
        }
        
        if (this.config.debug) {
            console.log('Consent updated', this.consentInfo);
        }
    }

    getConsent(): ConsentInfo | undefined {
        return this.consentInfo;
    }

    hasConsent(): boolean {
        if (!this.config.requireConsent) return true;
        return this.consentInfo?.granted || false;
    }

    // User identification
    setUserId(userId: string): void {
        this.userId = userId;
        if (this.config.debug) {
            console.log('User ID set', userId);
        }
    }

    getUserId(): string | undefined {
        return this.userId;
    }

    // Core tracking methods
    async track(
        eventType: EventType,
        eventAction: string,
        options: Partial<TrackingEvent> = {}
    ): Promise<void> {
        if (!this.shouldTrack(eventType)) {
            return;
        }

        const event: TrackingEvent = {
            eventId: this.generateEventId(),
            eventCategory: options.eventCategory || 'user_interaction',
            eventType,
            eventAction,
            eventLabel: options.eventLabel,
            contentType: options.contentType,
            contentId: options.contentId,
            contentPage: this.getCurrentPage(),
            contentTitle: this.document.title,
            sessionId: this.sessionId,
            userId: this.userId,
            deviceId: this.deviceId,
            timestamp: Date.now(),
            duration: options.duration,
            url: window.location.href,
            referrer: this.document.referrer,
            userAgent: navigator.userAgent,
            viewport: this.getViewportInfo(),
            customData: options.customData,
            consentGiven: this.hasConsent(),
            anonymized: this.config.anonymizeData,
            ...options
        };

        // Anonymize data if required
        if (this.config.anonymizeData) {
            this.anonymizeEvent(event);
        }

        // Add to queue
        this.eventQueue.push(event);
        this.eventSubject.next(event);

        // Process batch if needed
        if (this.eventQueue.length >= this.config.batchSize) {
            await this.processBatch();
        }

        if (this.config.debug) {
            console.log('Event tracked', event);
        }
    }

    // Convenience methods for common events
    async trackClick(element: Element, customData?: any): Promise<void> {
        const selector = this.getElementSelector(element);
        await this.track(EventType.CLICK, 'click', {
            eventLabel: selector,
            contentId: element.id || undefined,
            customData: {
                tagName: element.tagName.toLowerCase(),
                className: element.className,
                textContent: element.textContent?.substring(0, 100),
                ...customData
            }
        });
    }

    async trackView(page?: string, customData?: any): Promise<void> {
        await this.track(EventType.VIEW, 'page_view', {
            contentPage: page || this.getCurrentPage(),
            customData
        });
    }

    async trackScroll(scrollPercentage: number, customData?: any): Promise<void> {
        await this.track(EventType.SCROLL, 'scroll', {
            eventLabel: `${scrollPercentage}%`,
            customData: {
                scrollPercentage,
                ...customData
            }
        });
    }

    async trackFormSubmit(formElement: HTMLFormElement, customData?: any): Promise<void> {
        const formData = new FormData(formElement);
        const fields: Record<string, any> = {};
        
        formData.forEach((value, key) => {
            // Don't track sensitive data
            if (!this.isSensitiveField(key)) {
                fields[key] = typeof value === 'string' ? value.substring(0, 100) : value;
            }
        });

        await this.track(EventType.FORM_SUBMIT, 'form_submit', {
            contentId: formElement.id || undefined,
            eventLabel: formElement.name || 'unnamed_form',
            customData: {
                formFields: Object.keys(fields),
                fieldCount: Object.keys(fields).length,
                ...customData
            }
        });
    }

    async trackError(error: Error | ErrorInfo, customData?: any): Promise<void> {
        const errorInfo: ErrorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack,
            type: 'javascript'
        } : error;

        await this.track(EventType.ERROR, 'error', {
            eventLabel: errorInfo.message,
            customData: {
                ...errorInfo,
                ...customData
            }
        });
    }

    async trackCustom(action: string, category?: string, customData?: any): Promise<void> {
        await this.track(EventType.CUSTOM, action, {
            eventCategory: category || 'custom',
            customData
        });
    }

    // Analytics and reporting
    async getAnalytics(options: {
        startDate?: Date;
        endDate?: Date;
        eventTypes?: EventType[];
    } = {}): Promise<AnalyticsData> {
        const events = await this.getStoredEvents();
        const filteredEvents = this.filterEvents(events, options);
        
        return this.calculateAnalytics(filteredEvents);
    }

    async exportData(format: 'json' | 'csv' = 'json'): Promise<string> {
        const events = await this.getStoredEvents();
        
        if (format === 'csv') {
            return this.convertToCSV(events);
        }
        
        return JSON.stringify(events, null, 2);
    }

    // Storage management
    async clearData(): Promise<void> {
        this.eventQueue = [];
        await this.storageService.clear();
        
        if (this.config.debug) {
            console.log('All tracking data cleared');
        }
    }

    async getStorageStats(): Promise<any> {
        return this.storageService.getStats();
    }

    // Lifecycle methods
    destroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
        
        if (this.batchTimer) {
            clearTimeout(this.batchTimer);
        }
        
        // Process remaining events
        if (this.eventQueue.length > 0) {
            this.processBatch();
        }
    }

    // Private methods
    private shouldTrack(eventType: EventType): boolean {
        if (!this.config.enabled) return false;
        if (!this.hasConsent()) return false;
        if (this.config.respectDoNotTrack && navigator.doNotTrack === '1') return false;
        if (Math.random() > this.config.sampleRate) return false;
        
        if (this.config.includeEvents.length > 0) {
            return this.config.includeEvents.includes(eventType);
        }
        
        return !this.config.excludeEvents.includes(eventType);
    }

    private setupAutoTracking(): void {
        if (typeof window === 'undefined') return;

        // Page visibility changes
        fromEvent(this.document, 'visibilitychange')
            .pipe(takeUntil(this.destroy$))
            .subscribe(() => {
                const action = this.document.hidden ? 'page_hidden' : 'page_visible';
                this.track(EventType.VIEW, action);
            });

        // Page unload
        fromEvent(window, 'beforeunload')
            .pipe(takeUntil(this.destroy$))
            .subscribe(() => {
                this.track(EventType.PAGE_UNLOAD, 'page_unload');
                this.processBatch(); // Force process remaining events
            });

        // Scroll tracking
        fromEvent(window, 'scroll')
            .pipe(
                throttleTime(1000),
                takeUntil(this.destroy$)
            )
            .subscribe(() => {
                const scrollPercentage = this.getScrollPercentage();
                this.trackScroll(scrollPercentage);
            });

        // Click tracking (delegated)
        fromEvent(this.document, 'click')
            .pipe(
                debounceTime(100),
                takeUntil(this.destroy$)
            )
            .subscribe((event: Event) => {
                const target = event.target as Element;
                if (target && this.shouldTrackElement(target)) {
                    this.trackClick(target);
                }
            });
    }

    private stopAutoTracking(): void {
        this.destroy$.next();
    }

    private setupPerformanceTracking(): void {
        if (typeof window === 'undefined' || !window.performance) return;

        // Track page load performance
        window.addEventListener('load', () => {
            setTimeout(() => {
                const metrics = this.getPerformanceMetrics();
                this.track(EventType.PERFORMANCE, 'page_load_metrics', {
                    customData: metrics
                });
            }, 0);
        });
    }

    private setupErrorTracking(): void {
        if (typeof window === 'undefined') return;

        // JavaScript errors
        window.addEventListener('error', (event) => {
            this.trackError({
                message: event.message,
                filename: event.filename,
                lineno: event.lineno,
                colno: event.colno,
                stack: event.error?.stack,
                type: 'javascript'
            });
        });

        // Unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            this.trackError({
                message: `Unhandled promise rejection: ${event.reason}`,
                type: 'javascript'
            });
        });
    }

    private setupBatchProcessing(): void {
        this.batchTimer = setInterval(() => {
            if (this.eventQueue.length > 0) {
                this.processBatch();
            }
        }, this.config.batchTimeout);
    }

    private async processBatch(): Promise<void> {
        if (this.eventQueue.length === 0) return;

        const batch = this.eventQueue.splice(0, this.config.batchSize);
        
        try {
            // Store events
            await this.storeEvents(batch);
            
            // Send to API if configured
            if (this.config.apiEndpoint) {
                await this.sendToAPI(batch);
            }
            
            if (this.config.debug) {
                console.log(`Processed batch of ${batch.length} events`);
            }
        } catch (error) {
            // Re-add events to queue on failure
            this.eventQueue.unshift(...batch);
            
            if (this.config.debug) {
                console.error('Failed to process batch', error);
            }
        }
    }

    private async storeEvents(events: TrackingEvent[]): Promise<void> {
        const existingEvents = await this.getStoredEvents();
        const allEvents = [...existingEvents, ...events];
        
        // Limit storage size
        if (allEvents.length > this.config.maxStorageSize) {
            allEvents.splice(0, allEvents.length - this.config.maxStorageSize);
        }
        
        await this.storageService.store(this.config.storageKey, allEvents);
    }

    private async getStoredEvents(): Promise<TrackingEvent[]> {
        const events = await this.storageService.retrieve(this.config.storageKey);
        return Array.isArray(events) ? events : [];
    }

    private async loadEventsFromStorage(): Promise<void> {
        // This method can be used to load and process events on initialization
        const events = await this.getStoredEvents();
        if (this.config.debug && events.length > 0) {
            console.log(`Loaded ${events.length} events from storage`);
        }
    }

    private async loadConsentInfo(): Promise<void> {
        const consent = await this.storageService.retrieve('consent_info');
        if (consent) {
            this.consentInfo = consent;
            this.consentSubject.next(consent.granted);
        }
    }

    private async sendToAPI(events: TrackingEvent[]): Promise<void> {
        if (!this.config.apiEndpoint) return;

        const response = await fetch(this.config.apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                ...(this.config.apiKey && { 'Authorization': `Bearer ${this.config.apiKey}` })
            },
            body: JSON.stringify({ events })
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }
    }

    // Utility methods
    private generateSessionId(): string {
        return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    private generateEventId(): string {
        return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    private getOrCreateDeviceId(): string {
        const stored = localStorage.getItem('daf_tracker_device_id');
        if (stored) return stored;
        
        const deviceId = `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        localStorage.setItem('daf_tracker_device_id', deviceId);
        return deviceId;
    }

    private getCurrentPage(): string {
        return window.location.pathname;
    }

    private getViewportInfo(): ViewportInfo {
        return {
            width: window.innerWidth,
            height: window.innerHeight,
            scrollX: window.scrollX,
            scrollY: window.scrollY
        };
    }

    private getScrollPercentage(): number {
        const scrollTop = window.scrollY;
        const docHeight = this.document.documentElement.scrollHeight - window.innerHeight;
        return Math.round((scrollTop / docHeight) * 100);
    }

    private getElementSelector(element: Element): string {
        if (element.id) return `#${element.id}`;
        if (element.className) return `.${element.className.split(' ').join('.')}`;
        return element.tagName.toLowerCase();
    }

    private shouldTrackElement(element: Element): boolean {
        // Skip tracking for certain elements
        const skipTags = ['script', 'style', 'meta', 'link'];
        return !skipTags.includes(element.tagName.toLowerCase());
    }

    private isSensitiveField(fieldName: string): boolean {
        const sensitiveFields = ['password', 'ssn', 'credit', 'card', 'cvv', 'pin'];
        return sensitiveFields.some(field => fieldName.toLowerCase().includes(field));
    }

    private anonymizeEvent(event: TrackingEvent): void {
        if (event.userAgent) {
            event.userAgent = this.anonymizeUserAgent(event.userAgent);
        }
        
        // Remove or hash sensitive data
        delete event.userId;
        delete event.deviceId;
        
        if (event.customData) {
            event.customData = this.anonymizeCustomData(event.customData);
        }
    }

    private anonymizeUserAgent(userAgent: string): string {
        // Simple anonymization - remove version numbers
        return userAgent.replace(/\d+\.\d+\.\d+/g, 'x.x.x');
    }

    private anonymizeCustomData(data: any): any {
        // Simple anonymization for custom data
        const anonymized = { ...data };
        
        Object.keys(anonymized).forEach(key => {
            if (typeof anonymized[key] === 'string' && anonymized[key].length > 10) {
                anonymized[key] = anonymized[key].substring(0, 10) + '...';
            }
        });
        
        return anonymized;
    }

    private getPerformanceMetrics(): PerformanceMetrics {
        const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
        const paint = performance.getEntriesByType('paint');
        
        return {
            loadTime: navigation.loadEventEnd - navigation.loadEventStart,
            domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
            firstPaint: paint.find(p => p.name === 'first-paint')?.startTime || 0,
            firstContentfulPaint: paint.find(p => p.name === 'first-contentful-paint')?.startTime || 0,
            largestContentfulPaint: 0, // Would need additional implementation
            cumulativeLayoutShift: 0, // Would need additional implementation
            firstInputDelay: 0 // Would need additional implementation
        };
    }

    private filterEvents(events: TrackingEvent[], options: any): TrackingEvent[] {
        return events.filter(event => {
            if (options.startDate && event.timestamp < options.startDate.getTime()) return false;
            if (options.endDate && event.timestamp > options.endDate.getTime()) return false;
            if (options.eventTypes && !options.eventTypes.includes(event.eventType)) return false;
            return true;
        });
    }

    private calculateAnalytics(events: TrackingEvent[]): AnalyticsData {
        const eventsByType: Record<string, number> = {};
        const eventsByCategory: Record<string, number> = {};
        const pages: Record<string, number> = {};
        const actions: Record<string, number> = {};
        const sessions = new Set<string>();
        const users = new Set<string>();

        events.forEach(event => {
            eventsByType[event.eventType] = (eventsByType[event.eventType] || 0) + 1;
            eventsByCategory[event.eventCategory] = (eventsByCategory[event.eventCategory] || 0) + 1;
            pages[event.contentPage] = (pages[event.contentPage] || 0) + 1;
            actions[event.eventAction] = (actions[event.eventAction] || 0) + 1;
            sessions.add(event.sessionId);
            if (event.userId) users.add(event.userId);
        });

        const topPages = Object.entries(pages)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([page, count]) => ({ page, count, percentage: (count / events.length) * 100 }));

        const topActions = Object.entries(actions)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([action, count]) => ({ action, count, percentage: (count / events.length) * 100 }));

        return {
            totalEvents: events.length,
            eventsByType: eventsByType as any,
            eventsByCategory,
            uniqueUsers: users.size,
            uniqueSessions: sessions.size,
            averageSessionDuration: 0, // Would need session duration calculation
            topPages,
            topActions,
            timeRange: {
                start: Math.min(...events.map(e => e.timestamp)),
                end: Math.max(...events.map(e => e.timestamp))
            }
        };
    }

    private convertToCSV(events: TrackingEvent[]): string {
        if (events.length === 0) return '';
        
        const headers = Object.keys(events[0]).join(',');
        const rows = events.map(event => 
            Object.values(event).map(value => 
                typeof value === 'object' ? JSON.stringify(value) : String(value)
            ).join(',')
        );
        
        return [headers, ...rows].join('\n');
    }
}

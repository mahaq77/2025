import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { DafTracker } from './daf-tracker';
import { AnalyticsService } from './services/analytics.service';
import { ConsentService } from './services/consent.service';
import { AnalyticsData, ConsentInfo } from './models/daf-tracker-interface';

@Component({
  selector: 'lib-daf-track',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="daf-tracker-dashboard" *ngIf="showDashboard">
      <div class="daf-tracker-header">
        <h3>DAF Tracker Dashboard</h3>
        <button (click)="toggleDashboard()" class="close-btn">×</button>
      </div>
      
      <div class="daf-tracker-content">
        <!-- Consent Status -->
        <div class="consent-section" *ngIf="consentInfo">
          <h4>Consent Status</h4>
          <div class="consent-status" [class.granted]="consentInfo.granted">
            {{ consentInfo.granted ? 'Granted' : 'Not Granted' }}
          </div>
          <div class="consent-categories">
            <div *ngFor="let category of consentInfo.categories" 
                 class="category" 
                 [class.granted]="category.granted">
              {{ category.name }}: {{ category.granted ? 'Yes' : 'No' }}
            </div>
          </div>
        </div>

        <!-- Analytics Summary -->
        <div class="analytics-section" *ngIf="analyticsData">
          <h4>Analytics Summary</h4>
          <div class="stats-grid">
            <div class="stat">
              <span class="label">Total Events</span>
              <span class="value">{{ analyticsData.totalEvents }}</span>
            </div>
            <div class="stat">
              <span class="label">Unique Users</span>
              <span class="value">{{ analyticsData.uniqueUsers }}</span>
            </div>
            <div class="stat">
              <span class="label">Sessions</span>
              <span class="value">{{ analyticsData.uniqueSessions }}</span>
            </div>
            <div class="stat">
              <span class="label">Avg Session</span>
              <span class="value">{{ formatDuration(analyticsData.averageSessionDuration) }}</span>
            </div>
          </div>
        </div>

        <!-- Top Pages -->
        <div class="pages-section" *ngIf="analyticsData?.topPages?.length">
          <h4>Top Pages</h4>
          <div class="page-list">
            <div *ngFor="let page of analyticsData!.topPages.slice(0, 5)" class="page-item">
              <span class="page-name">{{ page.page }}</span>
              <span class="page-count">{{ page.count }}</span>
            </div>
          </div>
        </div>

        <!-- Actions -->
        <div class="actions-section">
          <button (click)="refreshData()" class="action-btn">Refresh Data</button>
          <button (click)="exportData()" class="action-btn">Export Data</button>
          <button (click)="clearData()" class="action-btn danger">Clear Data</button>
        </div>
      </div>
    </div>

    <!-- Toggle Button -->
    <button *ngIf="!showDashboard && showToggle" 
            (click)="toggleDashboard()" 
            class="dashboard-toggle">
      📊
    </button>
  `,
  styles: `
    .daf-tracker-dashboard {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 320px;
      max-height: 80vh;
      background: white;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      overflow: hidden;
    }

    .daf-tracker-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background: #f8f9fa;
      border-bottom: 1px solid #ddd;
    }

    .daf-tracker-header h3 {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
      color: #333;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 20px;
      cursor: pointer;
      color: #666;
      padding: 0;
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #333;
    }

    .daf-tracker-content {
      padding: 16px;
      max-height: calc(80vh - 60px);
      overflow-y: auto;
    }

    .consent-section, .analytics-section, .pages-section, .actions-section {
      margin-bottom: 20px;
    }

    .consent-section h4, .analytics-section h4, .pages-section h4 {
      margin: 0 0 8px 0;
      font-size: 14px;
      font-weight: 600;
      color: #333;
    }

    .consent-status {
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: 500;
      background: #f8d7da;
      color: #721c24;
      margin-bottom: 8px;
    }

    .consent-status.granted {
      background: #d4edda;
      color: #155724;
    }

    .consent-categories {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .category {
      font-size: 12px;
      color: #666;
    }

    .category.granted {
      color: #28a745;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    .stat {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 8px;
      background: #f8f9fa;
      border-radius: 4px;
    }

    .stat .label {
      font-size: 11px;
      color: #666;
      margin-bottom: 4px;
    }

    .stat .value {
      font-size: 16px;
      font-weight: 600;
      color: #333;
    }

    .page-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .page-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 4px 8px;
      background: #f8f9fa;
      border-radius: 4px;
      font-size: 12px;
    }

    .page-name {
      color: #333;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .page-count {
      color: #666;
      font-weight: 500;
      margin-left: 8px;
    }

    .actions-section {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .action-btn {
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      background: white;
      color: #333;
      font-size: 12px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .action-btn:hover {
      background: #f8f9fa;
    }

    .action-btn.danger {
      border-color: #dc3545;
      color: #dc3545;
    }

    .action-btn.danger:hover {
      background: #dc3545;
      color: white;
    }

    .dashboard-toggle {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #007bff;
      color: white;
      border: none;
      font-size: 20px;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      z-index: 9999;
      transition: all 0.2s;
    }

    .dashboard-toggle:hover {
      background: #0056b3;
      transform: scale(1.05);
    }
  `
})
export class DafTrack implements OnInit, OnDestroy {
  @Input() showDashboard: boolean = false;
  @Input() showToggle: boolean = true;
  @Input() autoRefresh: boolean = true;
  @Input() refreshInterval: number = 30000; // 30 seconds

  analyticsData: AnalyticsData | null = null;
  consentInfo: ConsentInfo | null = null;
  
  private destroy$ = new Subject<void>();
  private refreshTimer?: any;

  constructor(
    private tracker: DafTracker,
    private analytics: AnalyticsService,
    private consent: ConsentService
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.setupSubscriptions();
    
    if (this.autoRefresh) {
      this.startAutoRefresh();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
  }

  toggleDashboard(): void {
    this.showDashboard = !this.showDashboard;
    if (this.showDashboard) {
      this.refreshData();
    }
  }

  async refreshData(): Promise<void> {
    await this.loadData();
  }

  async exportData(): Promise<void> {
    try {
      const data = await this.tracker.exportData('json');
      this.downloadFile(data, 'daf-tracker-data.json', 'application/json');
    } catch (error) {
      console.error('Failed to export data:', error);
    }
  }

  async clearData(): Promise<void> {
    if (confirm('Are you sure you want to clear all tracking data? This action cannot be undone.')) {
      try {
        await this.tracker.clearData();
        this.analyticsData = null;
        alert('Data cleared successfully');
      } catch (error) {
        console.error('Failed to clear data:', error);
        alert('Failed to clear data');
      }
    }
  }

  formatDuration(ms: number): string {
    if (ms < 1000) return `${Math.round(ms)}ms`;
    if (ms < 60000) return `${Math.round(ms / 1000)}s`;
    return `${Math.round(ms / 60000)}m`;
  }

  private async loadData(): Promise<void> {
    try {
      // Load analytics data
      const analyticsResult = await this.analytics.generateReport();
      this.analyticsData = analyticsResult.data;
      
      // Load consent info
      this.consentInfo = this.consent.getConsent();
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    }
  }

  private setupSubscriptions(): void {
    // Subscribe to consent changes
    this.consent.consent$
      .pipe(takeUntil(this.destroy$))
      .subscribe(consent => {
        this.consentInfo = consent;
      });

    // Subscribe to analytics updates
    this.analytics.analytics$
      .pipe(takeUntil(this.destroy$))
      .subscribe(analytics => {
        if (analytics) {
          this.analyticsData = analytics;
        }
      });
  }

  private startAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (this.showDashboard) {
        this.refreshData();
      }
    }, this.refreshInterval);
  }

  private downloadFile(content: string, filename: string, contentType: string): void {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }
}

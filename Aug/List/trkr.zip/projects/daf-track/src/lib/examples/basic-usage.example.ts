import { Component, OnInit } from '@angular/core';
import { DafTracker, EventType, DafTrackerDirective } from 'daf-track';

@Component({
  selector: 'app-basic-example',
  standalone: true,
  imports: [DafTrackerDirective],
  template: `
    <div class="example-container">
      <h2>Basic DAF Tracker Usage Examples</h2>
      
      <!-- Basic click tracking -->
      <button dafTrack="click" 
              dafTrackCategory="navigation" 
              dafTrackAction="header-cta"
              dafTrackLabel="Get Started">
        Get Started
      </button>
      
      <!-- View tracking with Intersection Observer -->
      <div dafTrack="view" 
           dafTrackCategory="content" 
           dafTrackAction="hero-section"
           class="hero-section">
        <h3>Hero Section</h3>
        <p>This section will be tracked when it comes into view.</p>
      </div>
      
      <!-- Multiple event tracking -->
      <input dafTrack 
             dafTrackEvents="focus,blur,change"
             dafTrackCategory="form"
             dafTrackAction="email-input"
             dafTrackLabel="Newsletter Signup"
             placeholder="Enter your email"
             type="email">
      
      <!-- Hover tracking with duration -->
      <div dafTrack="hover"
           dafTrackCategory="engagement"
           dafTrackAction="product-card"
           class="product-card">
        <h4>Product Card</h4>
        <p>Hover over this card to track engagement.</p>
      </div>
      
      <!-- Form submission tracking -->
      <form dafTrack="form_submit"
            dafTrackCategory="conversion"
            dafTrackAction="contact-form"
            (ngSubmit)="onSubmit()">
        <input type="text" placeholder="Name" name="name">
        <input type="email" placeholder="Email" name="email">
        <button type="submit">Submit</button>
      </form>
      
      <!-- Conditional tracking -->
      <button dafTrack="click"
              [dafTrackCondition]="shouldTrackPremiumFeature"
              dafTrackCategory="premium"
              dafTrackAction="feature-access"
              dafTrackOnce="true">
        Premium Feature
      </button>
      
      <!-- Custom data tracking -->
      <div dafTrack="view"
           [dafTrackData]="{ section: 'pricing', plan: 'premium', value: 99 }"
           dafTrackCategory="pricing"
           dafTrackAction="plan-view">
        Premium Plan - $99/month
      </div>
      
      <!-- Programmatic tracking examples -->
      <div class="programmatic-examples">
        <button (click)="trackCustomEvent()">Track Custom Event</button>
        <button (click)="trackError()">Track Error</button>
        <button (click)="trackPerformance()">Track Performance</button>
      </div>
    </div>
  `,
  styles: `
    .example-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .hero-section {
      background: #f8f9fa;
      padding: 40px;
      margin: 20px 0;
      border-radius: 8px;
      text-align: center;
    }
    
    .product-card {
      border: 1px solid #ddd;
      padding: 20px;
      margin: 20px 0;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s;
    }
    
    .product-card:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transform: translateY(-2px);
    }
    
    form {
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-width: 300px;
      margin: 20px 0;
    }
    
    input, button {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    
    button {
      background: #007bff;
      color: white;
      cursor: pointer;
    }
    
    button:hover {
      background: #0056b3;
    }
    
    .programmatic-examples {
      margin-top: 40px;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
  `
})
export class BasicUsageExample implements OnInit {
  shouldTrackPremiumFeature = true;

  constructor(private tracker: DafTracker) {}

  ngOnInit(): void {
    // Track page view
    this.tracker.trackView('/examples/basic-usage');
    
    // Set user ID for session tracking
    this.tracker.setUserId('user_123');
  }

  onSubmit(): void {
    // Form submission will be automatically tracked by directive
    console.log('Form submitted');
  }

  trackCustomEvent(): void {
    this.tracker.trackCustom('button_clicked', 'engagement', {
      buttonType: 'programmatic',
      timestamp: Date.now(),
      userAgent: navigator.userAgent
    });
  }

  trackError(): void {
    try {
      // Simulate an error
      throw new Error('This is a test error for tracking');
    } catch (error) {
      this.tracker.trackError(error as Error, {
        context: 'example_component',
        severity: 'low'
      });
    }
  }

  trackPerformance(): void {
    const startTime = performance.now();
    
    // Simulate some work
    setTimeout(() => {
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      this.tracker.track(EventType.PERFORMANCE, 'operation_completed', {
        eventCategory: 'performance',
        eventLabel: 'example_operation',
        duration,
        customData: {
          operationType: 'simulation',
          executionTime: duration
        }
      });
    }, 100);
  }
}
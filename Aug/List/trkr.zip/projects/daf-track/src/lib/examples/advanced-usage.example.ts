import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { 
  DafTracker, 
  AnalyticsService, 
  ConsentService, 
  HeatmapService,
  PerformanceService,
  EventType,
  StorageType,
  DafTrackerDirective
} from 'daf-track';

@Component({
  selector: 'app-advanced-example',
  standalone: true,
  imports: [CommonModule, DafTrackerDirective],
  template: `
    <div class="advanced-example">
      <h2>Advanced DAF Tracker Features</h2>
      
      <!-- Consent Management -->
      <div class="consent-section">
        <h3>Consent Management</h3>
        <div class="consent-status">
          Status: {{ consentGranted ? 'Granted' : 'Not Granted' }}
        </div>
        <button (click)="grantConsent()" [disabled]="consentGranted">
          Grant Consent
        </button>
        <button (click)="revokeConsent()" [disabled]="!consentGranted">
          Revoke Consent
        </button>
      </div>
      
      <!-- Analytics Dashboard -->
      <div class="analytics-section">
        <h3>Analytics Dashboard</h3>
        <div class="analytics-stats" *ngIf="analyticsData">
          <div class="stat">
            <label>Total Events:</label>
            <span>{{ analyticsData.totalEvents }}</span>
          </div>
          <div class="stat">
            <label>Unique Users:</label>
            <span>{{ analyticsData.uniqueUsers }}</span>
          </div>
          <div class="stat">
            <label>Sessions:</label>
            <span>{{ analyticsData.uniqueSessions }}</span>
          </div>
        </div>
        <button (click)="generateAnalytics()">Generate Report</button>
        <button (click)="exportData()">Export Data</button>
      </div>
      
      <!-- Heatmap Controls -->
      <div class="heatmap-section">
        <h3>Heatmap Tracking</h3>
        <div class="heatmap-controls">
          <button (click)="startHeatmapTracking()" [disabled]="heatmapActive">
            Start Heatmap
          </button>
          <button (click)="stopHeatmapTracking()" [disabled]="!heatmapActive">
            Stop Heatmap
          </button>
          <button (click)="generateHeatmapImage()">Generate Image</button>
          <button (click)="clearHeatmapData()">Clear Data</button>
        </div>
        <div class="heatmap-stats" *ngIf="heatmapStats">
          <p>Total Points: {{ heatmapStats.totalPoints }}</p>
          <p>Clicks: {{ heatmapStats.clicks }}</p>
          <p>Hovers: {{ heatmapStats.hovers }}</p>
        </div>
      </div>
      
      <!-- Performance Monitoring -->
      <div class="performance-section">
        <h3>Performance Monitoring</h3>
        <div class="performance-stats" *ngIf="performanceData">
          <div class="metric">
            <label>Performance Score:</label>
            <span [class]="getScoreClass(performanceData.score)">
              {{ performanceData.score }}
            </span>
          </div>
          <div class="metric" *ngIf="performanceData.metrics">
            <label>LCP:</label>
            <span>{{ performanceData.metrics.largestContentfulPaint | number:'1.0-0' }}ms</span>
          </div>
          <div class="metric" *ngIf="performanceData.metrics">
            <label>FID:</label>
            <span>{{ performanceData.metrics.firstInputDelay | number:'1.0-0' }}ms</span>
          </div>
        </div>
        <button (click)="getPerformanceReport()">Get Performance Report</button>
      </div>
      
      <!-- Interactive Elements for Testing -->
      <div class="test-elements">
        <h3>Test Elements</h3>
        
        <div class="test-grid">
          <button dafTrack="click" 
                  dafTrackCategory="test" 
                  dafTrackAction="test-button-1"
                  class="test-button">
            Test Button 1
          </button>
          
          <button dafTrack="click" 
                  dafTrackCategory="test" 
                  dafTrackAction="test-button-2"
                  class="test-button">
            Test Button 2
          </button>
          
          <div dafTrack="hover"
               dafTrackCategory="test"
               dafTrackAction="hover-area"
               class="hover-area">
            Hover Area
          </div>
          
          <div dafTrack="view"
               dafTrackCategory="test"
               dafTrackAction="view-area"
               class="view-area">
            View Tracking Area
          </div>
        </div>
      </div>
      
      <!-- Funnel Analysis -->
      <div class="funnel-section">
        <h3>Funnel Analysis</h3>
        <button (click)="analyzeFunnel()">Analyze Conversion Funnel</button>
        <div class="funnel-results" *ngIf="funnelData">
          <div class="funnel-step" *ngFor="let step of funnelData.results">
            <span class="step-name">{{ step.step.name }}</span>
            <span class="step-users">{{ step.users }} users</span>
            <span class="step-rate">{{ step.conversionRate | number:'1.1-1' }}%</span>
          </div>
        </div>
      </div>
      
      <!-- Storage Management -->
      <div class="storage-section">
        <h3>Storage Management</h3>
        <div class="storage-controls">
          <select [(ngModel)]="selectedStorageType" (change)="changeStorageType()">
            <option value="localStorage">Local Storage</option>
            <option value="sessionStorage">Session Storage</option>
            <option value="memory">Memory</option>
            <option value="indexedDB">IndexedDB</option>
          </select>
          <button (click)="getStorageStats()">Get Storage Stats</button>
          <button (click)="clearStorage()">Clear Storage</button>
        </div>
        <div class="storage-stats" *ngIf="storageStats">
          <p>Total Items: {{ storageStats.totalItems }}</p>
          <p>Total Size: {{ formatBytes(storageStats.totalSize) }}</p>
          <p>Storage Type: {{ storageStats.storageType }}</p>
        </div>
      </div>
    </div>
  `,
  styles: `
    .advanced-example {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .consent-section, .analytics-section, .heatmap-section, 
    .performance-section, .test-elements, .funnel-section, 
    .storage-section {
      margin-bottom: 40px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
    }
    
    .consent-status {
      margin: 10px 0;
      padding: 10px;
      background: #f8f9fa;
      border-radius: 4px;
    }
    
    .analytics-stats, .heatmap-stats, .performance-stats, .storage-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      margin: 15px 0;
    }
    
    .stat, .metric {
      display: flex;
      justify-content: space-between;
      padding: 10px;
      background: #f8f9fa;
      border-radius: 4px;
    }
    
    .heatmap-controls, .storage-controls {
      display: flex;
      gap: 10px;
      margin: 15px 0;
      flex-wrap: wrap;
    }
    
    .test-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 15px;
      margin: 20px 0;
    }
    
    .test-button, .hover-area, .view-area {
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 4px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
    }
    
    .test-button {
      background: #007bff;
      color: white;
    }
    
    .test-button:hover {
      background: #0056b3;
    }
    
    .hover-area {
      background: #28a745;
      color: white;
    }
    
    .hover-area:hover {
      background: #1e7e34;
      transform: scale(1.05);
    }
    
    .view-area {
      background: #ffc107;
      color: #212529;
    }
    
    .funnel-results {
      margin-top: 15px;
    }
    
    .funnel-step {
      display: flex;
      justify-content: space-between;
      padding: 10px;
      margin: 5px 0;
      background: #f8f9fa;
      border-radius: 4px;
    }
    
    .score-excellent { color: #28a745; }
    .score-good { color: #ffc107; }
    .score-poor { color: #dc3545; }
    
    button {
      padding: 8px 16px;
      margin: 5px;
      border: 1px solid #ddd;
      border-radius: 4px;
      background: white;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    button:hover:not(:disabled) {
      background: #f8f9fa;
    }
    
    button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    select {
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
  `
})
export class AdvancedUsageExample implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  
  consentGranted = false;
  analyticsData: any = null;
  heatmapActive = false;
  heatmapStats: any = null;
  performanceData: any = null;
  funnelData: any = null;
  storageStats: any = null;
  selectedStorageType = 'localStorage';

  constructor(
    private tracker: DafTracker,
    private analytics: AnalyticsService,
    private consent: ConsentService,
    private heatmap: HeatmapService,
    private performance: PerformanceService
  ) {}

  ngOnInit(): void {
    this.setupSubscriptions();
    this.initializeTracking();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private setupSubscriptions(): void {
    // Subscribe to consent changes
    this.consent.consent$
      .pipe(takeUntil(this.destroy$))
      .subscribe(consent => {
        this.consentGranted = consent?.granted || false;
      });

    // Subscribe to heatmap data
    this.heatmap.heatmap$
      .pipe(takeUntil(this.destroy$))
      .subscribe(points => {
        this.heatmapStats = {
          totalPoints: points.length,
          clicks: points.filter(p => p.eventType === EventType.CLICK).length,
          hovers: points.filter(p => p.eventType === EventType.HOVER).length
        };
      });
  }

  private initializeTracking(): void {
    // Configure advanced tracking options
    this.tracker.configure({
      debug: true,
      sampleRate: 1.0,
      batchSize: 10,
      batchTimeout: 3000
    });

    // Track page view
    this.tracker.trackView('/examples/advanced-usage');
  }

  async grantConsent(): Promise<void> {
    await this.consent.grantConsent(['analytics', 'marketing', 'personalization']);
  }

  async revokeConsent(): Promise<void> {
    await this.consent.revokeConsent();
  }

  async generateAnalytics(): Promise<void> {
    const result = await this.analytics.generateReport({
      startDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // Last 24 hours
      endDate: new Date()
    });
    this.analyticsData = result.data;
  }

  async exportData(): Promise<void> {
    const data = await this.tracker.exportData('json');
    this.downloadFile(data, 'tracking-data.json', 'application/json');
  }

  startHeatmapTracking(): void {
    this.heatmap.configure({
      enabled: true,
      trackClicks: true,
      trackHovers: true,
      sampleRate: 1.0
    });
    this.heatmap.startTracking();
    this.heatmapActive = true;
  }

  stopHeatmapTracking(): void {
    this.heatmap.stopTracking();
    this.heatmapActive = false;
  }

  async generateHeatmapImage(): Promise<void> {
    try {
      const imageData = await this.heatmap.generateHeatmapImage(800, 600);
      // Display or download the heatmap image
      const link = document.createElement('a');
      link.href = imageData;
      link.download = 'heatmap.png';
      link.click();
    } catch (error) {
      console.error('Failed to generate heatmap image:', error);
    }
  }

  async clearHeatmapData(): Promise<void> {
    await this.heatmap.clearHeatmapData();
  }

  async getPerformanceReport(): Promise<void> {
    this.performanceData = await this.performance.getPerformanceReport();
  }

  async analyzeFunnel(): Promise<void> {
    this.funnelData = await this.analytics.getFunnelAnalysis([
      { name: 'Page View', eventType: EventType.VIEW, required: true },
      { name: 'Button Click', eventType: EventType.CLICK, required: true },
      { name: 'Hover Interaction', eventType: EventType.HOVER, required: false }
    ]);
  }

  changeStorageType(): void {
    const storageType = this.selectedStorageType as keyof typeof StorageType;
    this.tracker.configure({
      storageType: StorageType[storageType]
    });
  }

  async getStorageStats(): Promise<void> {
    this.storageStats = await this.tracker.getStorageStats();
  }

  async clearStorage(): Promise<void> {
    if (confirm('Are you sure you want to clear all storage data?')) {
      await this.tracker.clearData();
      this.storageStats = null;
    }
  }

  getScoreClass(score: number): string {
    if (score >= 90) return 'score-excellent';
    if (score >= 70) return 'score-good';
    return 'score-poor';
  }

  formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  private downloadFile(content: string, filename: string, contentType: string): void {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }
}
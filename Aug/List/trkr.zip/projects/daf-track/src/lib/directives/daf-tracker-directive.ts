import { 
    Directive, 
    ElementRef, 
    Input, 
    OnInit, 
    OnDestroy, 
    HostListener,
    Renderer2,
    Optional
} from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, throttleTime } from 'rxjs/operators';

import { DafTracker } from '../daf-tracker';
import { EventType } from '../models/daf-tracker-interface';

@Directive({
    selector: '[dafTrack]',
    standalone: true
})
export class DafTrackerDirective implements OnInit, OnDestroy {
    @Input('dafTrack') trackingConfig: string | TrackingConfig = 'click';
    @Input() dafTrackCategory?: string;
    @Input() dafTrackAction?: string;
    @Input() dafTrackLabel?: string;
    @Input() dafTrackData?: any;
    @Input() dafTrackEvents?: EventType[] | string;
    @Input() dafTrackDebounce?: number;
    @Input() dafTrackThrottle?: number;
    @Input() dafTrackOnce?: boolean;
    @Input() dafTrackCondition?: () => boolean;

    private destroy$ = new Subject<void>();
    private hasTracked = false;
    private config!: TrackingConfig;

    constructor(
        private elementRef: ElementRef<HTMLElement>,
        private renderer: Renderer2,
        @Optional() private tracker: DafTracker
    ) {}

    ngOnInit(): void {
        if (!this.tracker) {
            console.warn('DafTracker service not found. Make sure it is provided.');
            return;
        }

        this.parseConfig();
        this.setupTracking();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    private parseConfig(): void {
        if (typeof this.trackingConfig === 'string') {
            this.config = {
                events: [this.trackingConfig as EventType],
                category: this.dafTrackCategory || 'user_interaction',
                action: this.dafTrackAction || this.trackingConfig,
                label: this.dafTrackLabel,
                data: this.dafTrackData,
                debounce: this.dafTrackDebounce,
                throttle: this.dafTrackThrottle,
                once: this.dafTrackOnce || false,
                condition: this.dafTrackCondition
            };
        } else {
            this.config = {
                ...this.trackingConfig,
                // Override with individual inputs if provided
                events: this.trackingConfig.events || [EventType.CLICK],
                category: this.dafTrackCategory || this.trackingConfig.category || 'user_interaction',
                action: this.dafTrackAction || this.trackingConfig.action || 'click',
                label: this.dafTrackLabel || this.trackingConfig.label,
                data: this.dafTrackData || this.trackingConfig.data,
                debounce: this.dafTrackDebounce ?? this.trackingConfig.debounce,
                throttle: this.dafTrackThrottle ?? this.trackingConfig.throttle,
                once: this.dafTrackOnce ?? this.trackingConfig.once ?? false,
                condition: this.dafTrackCondition || this.trackingConfig.condition
            };
        }

        // Parse events if string
        if (typeof this.dafTrackEvents === 'string') {
            this.config.events = this.dafTrackEvents.split(',').map(e => e.trim() as EventType);
        } else if (Array.isArray(this.dafTrackEvents)) {
            this.config.events = this.dafTrackEvents;
        }
    }

    private setupTracking(): void {
        const element = this.elementRef.nativeElement;

        this.config.events.forEach(eventType => {
            switch (eventType) {
                case EventType.CLICK:
                    this.setupClickTracking();
                    break;
                case EventType.VIEW:
                    this.setupViewTracking();
                    break;
                case EventType.HOVER:
                    this.setupHoverTracking();
                    break;
                case EventType.FOCUS:
                    this.setupFocusTracking();
                    break;
                case EventType.BLUR:
                    this.setupBlurTracking();
                    break;
                case EventType.SCROLL:
                    this.setupScrollTracking();
                    break;
                case EventType.FORM_SUBMIT:
                    this.setupFormSubmitTracking();
                    break;
                case EventType.FORM_FIELD_CHANGE:
                    this.setupFormFieldChangeTracking();
                    break;
                default:
                    console.warn(`Unsupported event type: ${eventType}`);
            }
        });
    }

    private setupClickTracking(): void {
        this.renderer.listen(this.elementRef.nativeElement, 'click', (event: MouseEvent) => {
            this.handleEvent(EventType.CLICK, event);
        });
    }

    private setupViewTracking(): void {
        // Use Intersection Observer for view tracking
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver(
                (entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            this.handleEvent(EventType.VIEW);
                            if (this.config.once) {
                                observer.disconnect();
                            }
                        }
                    });
                },
                { threshold: 0.5 } // Element is 50% visible
            );

            observer.observe(this.elementRef.nativeElement);

            // Cleanup observer on destroy
            this.destroy$.subscribe(() => observer.disconnect());
        } else {
            // Fallback for browsers without Intersection Observer
            this.handleEvent(EventType.VIEW);
        }
    }

    private setupHoverTracking(): void {
        let hoverStartTime: number;

        this.renderer.listen(this.elementRef.nativeElement, 'mouseenter', () => {
            hoverStartTime = Date.now();
        });

        this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', () => {
            if (hoverStartTime) {
                const duration = Date.now() - hoverStartTime;
                this.handleEvent(EventType.HOVER, undefined, { duration });
            }
        });
    }

    private setupFocusTracking(): void {
        this.renderer.listen(this.elementRef.nativeElement, 'focus', (event: FocusEvent) => {
            this.handleEvent(EventType.FOCUS, event);
        });
    }

    private setupBlurTracking(): void {
        let focusStartTime: number;

        this.renderer.listen(this.elementRef.nativeElement, 'focus', () => {
            focusStartTime = Date.now();
        });

        this.renderer.listen(this.elementRef.nativeElement, 'blur', (event: FocusEvent) => {
            const duration = focusStartTime ? Date.now() - focusStartTime : undefined;
            this.handleEvent(EventType.BLUR, event, { duration });
        });
    }

    private setupScrollTracking(): void {
        // Only track scroll if element is scrollable
        const element = this.elementRef.nativeElement;
        if (element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth) {
            let scrollSubject = new Subject<Event>();
            
            this.renderer.listen(element, 'scroll', (event: Event) => {
                scrollSubject.next(event);
            });

            scrollSubject.pipe(
                throttleTime(this.config.throttle || 1000),
                takeUntil(this.destroy$)
            ).subscribe((event) => {
                const scrollPercentage = this.calculateScrollPercentage(element);
                this.handleEvent(EventType.SCROLL, event, { scrollPercentage });
            });
        }
    }

    private setupFormSubmitTracking(): void {
        const element = this.elementRef.nativeElement;
        if (element.tagName.toLowerCase() === 'form') {
            this.renderer.listen(element, 'submit', (event: SubmitEvent) => {
                this.handleEvent(EventType.FORM_SUBMIT, event);
            });
        }
    }

    private setupFormFieldChangeTracking(): void {
        const element = this.elementRef.nativeElement;
        const isFormField = ['input', 'select', 'textarea'].includes(element.tagName.toLowerCase());
        
        if (isFormField) {
            let changeSubject = new Subject<Event>();
            
            this.renderer.listen(element, 'change', (event: Event) => {
                changeSubject.next(event);
            });

            this.renderer.listen(element, 'input', (event: Event) => {
                changeSubject.next(event);
            });

            changeSubject.pipe(
                debounceTime(this.config.debounce || 500),
                takeUntil(this.destroy$)
            ).subscribe((event) => {
                this.handleEvent(EventType.FORM_FIELD_CHANGE, event);
            });
        }
    }

    private handleEvent(eventType: EventType, originalEvent?: Event, additionalData?: any): void {
        // Check if already tracked and once is true
        if (this.config.once && this.hasTracked) {
            return;
        }

        // Check condition if provided
        if (this.config.condition && !this.config.condition()) {
            return;
        }

        const element = this.elementRef.nativeElement;
        const customData = {
            elementInfo: this.getElementInfo(element),
            ...this.config.data,
            ...additionalData
        };

        // Add event-specific data
        if (originalEvent) {
            customData.eventInfo = this.getEventInfo(originalEvent);
        }

        this.tracker.track(eventType, this.config.action, {
            eventCategory: this.config.category,
            eventLabel: this.config.label,
            contentId: element.id || undefined,
            customData
        });

        this.hasTracked = true;
    }

    private getElementInfo(element: HTMLElement): any {
        return {
            tagName: element.tagName.toLowerCase(),
            id: element.id,
            className: element.className,
            textContent: element.textContent?.substring(0, 100),
            attributes: this.getRelevantAttributes(element),
            position: this.getElementPosition(element),
            size: {
                width: element.offsetWidth,
                height: element.offsetHeight
            }
        };
    }

    private getEventInfo(event: Event): any {
        const info: any = {
            type: event.type,
            timestamp: Date.now()
        };

        if (event instanceof MouseEvent) {
            info.mouse = {
                clientX: event.clientX,
                clientY: event.clientY,
                button: event.button,
                buttons: event.buttons,
                altKey: event.altKey,
                ctrlKey: event.ctrlKey,
                shiftKey: event.shiftKey,
                metaKey: event.metaKey
            };
        }

        if (event instanceof KeyboardEvent) {
            info.keyboard = {
                key: event.key,
                code: event.code,
                altKey: event.altKey,
                ctrlKey: event.ctrlKey,
                shiftKey: event.shiftKey,
                metaKey: event.metaKey
            };
        }

        if (event instanceof TouchEvent) {
            info.touch = {
                touches: event.touches.length,
                changedTouches: event.changedTouches.length
            };
        }

        return info;
    }

    private getRelevantAttributes(element: HTMLElement): Record<string, string> {
        const relevantAttrs = ['data-', 'aria-', 'role', 'type', 'name', 'value', 'href', 'src'];
        const attributes: Record<string, string> = {};

        for (let i = 0; i < element.attributes.length; i++) {
            const attr = element.attributes[i];
            if (relevantAttrs.some(prefix => attr.name.startsWith(prefix))) {
                attributes[attr.name] = attr.value;
            }
        }

        return attributes;
    }

    private getElementPosition(element: HTMLElement): { x: number; y: number } {
        const rect = element.getBoundingClientRect();
        return {
            x: rect.left + window.scrollX,
            y: rect.top + window.scrollY
        };
    }

    private calculateScrollPercentage(element: HTMLElement): number {
        const scrollTop = element.scrollTop;
        const scrollHeight = element.scrollHeight - element.clientHeight;
        return scrollHeight > 0 ? Math.round((scrollTop / scrollHeight) * 100) : 0;
    }

    // Host listeners for common events (as backup)
    @HostListener('click', ['$event'])
    onHostClick(event: MouseEvent): void {
        if (this.config.events.includes(EventType.CLICK)) {
            this.handleEvent(EventType.CLICK, event);
        }
    }

    @HostListener('mouseenter')
    onHostMouseEnter(): void {
        if (this.config.events.includes(EventType.HOVER)) {
            // Handled in setupHoverTracking
        }
    }

    @HostListener('focus', ['$event'])
    onHostFocus(event: FocusEvent): void {
        if (this.config.events.includes(EventType.FOCUS)) {
            this.handleEvent(EventType.FOCUS, event);
        }
    }
}

// Configuration interface for the directive
export interface TrackingConfig {
    events: EventType[];
    category: string;
    action: string;
    label?: string;
    data?: any;
    debounce?: number;
    throttle?: number;
    once?: boolean;
    condition?: () => boolean;
}

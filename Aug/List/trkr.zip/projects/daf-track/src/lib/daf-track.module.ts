import { NgModule, ModuleWithProviders, InjectionToken } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DafTracker } from './daf-tracker';
import { DafTrack } from './daf-track';
import { DafTrackerDirective } from './directives/daf-tracker-directive';
import { StorageService } from './storage/storage.service';
import { AnalyticsService } from './services/analytics.service';
import { ConsentService } from './services/consent.service';
import { PerformanceService } from './services/performance.service';
import { HeatmapService } from './services/heatmap.service';
import { DafTrackerConfig } from './models/daf-tracker-interface';

// Injection token for configuration
export const DAF_TRACKER_CONFIG = new InjectionToken<Partial<DafTrackerConfig>>('DAF_TRACKER_CONFIG');

@NgModule({
    imports: [
        CommonModule,
        DafTrack,
        DafTrackerDirective
    ],
    exports: [
        DafTrack,
        DafTrackerDirective
    ]
})
export class DafTrackModule {
    static forRoot(config?: Partial<DafTrackerConfig>): ModuleWithProviders<DafTrackModule> {
        return {
            ngModule: DafTrackModule,
            providers: [
                DafTracker,
                StorageService,
                AnalyticsService,
                ConsentService,
                PerformanceService,
                HeatmapService,
                {
                    provide: DAF_TRACKER_CONFIG,
                    useValue: config || {}
                }
            ]
        };
    }

    static forChild(): ModuleWithProviders<DafTrackModule> {
        return {
            ngModule: DafTrackModule,
            providers: []
        };
    }
}
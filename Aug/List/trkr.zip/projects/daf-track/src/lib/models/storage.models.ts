// Storage-related models and interfaces

export interface StorageOptions {
    encrypt?: boolean;
    compress?: boolean;
    ttl?: number; // Time to live in milliseconds
    namespace?: string;
}

export interface StorageItem<T = any> {
    data: T;
    timestamp: number;
    ttl?: number;
    metadata?: Record<string, any>;
}

export interface StorageStats {
    totalItems: number;
    totalSize: number; // in bytes
    oldestItem: number; // timestamp
    newestItem: number; // timestamp
    storageType: string;
}

export interface BatchOperation {
    operation: 'store' | 'retrieve' | 'remove';
    key: string;
    data?: any;
}

export interface BatchResult {
    success: boolean;
    results: Array<{
        key: string;
        success: boolean;
        data?: any;
        error?: string;
    }>;
}
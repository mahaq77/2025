
// Core tracking event interface
export interface TrackingEvent {
    // Event identification
    eventId: string;
    eventCategory: string;
    eventType: EventType;
    eventAction: string;
    eventLabel?: string;
    
    // Content information
    contentType?: string;
    contentId?: string;
    contentPage: string;
    contentTitle?: string;
    
    // Session and user data
    sessionId: string;
    userId?: string;
    deviceId?: string;
    
    // Timing information
    timestamp: number;
    duration?: number;
    
    // Location and context
    url: string;
    referrer?: string;
    userAgent?: string;
    viewport?: ViewportInfo;
    
    // Custom data
    customData?: Record<string, any>;
    
    // Privacy and compliance
    consentGiven: boolean;
    anonymized?: boolean;
}

// Event types enum
export enum EventType {
    CLICK = 'click',
    VIEW = 'view',
    SCROLL = 'scroll',
    HOVER = 'hover',
    FOCUS = 'focus',
    BLUR = 'blur',
    FORM_SUBMIT = 'form_submit',
    FORM_FIELD_CHANGE = 'form_field_change',
    PAGE_LOAD = 'page_load',
    PAGE_UNLOAD = 'page_unload',
    CUSTOM = 'custom',
    ERROR = 'error',
    PERFORMANCE = 'performance'
}

// Viewport information
export interface ViewportInfo {
    width: number;
    height: number;
    scrollX: number;
    scrollY: number;
}

// Configuration interface
export interface DafTrackerConfig {
    // Basic settings
    enabled: boolean;
    debug: boolean;
    
    // Storage settings
    storageType: StorageType;
    storageKey: string;
    maxStorageSize: number;
    
    // Privacy settings
    respectDoNotTrack: boolean;
    requireConsent: boolean;
    anonymizeData: boolean;
    
    // Sampling and filtering
    sampleRate: number; // 0-1, percentage of events to track
    excludeEvents: EventType[];
    includeEvents: EventType[];
    
    // Batch processing
    batchSize: number;
    batchTimeout: number; // milliseconds
    
    // API settings
    apiEndpoint?: string;
    apiKey?: string;
    
    // Custom settings
    customFields: Record<string, any>;
}

// Storage types
export enum StorageType {
    LOCAL_STORAGE = 'localStorage',
    SESSION_STORAGE = 'sessionStorage',
    MEMORY = 'memory',
    INDEXED_DB = 'indexedDB',
    CUSTOM = 'custom'
}

// Analytics data interface
export interface AnalyticsData {
    totalEvents: number;
    eventsByType: Record<EventType, number>;
    eventsByCategory: Record<string, number>;
    uniqueUsers: number;
    uniqueSessions: number;
    averageSessionDuration: number;
    topPages: Array<{ page: string; count: number; percentage: number }>;
    topActions: Array<{ action: string; count: number; percentage: number }>;
    timeRange: {
        start: number;
        end: number;
    };
    trends?: {
        daily?: Array<{ date: string; count: number }>;
        hourly?: Array<{ hour: number; count: number }>;
        weekly?: Array<{ week: string; count: number }>;
    };
}

// Storage interface for custom storage implementations
export interface StorageProvider {
    store(key: string, data: any): Promise<void> | void;
    retrieve(key: string): Promise<any> | any;
    remove(key: string): Promise<void> | void;
    clear(): Promise<void> | void;
    size(): Promise<number> | number;
}

// Consent management
export interface ConsentInfo {
    granted: boolean;
    timestamp: number;
    version: string;
    categories: ConsentCategory[];
    ipAddress?: string;
    userAgent?: string;
    method: ConsentMethod;
}

export interface ConsentCategory {
    id: string;
    name: string;
    description: string;
    required: boolean;
    granted: boolean;
}

export enum ConsentMethod {
    EXPLICIT = 'explicit',
    IMPLIED = 'implied',
    LEGITIMATE_INTEREST = 'legitimate_interest',
    COOKIE_BANNER = 'cookie_banner',
    SETTINGS_PAGE = 'settings_page'
}

// Performance tracking
export interface PerformanceMetrics {
    loadTime: number;
    domContentLoaded: number;
    firstPaint: number;
    firstContentfulPaint: number;
    largestContentfulPaint: number;
    cumulativeLayoutShift: number;
    firstInputDelay: number;
}

// Analytics interfaces
export interface AnalyticsQuery {
    startDate?: Date;
    endDate?: Date;
    eventTypes?: EventType[];
    eventCategories?: string[];
    userId?: string;
    sessionId?: string;
    limit?: number;
    offset?: number;
}

export interface AnalyticsResult {
    data: AnalyticsData;
    query: AnalyticsQuery;
    generatedAt: number;
}

export interface FunnelStep {
    name: string;
    eventType: EventType;
    eventAction?: string;
    eventCategory?: string;
    required: boolean;
}

export interface FunnelAnalysis {
    steps: FunnelStep[];
    results: Array<{
        step: FunnelStep;
        users: number;
        conversionRate: number;
        dropoffRate: number;
    }>;
    totalUsers: number;
    overallConversionRate: number;
    generatedAt: number;
}

export interface CohortAnalysis {
    cohorts: Array<{
        cohortId: string;
        period: string;
        users: number;
        retention: Record<string, number>;
    }>;
    generatedAt: number;
}

export interface HeatmapData {
    element: string;
    selector: string;
    clicks: number;
    hovers: number;
    views: number;
    position: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}

// Privacy and consent interfaces
export interface PrivacySettings {
    anonymizeIp: boolean;
    anonymizeUserAgent: boolean;
    respectDoNotTrack: boolean;
    dataRetentionDays: number;
    allowCrossSiteTracking: boolean;
    enableFingerprinting: boolean;
}

export interface DataSubjectRequest {
    type: 'access' | 'erasure' | 'portability' | 'rectification' | 'restriction';
    userId?: string;
    sessionId?: string;
    email: string;
    requestDate: number;
    status: 'pending' | 'processing' | 'completed' | 'rejected';
    reason?: string;
}

export interface ComplianceReport {
    period: {
        start: number;
        end: number;
    };
    totalUsers: number;
    consentedUsers: number;
    consentRate: number;
    dataSubjectRequests: {
        total: number;
        byType: Record<string, number>;
        processed: number;
        pending: number;
    };
    dataRetention: {
        totalRecords: number;
        expiredRecords: number;
        deletedRecords: number;
    };
    violations: Array<{
        type: string;
        description: string;
        timestamp: number;
        resolved: boolean;
    }>;
}

// Error tracking
export interface ErrorInfo {
    message: string;
    stack?: string;
    filename?: string;
    lineno?: number;
    colno?: number;
    type: 'javascript' | 'network' | 'custom';
}

// Legacy interface for backward compatibility
export interface Tracker {
    evtCtg?: string;
    evtTyp?: string;
    cntTyp?: string;
    cntId?: string;
    custSessId?: string;
    data?: any;
    dvId?: string;
    dvCfg: string;
    cntPg: string;
    commId?: string;
    commTyp?: string;
    subLst?: string;
}
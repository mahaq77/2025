import { BaseStorageProvider } from './base-storage.provider';
import { StorageItem, StorageOptions, StorageStats } from '../models/storage.models';

export class LocalStorageProvider extends BaseStorageProvider {
    constructor(options: StorageOptions = {}) {
        super(options);
    }

    async store(key: string, data: any): Promise<void> {
        if (!this.isAvailable()) {
            throw new Error('localStorage is not available');
        }

        const namespacedKey = this.getNamespacedKey(key);
        const item = this.createStorageItem(data);
        const serialized = await this.processForStorage(item);

        try {
            localStorage.setItem(namespacedKey, serialized);
        } catch (error) {
            // Handle quota exceeded error
            if (error instanceof DOMException && error.code === 22) {
                await this.cleanup();
                localStorage.setItem(namespacedKey, serialized);
            } else {
                throw error;
            }
        }
    }

    async retrieve(key: string): Promise<any> {
        if (!this.isAvailable()) {
            return null;
        }

        const namespacedKey = this.getNamespacedKey(key);
        const serialized = localStorage.getItem(namespacedKey);

        if (!serialized) {
            return null;
        }

        try {
            const item: StorageItem = await this.processFromStorage(serialized);
            
            if (this.isExpired(item)) {
                await this.remove(key);
                return null;
            }

            return item.data;
        } catch (error) {
            // If parsing fails, remove the corrupted item
            await this.remove(key);
            return null;
        }
    }

    async remove(key: string): Promise<void> {
        if (!this.isAvailable()) {
            return;
        }

        const namespacedKey = this.getNamespacedKey(key);
        localStorage.removeItem(namespacedKey);
    }

    async clear(): Promise<void> {
        if (!this.isAvailable()) {
            return;
        }

        const keysToRemove: string[] = [];
        const prefix = `${this.namespace}:`;

        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith(prefix)) {
                keysToRemove.push(key);
            }
        }

        keysToRemove.forEach(key => localStorage.removeItem(key));
    }

    size(): number {
        if (!this.isAvailable()) {
            return 0;
        }

        let count = 0;
        const prefix = `${this.namespace}:`;

        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith(prefix)) {
                count++;
            }
        }

        return count;
    }

    getStats(): StorageStats {
        if (!this.isAvailable()) {
            return {
                totalItems: 0,
                totalSize: 0,
                oldestItem: 0,
                newestItem: 0,
                storageType: 'localStorage'
            };
        }

        let totalItems = 0;
        let totalSize = 0;
        let oldestItem = Number.MAX_SAFE_INTEGER;
        let newestItem = 0;
        const prefix = `${this.namespace}:`;

        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith(prefix)) {
                totalItems++;
                const value = localStorage.getItem(key);
                if (value) {
                    totalSize += value.length;
                    try {
                        const item: StorageItem = JSON.parse(value);
                        oldestItem = Math.min(oldestItem, item.timestamp);
                        newestItem = Math.max(newestItem, item.timestamp);
                    } catch {
                        // Ignore parsing errors for stats
                    }
                }
            }
        }

        return {
            totalItems,
            totalSize,
            oldestItem: oldestItem === Number.MAX_SAFE_INTEGER ? 0 : oldestItem,
            newestItem,
            storageType: 'localStorage'
        };
    }

    private isAvailable(): boolean {
        try {
            const test = '__daf_tracker_test__';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch {
            return false;
        }
    }

    private async cleanup(): Promise<void> {
        const items: Array<{ key: string; timestamp: number }> = [];
        const prefix = `${this.namespace}:`;

        // Collect all items with timestamps
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith(prefix)) {
                const value = localStorage.getItem(key);
                if (value) {
                    try {
                        const item: StorageItem = JSON.parse(value);
                        items.push({ key, timestamp: item.timestamp });
                    } catch {
                        // Remove corrupted items
                        localStorage.removeItem(key);
                    }
                }
            }
        }

        // Sort by timestamp (oldest first) and remove oldest 25%
        items.sort((a, b) => a.timestamp - b.timestamp);
        const itemsToRemove = items.slice(0, Math.floor(items.length * 0.25));
        
        itemsToRemove.forEach(item => localStorage.removeItem(item.key));
    }
}
import { Injectable } from '@angular/core';
import { StorageProvider, StorageType } from '../models/daf-tracker-interface';
import { StorageOptions, StorageStats } from '../models/storage.models';
import { LocalStorageProvider } from './local-storage.provider';
import { SessionStorageProvider } from './session-storage.provider';
import { MemoryStorageProvider } from './memory-storage.provider';
import { IndexedDBStorageProvider } from './indexed-db-storage.provider';

@Injectable({
    providedIn: 'root'
})
export class StorageService {
    private providers = new Map<StorageType, StorageProvider>();
    private currentProvider: StorageProvider;

    constructor() {
        // Initialize default providers
        this.providers.set(StorageType.LOCAL_STORAGE, new LocalStorageProvider());
        this.providers.set(StorageType.SESSION_STORAGE, new SessionStorageProvider());
        this.providers.set(StorageType.MEMORY, new MemoryStorageProvider());
        this.providers.set(StorageType.INDEXED_DB, new IndexedDBStorageProvider());
        
        // Set default provider
        this.currentProvider = this.providers.get(StorageType.LOCAL_STORAGE)!;
    }

    setProvider(type: StorageType, options?: StorageOptions): void {
        let provider = this.providers.get(type);
        
        if (!provider || options) {
            // Create new provider with options
            switch (type) {
                case StorageType.LOCAL_STORAGE:
                    provider = new LocalStorageProvider(options);
                    break;
                case StorageType.SESSION_STORAGE:
                    provider = new SessionStorageProvider(options);
                    break;
                case StorageType.MEMORY:
                    provider = new MemoryStorageProvider(options);
                    break;
                case StorageType.INDEXED_DB:
                    provider = new IndexedDBStorageProvider(options);
                    break;
                default:
                    throw new Error(`Unsupported storage type: ${type}`);
            }
            this.providers.set(type, provider);
        }
        
        this.currentProvider = provider;
    }

    setCustomProvider(provider: StorageProvider): void {
        this.providers.set(StorageType.CUSTOM, provider);
        this.currentProvider = provider;
    }

    async store(key: string, data: any): Promise<void> {
        return this.currentProvider.store(key, data);
    }

    async retrieve(key: string): Promise<any> {
        return this.currentProvider.retrieve(key);
    }

    async remove(key: string): Promise<void> {
        return this.currentProvider.remove(key);
    }

    async clear(): Promise<void> {
        return this.currentProvider.clear();
    }

    async size(): Promise<number> {
        const result = this.currentProvider.size();
        return result instanceof Promise ? result : Promise.resolve(result);
    }

    async getStats(): Promise<StorageStats> {
        if ('getStats' in this.currentProvider && typeof this.currentProvider.getStats === 'function') {
            const result = this.currentProvider.getStats();
            return result instanceof Promise ? result : Promise.resolve(result);
        }
        
        // Fallback stats
        const size = await this.size();
        return {
            totalItems: size,
            totalSize: 0,
            oldestItem: 0,
            newestItem: Date.now(),
            storageType: 'unknown'
        };
    }

    getCurrentProvider(): StorageProvider {
        return this.currentProvider;
    }

    getProvider(type: StorageType): StorageProvider | undefined {
        return this.providers.get(type);
    }

    // Batch operations
    async storeBatch(items: Array<{ key: string; data: any }>): Promise<void> {
        const promises = items.map(item => this.store(item.key, item.data));
        await Promise.all(promises);
    }

    async retrieveBatch(keys: string[]): Promise<Array<{ key: string; data: any }>> {
        const promises = keys.map(async key => ({
            key,
            data: await this.retrieve(key)
        }));
        return Promise.all(promises);
    }

    async removeBatch(keys: string[]): Promise<void> {
        const promises = keys.map(key => this.remove(key));
        await Promise.all(promises);
    }

    // Utility methods
    async exists(key: string): Promise<boolean> {
        const data = await this.retrieve(key);
        return data !== null && data !== undefined;
    }

    async keys(): Promise<string[]> {
        if ('getAllKeys' in this.currentProvider && typeof this.currentProvider.getAllKeys === 'function') {
            const result = (this.currentProvider as any).getAllKeys();
            return result instanceof Promise ? result : Promise.resolve(result);
        }
        
        // Fallback: not supported by all providers
        return [];
    }

    async cleanupExpired(): Promise<number> {
        if ('cleanupExpired' in this.currentProvider && typeof this.currentProvider.cleanupExpired === 'function') {
            const result = (this.currentProvider as any).cleanupExpired();
            return result instanceof Promise ? result : Promise.resolve(result);
        }
        
        return 0;
    }

    // Health check
    async healthCheck(): Promise<{
        available: boolean;
        readable: boolean;
        writable: boolean;
        error?: string;
    }> {
        try {
            const testKey = '__daf_tracker_health_check__';
            const testData = { timestamp: Date.now() };
            
            // Test write
            await this.store(testKey, testData);
            
            // Test read
            const retrieved = await this.retrieve(testKey);
            const readable = retrieved && retrieved.timestamp === testData.timestamp;
            
            // Cleanup
            await this.remove(testKey);
            
            return {
                available: true,
                readable,
                writable: true
            };
        } catch (error) {
            return {
                available: false,
                readable: false,
                writable: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
import { BaseStorageProvider } from './base-storage.provider';
import { StorageItem, StorageOptions, StorageStats } from '../models/storage.models';

export class MemoryStorageProvider extends BaseStorageProvider {
    private storage = new Map<string, StorageItem>();
    private maxSize: number;

    constructor(options: StorageOptions & { maxSize?: number } = {}) {
        super(options);
        this.maxSize = options.maxSize || 1000; // Default max 1000 items
    }

    async store(key: string, data: any): Promise<void> {
        const namespacedKey = this.getNamespacedKey(key);
        const item = this.createStorageItem(data);

        // Check if we need to cleanup
        if (this.storage.size >= this.maxSize) {
            await this.cleanup();
        }

        this.storage.set(namespacedKey, item);
    }

    async retrieve(key: string): Promise<any> {
        const namespacedKey = this.getNamespacedKey(key);
        const item = this.storage.get(namespacedKey);

        if (!item) {
            return null;
        }

        if (this.isExpired(item)) {
            await this.remove(key);
            return null;
        }

        return item.data;
    }

    async remove(key: string): Promise<void> {
        const namespacedKey = this.getNamespacedKey(key);
        this.storage.delete(namespacedKey);
    }

    async clear(): Promise<void> {
        const prefix = `${this.namespace}:`;
        const keysToRemove: string[] = [];

        for (const key of this.storage.keys()) {
            if (key.startsWith(prefix)) {
                keysToRemove.push(key);
            }
        }

        keysToRemove.forEach(key => this.storage.delete(key));
    }

    size(): number {
        const prefix = `${this.namespace}:`;
        let count = 0;

        for (const key of this.storage.keys()) {
            if (key.startsWith(prefix)) {
                count++;
            }
        }

        return count;
    }

    getStats(): StorageStats {
        let totalItems = 0;
        let totalSize = 0;
        let oldestItem = Number.MAX_SAFE_INTEGER;
        let newestItem = 0;
        const prefix = `${this.namespace}:`;

        for (const [key, item] of this.storage.entries()) {
            if (key.startsWith(prefix)) {
                totalItems++;
                // Estimate size by serializing the item
                totalSize += JSON.stringify(item).length;
                oldestItem = Math.min(oldestItem, item.timestamp);
                newestItem = Math.max(newestItem, item.timestamp);
            }
        }

        return {
            totalItems,
            totalSize,
            oldestItem: oldestItem === Number.MAX_SAFE_INTEGER ? 0 : oldestItem,
            newestItem,
            storageType: 'memory'
        };
    }

    private async cleanup(): Promise<void> {
        const items: Array<{ key: string; timestamp: number }> = [];
        const prefix = `${this.namespace}:`;

        // Collect all items with timestamps
        for (const [key, item] of this.storage.entries()) {
            if (key.startsWith(prefix)) {
                items.push({ key, timestamp: item.timestamp });
            }
        }

        // Sort by timestamp (oldest first) and remove oldest 25%
        items.sort((a, b) => a.timestamp - b.timestamp);
        const itemsToRemove = items.slice(0, Math.floor(items.length * 0.25));
        
        itemsToRemove.forEach(item => this.storage.delete(item.key));
    }

    // Additional methods for memory storage
    getAllKeys(): string[] {
        const prefix = `${this.namespace}:`;
        return Array.from(this.storage.keys())
            .filter(key => key.startsWith(prefix))
            .map(key => this.removeNamespace(key));
    }

    getAllItems(): Array<{ key: string; data: any; timestamp: number }> {
        const prefix = `${this.namespace}:`;
        const items: Array<{ key: string; data: any; timestamp: number }> = [];

        for (const [key, item] of this.storage.entries()) {
            if (key.startsWith(prefix) && !this.isExpired(item)) {
                items.push({
                    key: this.removeNamespace(key),
                    data: item.data,
                    timestamp: item.timestamp
                });
            }
        }

        return items;
    }

    // Cleanup expired items
    async cleanupExpired(): Promise<number> {
        const prefix = `${this.namespace}:`;
        const expiredKeys: string[] = [];

        for (const [key, item] of this.storage.entries()) {
            if (key.startsWith(prefix) && this.isExpired(item)) {
                expiredKeys.push(key);
            }
        }

        expiredKeys.forEach(key => this.storage.delete(key));
        return expiredKeys.length;
    }
}
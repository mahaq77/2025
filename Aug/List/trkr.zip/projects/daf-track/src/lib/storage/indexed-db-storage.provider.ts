import { BaseStorageProvider } from './base-storage.provider';
import { StorageItem, StorageOptions, StorageStats } from '../models/storage.models';

export class IndexedDBStorageProvider extends BaseStorageProvider {
    private dbName: string;
    private dbVersion: number;
    private storeName: string;
    private db: IDBDatabase | null = null;

    constructor(options: StorageOptions & { 
        dbName?: string; 
        dbVersion?: number; 
        storeName?: string; 
    } = {}) {
        super(options);
        this.dbName = options.dbName || 'DafTrackerDB';
        this.dbVersion = options.dbVersion || 1;
        this.storeName = options.storeName || 'tracking_data';
    }

    private async initDB(): Promise<IDBDatabase> {
        if (this.db) {
            return this.db;
        }

        return new Promise((resolve, reject) => {
            if (!window.indexedDB) {
                reject(new Error('IndexedDB is not supported'));
                return;
            }

            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = (event.target as IDBOpenDBRequest).result;
                
                if (!db.objectStoreNames.contains(this.storeName)) {
                    const store = db.createObjectStore(this.storeName, { keyPath: 'key' });
                    store.createIndex('timestamp', 'timestamp', { unique: false });
                    store.createIndex('ttl', 'ttl', { unique: false });
                }
            };
        });
    }

    async store(key: string, data: any): Promise<void> {
        const db = await this.initDB();
        const namespacedKey = this.getNamespacedKey(key);
        const item = this.createStorageItem(data);

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readwrite');
            const store = transaction.objectStore(this.storeName);
            
            const request = store.put({
                key: namespacedKey,
                ...item
            });

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async retrieve(key: string): Promise<any> {
        const db = await this.initDB();
        const namespacedKey = this.getNamespacedKey(key);

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readonly');
            const store = transaction.objectStore(this.storeName);
            const request = store.get(namespacedKey);

            request.onsuccess = () => {
                const result = request.result;
                if (!result) {
                    resolve(null);
                    return;
                }

                const item: StorageItem = {
                    data: result.data,
                    timestamp: result.timestamp,
                    ttl: result.ttl,
                    metadata: result.metadata
                };

                if (this.isExpired(item)) {
                    this.remove(key).then(() => resolve(null));
                    return;
                }

                resolve(item.data);
            };

            request.onerror = () => reject(request.error);
        });
    }

    async remove(key: string): Promise<void> {
        const db = await this.initDB();
        const namespacedKey = this.getNamespacedKey(key);

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readwrite');
            const store = transaction.objectStore(this.storeName);
            const request = store.delete(namespacedKey);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async clear(): Promise<void> {
        const db = await this.initDB();
        const prefix = `${this.namespace}:`;

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readwrite');
            const store = transaction.objectStore(this.storeName);
            const request = store.openCursor();

            request.onsuccess = (event) => {
                const cursor = (event.target as IDBRequest).result;
                if (cursor) {
                    if (cursor.key.toString().startsWith(prefix)) {
                        cursor.delete();
                    }
                    cursor.continue();
                } else {
                    resolve();
                }
            };

            request.onerror = () => reject(request.error);
        });
    }

    async size(): Promise<number> {
        const db = await this.initDB();
        const prefix = `${this.namespace}:`;

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readonly');
            const store = transaction.objectStore(this.storeName);
            const request = store.openCursor();
            let count = 0;

            request.onsuccess = (event) => {
                const cursor = (event.target as IDBRequest).result;
                if (cursor) {
                    if (cursor.key.toString().startsWith(prefix)) {
                        count++;
                    }
                    cursor.continue();
                } else {
                    resolve(count);
                }
            };

            request.onerror = () => reject(request.error);
        });
    }

    async getStats(): Promise<StorageStats> {
        const db = await this.initDB();
        const prefix = `${this.namespace}:`;

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readonly');
            const store = transaction.objectStore(this.storeName);
            const request = store.openCursor();

            let totalItems = 0;
            let totalSize = 0;
            let oldestItem = Number.MAX_SAFE_INTEGER;
            let newestItem = 0;

            request.onsuccess = (event) => {
                const cursor = (event.target as IDBRequest).result;
                if (cursor) {
                    const key = cursor.key.toString();
                    if (key.startsWith(prefix)) {
                        totalItems++;
                        const value = cursor.value;
                        totalSize += JSON.stringify(value).length;
                        oldestItem = Math.min(oldestItem, value.timestamp);
                        newestItem = Math.max(newestItem, value.timestamp);
                    }
                    cursor.continue();
                } else {
                    resolve({
                        totalItems,
                        totalSize,
                        oldestItem: oldestItem === Number.MAX_SAFE_INTEGER ? 0 : oldestItem,
                        newestItem,
                        storageType: 'indexedDB'
                    });
                }
            };

            request.onerror = () => reject(request.error);
        });
    }

    // Additional IndexedDB specific methods
    async getAllKeys(): Promise<string[]> {
        const db = await this.initDB();
        const prefix = `${this.namespace}:`;

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readonly');
            const store = transaction.objectStore(this.storeName);
            const request = store.getAllKeys();

            request.onsuccess = () => {
                const keys = request.result
                    .filter(key => key.toString().startsWith(prefix))
                    .map(key => this.removeNamespace(key.toString()));
                resolve(keys);
            };

            request.onerror = () => reject(request.error);
        });
    }

    async cleanupExpired(): Promise<number> {
        const db = await this.initDB();
        const prefix = `${this.namespace}:`;
        const now = Date.now();

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([this.storeName], 'readwrite');
            const store = transaction.objectStore(this.storeName);
            const request = store.openCursor();
            let deletedCount = 0;

            request.onsuccess = (event) => {
                const cursor = (event.target as IDBRequest).result;
                if (cursor) {
                    const key = cursor.key.toString();
                    const value = cursor.value;
                    
                    if (key.startsWith(prefix)) {
                        const item: StorageItem = {
                            data: value.data,
                            timestamp: value.timestamp,
                            ttl: value.ttl,
                            metadata: value.metadata
                        };

                        if (this.isExpired(item)) {
                            cursor.delete();
                            deletedCount++;
                        }
                    }
                    cursor.continue();
                } else {
                    resolve(deletedCount);
                }
            };

            request.onerror = () => reject(request.error);
        });
    }

    async close(): Promise<void> {
        if (this.db) {
            this.db.close();
            this.db = null;
        }
    }
}
import { StorageProvider, StorageItem, StorageOptions, StorageStats } from '../models';

export abstract class BaseStorageProvider implements StorageProvider {
    protected options: StorageOptions;
    protected namespace: string;

    constructor(options: StorageOptions = {}) {
        this.options = {
            encrypt: false,
            compress: false,
            ttl: undefined,
            namespace: 'daf-tracker',
            ...options
        };
        this.namespace = this.options.namespace!;
    }

    abstract store(key: string, data: any): Promise<void> | void;
    abstract retrieve(key: string): Promise<any> | any;
    abstract remove(key: string): Promise<void> | void;
    abstract clear(): Promise<void> | void;
    abstract size(): Promise<number> | number;
    abstract getStats(): Promise<StorageStats> | StorageStats;

    protected createStorageItem<T>(data: T): StorageItem<T> {
        return {
            data,
            timestamp: Date.now(),
            ttl: this.options.ttl,
            metadata: {}
        };
    }

    protected isExpired(item: StorageItem): boolean {
        if (!item.ttl) return false;
        return Date.now() > (item.timestamp + item.ttl);
    }

    protected getNamespacedKey(key: string): string {
        return `${this.namespace}:${key}`;
    }

    protected removeNamespace(key: string): string {
        const prefix = `${this.namespace}:`;
        return key.startsWith(prefix) ? key.substring(prefix.length) : key;
    }

    protected async compress(data: string): Promise<string> {
        if (!this.options.compress) return data;
        // Simple compression implementation
        // In a real implementation, you might use a library like pako
        return data;
    }

    protected async decompress(data: string): Promise<string> {
        if (!this.options.compress) return data;
        // Simple decompression implementation
        return data;
    }

    protected async encrypt(data: string): Promise<string> {
        if (!this.options.encrypt) return data;
        // Simple encryption implementation
        // In a real implementation, you would use proper encryption
        return btoa(data);
    }

    protected async decrypt(data: string): Promise<string> {
        if (!this.options.encrypt) return data;
        // Simple decryption implementation
        try {
            return atob(data);
        } catch {
            return data; // Return original if decryption fails
        }
    }

    protected async processForStorage(data: any): Promise<string> {
        let serialized = JSON.stringify(data);
        serialized = await this.compress(serialized);
        serialized = await this.encrypt(serialized);
        return serialized;
    }

    protected async processFromStorage(data: string): Promise<any> {
        let processed = await this.decrypt(data);
        processed = await this.decompress(processed);
        return JSON.parse(processed);
    }
}
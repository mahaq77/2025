import 'zone.js';
import { bootstrapApplication } from '@angular/platform-browser';
import { importProvidersFrom } from '@angular/core';
import { AppComponent } from './app/app.component';
import { DafTrackModule } from 'daf-track';

bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(
      DafTrackModule.forRoot({
        enabled: true,
        debug: true,
        storageType: 'localStorage' as any,
        requireConsent: true,
        respectDoNotTrack: true,
        sampleRate: 1.0,
        batchSize: 10,
        batchTimeout: 3000,
        customFields: {
          appName: 'DAF Tracker Demo',
          version: '1.0.0'
        }
      })
    )
  ]
}).catch((err) => console.error(err));
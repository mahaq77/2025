import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { 
  DafTrack, 
  DafTracker, 
  DafTrackerDirective,
  AnalyticsService,
  ConsentService,
  HeatmapService,
  PerformanceService,
  EventType
} from 'daf-track';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule,
    DafTrack, 
    DafTrackerDirective
  ],
  template: `
    <div class="app-container">
      <header class="header">
        <h1 dafTrack="view" 
            dafTrackCategory="branding" 
            dafTrackAction="logo-view">
          DAF Tracker Demo
        </h1>
        <nav>
          <button dafTrack="click" 
                  dafTrackCategory="navigation" 
                  dafTrackAction="nav-home"
                  class="nav-btn">
            Home
          </button>
          <button dafTrack="click" 
                  dafTrackCategory="navigation" 
                  dafTrackAction="nav-features"
                  class="nav-btn">
            Features
          </button>
          <button dafTrack="click" 
                  dafTrackCategory="navigation" 
                  dafTrackAction="nav-pricing"
                  class="nav-btn">
            Pricing
          </button>
        </nav>
      </header>

      <main class="main-content">
        <!-- Hero Section -->
        <section dafTrack="view" 
                 dafTrackCategory="content" 
                 dafTrackAction="hero-view"
                 class="hero">
          <h2>Advanced User Interaction Tracking</h2>
          <p>Track user behavior, analyze performance, and ensure GDPR compliance with our comprehensive Angular library.</p>
          <button dafTrack="click" 
                  dafTrackCategory="conversion" 
                  dafTrackAction="cta-primary"
                  dafTrackLabel="Get Started"
                  class="cta-button">
            Get Started
          </button>
        </section>

        <!-- Features Grid -->
        <section class="features">
          <h3>Key Features</h3>
          <div class="features-grid">
            <div dafTrack="hover" 
                 dafTrackCategory="engagement" 
                 dafTrackAction="feature-card-hover"
                 dafTrackLabel="Analytics"
                 class="feature-card">
              <h4>Real-time Analytics</h4>
              <p>Get instant insights into user behavior and engagement patterns.</p>
            </div>
            
            <div dafTrack="hover" 
                 dafTrackCategory="engagement" 
                 dafTrackAction="feature-card-hover"
                 dafTrackLabel="Heatmaps"
                 class="feature-card">
              <h4>Interactive Heatmaps</h4>
              <p>Visualize click patterns and user interaction hotspots.</p>
            </div>
            
            <div dafTrack="hover" 
                 dafTrackCategory="engagement" 
                 dafTrackAction="feature-card-hover"
                 dafTrackLabel="Performance"
                 class="feature-card">
              <h4>Performance Monitoring</h4>
              <p>Track Core Web Vitals and application performance metrics.</p>
            </div>
            
            <div dafTrack="hover" 
                 dafTrackCategory="engagement" 
                 dafTrackAction="feature-card-hover"
                 dafTrackLabel="Privacy"
                 class="feature-card">
              <h4>GDPR Compliance</h4>
              <p>Built-in consent management and privacy protection.</p>
            </div>
          </div>
        </section>

        <!-- Interactive Demo -->
        <section class="demo-section">
          <h3>Interactive Demo</h3>
          <div class="demo-controls">
            <button (click)="trackCustomEvent()" class="demo-btn">Track Custom Event</button>
            <button (click)="generateAnalytics()" class="demo-btn">Generate Analytics</button>
            <button (click)="startHeatmapTracking()" class="demo-btn">Start Heatmap</button>
            <button (click)="getPerformanceReport()" class="demo-btn">Performance Report</button>
            <button (click)="exportData()" class="demo-btn">Export Data</button>
          </div>
          
          <div class="demo-results" *ngIf="demoResults">
            <h4>Results:</h4>
            <pre>{{ demoResults | json }}</pre>
          </div>
        </section>

        <!-- Contact Form -->
        <section class="contact-section">
          <h3>Contact Us</h3>
          <form dafTrack="form_submit" 
                dafTrackCategory="conversion" 
                dafTrackAction="contact-form"
                (ngSubmit)="onSubmit()" 
                class="contact-form">
            <input dafTrack="focus" 
                   dafTrackCategory="form" 
                   dafTrackAction="field-focus"
                   dafTrackLabel="name"
                   type="text" 
                   placeholder="Your Name" 
                   [(ngModel)]="formData.name"
                   name="name">
            
            <input dafTrack="focus" 
                   dafTrackCategory="form" 
                   dafTrackAction="field-focus"
                   dafTrackLabel="email"
                   type="email" 
                   placeholder="Your Email" 
                   [(ngModel)]="formData.email"
                   name="email">
            
            <textarea dafTrack="focus" 
                      dafTrackCategory="form" 
                      dafTrackAction="field-focus"
                      dafTrackLabel="message"
                      placeholder="Your Message" 
                      [(ngModel)]="formData.message"
                      name="message"></textarea>
            
            <button type="submit" class="submit-btn">Send Message</button>
          </form>
        </section>
      </main>

      <!-- DAF Tracker Dashboard Component -->
      <lib-daf-track [showDashboard]="showDashboard" 
                     [showToggle]="true"
                     [autoRefresh]="true"></lib-daf-track>

      <footer class="footer">
        <p>&copy; 2024 DAF Tracker. All rights reserved.</p>
        <div class="footer-controls">
          <button (click)="toggleDashboard()" class="footer-btn">
            {{ showDashboard ? 'Hide' : 'Show' }} Dashboard
          </button>
          <button (click)="clearAllData()" class="footer-btn danger">
            Clear All Data
          </button>
        </div>
      </footer>
    </div>
  `,
  styles: `
    .app-container {
      min-height: 100vh;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 1rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .header h1 {
      margin: 0;
      font-size: 1.8rem;
      font-weight: 600;
    }

    .header nav {
      display: flex;
      gap: 1rem;
    }

    .nav-btn {
      background: rgba(255,255,255,0.2);
      border: 1px solid rgba(255,255,255,0.3);
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .nav-btn:hover {
      background: rgba(255,255,255,0.3);
      transform: translateY(-1px);
    }

    .main-content {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }

    .hero {
      text-align: center;
      padding: 4rem 2rem;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      border-radius: 12px;
      margin-bottom: 3rem;
    }

    .hero h2 {
      font-size: 2.5rem;
      margin-bottom: 1rem;
      color: #333;
    }

    .hero p {
      font-size: 1.2rem;
      color: #666;
      margin-bottom: 2rem;
      max-width: 600px;
      margin-left: auto;
      margin-right: auto;
    }

    .cta-button {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      padding: 1rem 2rem;
      font-size: 1.1rem;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s;
      box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }

    .cta-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
    }

    .features {
      margin-bottom: 3rem;
    }

    .features h3 {
      text-align: center;
      font-size: 2rem;
      margin-bottom: 2rem;
      color: #333;
    }

    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 2rem;
    }

    .feature-card {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      transition: all 0.3s;
      cursor: pointer;
    }

    .feature-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 30px rgba(0,0,0,0.15);
    }

    .feature-card h4 {
      color: #667eea;
      margin-bottom: 1rem;
      font-size: 1.3rem;
    }

    .feature-card p {
      color: #666;
      line-height: 1.6;
    }

    .demo-section {
      background: #f8f9fa;
      padding: 2rem;
      border-radius: 12px;
      margin-bottom: 3rem;
    }

    .demo-section h3 {
      text-align: center;
      margin-bottom: 2rem;
      color: #333;
    }

    .demo-controls {
      display: flex;
      justify-content: center;
      gap: 1rem;
      margin-bottom: 2rem;
      flex-wrap: wrap;
    }

    .demo-btn {
      background: #28a745;
      color: white;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .demo-btn:hover {
      background: #218838;
      transform: translateY(-1px);
    }

    .demo-results {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      border-left: 4px solid #667eea;
    }

    .demo-results pre {
      background: #f8f9fa;
      padding: 1rem;
      border-radius: 4px;
      overflow-x: auto;
      font-size: 0.9rem;
    }

    .contact-section {
      margin-bottom: 3rem;
    }

    .contact-section h3 {
      text-align: center;
      margin-bottom: 2rem;
      color: #333;
    }

    .contact-form {
      max-width: 600px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .contact-form input,
    .contact-form textarea {
      padding: 1rem;
      border: 2px solid #e9ecef;
      border-radius: 8px;
      font-size: 1rem;
      transition: border-color 0.3s;
    }

    .contact-form input:focus,
    .contact-form textarea:focus {
      outline: none;
      border-color: #667eea;
    }

    .contact-form textarea {
      min-height: 120px;
      resize: vertical;
    }

    .submit-btn {
      background: #667eea;
      color: white;
      border: none;
      padding: 1rem;
      border-radius: 8px;
      font-size: 1.1rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .submit-btn:hover {
      background: #5a6fd8;
    }

    .footer {
      background: #343a40;
      color: white;
      padding: 2rem;
      text-align: center;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 1rem;
    }

    .footer-controls {
      display: flex;
      gap: 1rem;
    }

    .footer-btn {
      background: #6c757d;
      color: white;
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .footer-btn:hover {
      background: #5a6268;
    }

    .footer-btn.danger {
      background: #dc3545;
    }

    .footer-btn.danger:hover {
      background: #c82333;
    }

    @media (max-width: 768px) {
      .header {
        flex-direction: column;
        gap: 1rem;
      }

      .hero h2 {
        font-size: 2rem;
      }

      .features-grid {
        grid-template-columns: 1fr;
      }

      .demo-controls {
        flex-direction: column;
        align-items: center;
      }

      .footer {
        flex-direction: column;
      }
    }
  `
})
export class AppComponent implements OnInit {
  title = 'daf-tracker-demo';
  showDashboard = false;
  demoResults: any = null;
  
  formData = {
    name: '',
    email: '',
    message: ''
  };

  constructor(
    private tracker: DafTracker,
    private analytics: AnalyticsService,
    private consent: ConsentService,
    private heatmap: HeatmapService,
    private performance: PerformanceService
  ) {}

  ngOnInit(): void {
    // Initialize tracking
    this.tracker.trackView('/demo-app');
    
    // Set up consent (for demo purposes, auto-grant)
    setTimeout(() => {
      this.consent.grantConsent(['analytics', 'marketing']);
    }, 2000);
  }

  async trackCustomEvent(): Promise<void> {
    this.tracker.trackCustom('demo_interaction', 'engagement', {
      feature: 'custom_event_demo',
      timestamp: Date.now(),
      userAgent: navigator.userAgent
    });
    
    this.demoResults = {
      action: 'Custom Event Tracked',
      timestamp: new Date().toISOString(),
      eventType: 'custom'
    };
  }

  async generateAnalytics(): Promise<void> {
    const report = await this.analytics.generateReport({
      startDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // Last 24 hours
      endDate: new Date()
    });
    
    this.demoResults = {
      action: 'Analytics Generated',
      totalEvents: report.data.totalEvents,
      uniqueUsers: report.data.uniqueUsers,
      topPages: report.data.topPages.slice(0, 3)
    };
  }

  async startHeatmapTracking(): Promise<void> {
    this.heatmap.configure({
      enabled: true,
      trackClicks: true,
      trackHovers: true,
      sampleRate: 1.0
    });
    
    this.heatmap.startTracking();
    
    this.demoResults = {
      action: 'Heatmap Tracking Started',
      status: 'active',
      trackingClicks: true,
      trackingHovers: true
    };
  }

  async getPerformanceReport(): Promise<void> {
    const report = await this.performance.getPerformanceReport();
    
    this.demoResults = {
      action: 'Performance Report Generated',
      score: report.score,
      metrics: {
        lcp: report.metrics?.largestContentfulPaint,
        fid: report.metrics?.firstInputDelay,
        cls: report.metrics?.cumulativeLayoutShift
      }
    };
  }

  async exportData(): Promise<void> {
    const data = await this.tracker.exportData('json');
    const blob = new Blob([data], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'daf-tracker-demo-data.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    this.demoResults = {
      action: 'Data Exported',
      filename: 'daf-tracker-demo-data.json',
      timestamp: new Date().toISOString()
    };
  }

  onSubmit(): void {
    // Form submission is automatically tracked by directive
    console.log('Form submitted:', this.formData);
    
    // Reset form
    this.formData = { name: '', email: '', message: '' };
    
    this.demoResults = {
      action: 'Form Submitted',
      message: 'Thank you for your message!'
    };
  }

  toggleDashboard(): void {
    this.showDashboard = !this.showDashboard;
  }

  async clearAllData(): Promise<void> {
    if (confirm('Are you sure you want to clear all tracking data? This action cannot be undone.')) {
      await this.tracker.clearData();
      this.demoResults = {
        action: 'All Data Cleared',
        timestamp: new Date().toISOString()
      };
    }
  }
}
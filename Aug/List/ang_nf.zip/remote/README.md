# Remote (microfrontend) - Angular 20 + Native Federation (starter)

## Quick notes
- This remote exposes `./RemoteModule` via `federation.config.js`.
- The build step (with @angular-architects/native-federation) will emit a federation manifest / import map entry.
- In development you can run the remote locally on port 4201 and serve the generated manifest so the shell can consume it.

## Files of interest
- `federation.config.js` — declares `exposes` and shared libs
- `src/app/remote/remote.module.ts` — module exported to shell
- `src/app/remote/remote.component.ts` — example component

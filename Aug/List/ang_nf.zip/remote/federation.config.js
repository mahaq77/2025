const { withNativeFederation, shareAll } = require('@angular-architects/native-federation/config');

module.exports = withNativeFederation({
  name: 'remoteApp',
  exposes: {
    // exposed name consumed by shell: remoteApp -> ./RemoteModule
    './RemoteModule': './src/app/remote/remote.module.ts'
  },
  shared: {
    ...shareAll({ singleton: true, strictVersion: true })
  }
});

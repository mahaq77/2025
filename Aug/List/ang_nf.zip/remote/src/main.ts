import { bootstrapApplication } from '@angular/platform-browser';
import { RemoteComponent } from './app/remote/remote.component';

// A remote doesn't always need to bootstrap a full app during ESM consumption;
// but for local dev we provide a small host to view the remote component standalone.
bootstrapApplication(RemoteComponent).catch(err => console.error(err));

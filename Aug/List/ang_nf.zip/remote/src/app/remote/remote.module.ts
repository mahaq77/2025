import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RemoteComponent } from './remote.component';

@NgModule({
  declarations: [RemoteComponent],
  imports: [CommonModule],
  exports: [RemoteComponent]
})
export class RemoteModule {
  // Exported module for Native Federation to consume
}

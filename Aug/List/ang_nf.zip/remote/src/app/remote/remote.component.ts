import { Component } from '@angular/core';

@Component({
  selector: 'remote-component',
  template: `<div style="border: 2px dashed #888; padding: 12px;">
    <h3>Remote Component</h3>
    <p>This component is served from the remote microfrontend (remoteApp).</p>
  </div>`,
  standalone: true
})
export class RemoteComponent {}

import { enableProdMode } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { initFederation as initNativeFederation } from '@angular-architects/native-federation';

(async () => {
  // load the manifest/import map produced by your build or hosted by your CDN
  // adjust the path or make this a full URL in production
  try {
    await initNativeFederation('/assets/federation.manifest.json');
  } catch (e) {
    console.warn('Could not init native federation import map:', e);
  }

  await bootstrapApplication(AppComponent);
})();

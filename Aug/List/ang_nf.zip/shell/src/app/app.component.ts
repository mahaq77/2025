import { Component } from '@angular/core';
import { loadRemoteModule } from '@angular-architects/native-federation';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <h1>Shell (Angular 20) — Native Federation</h1>
    <button (click)="loadRemote()">Load Remote Component</button>
    <div id="remote-host"></div>
  `
})
export class AppComponent {
  async loadRemote() {
    try {
      const m = await loadRemoteModule({
        remoteName: 'remoteApp',
        exposedModule: './RemoteModule'
      });
      // expected exported symbol: RemoteModule or RemoteComponent
      // for demonstration we'll console.log it and let users integrate via routes or ViewContainerRef
      console.log('Loaded remote module', m);
      alert('Remote loaded — check console for exported symbols');
    } catch (e) {
      console.error('Error loading remote', e);
      alert('Failed to load remote. See console.');
    }
  }
}

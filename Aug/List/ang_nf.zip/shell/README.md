# Shell (host) - Angular 20 + Native Federation (starter)

## Quick notes
- This is a minimal starter with `initNativeFederation()` in `main.ts`.
- The shell expects a `federation.manifest.json` or import map at `/assets/federation.manifest.json`.
- During development you can host the remote locally and point the import map to the remote's JS bundle URL.

## Typical workflow
1. Build & deploy the remote to a URL (e.g. `http://localhost:4201/remoteApp.js` and asset manifest).
2. Ensure shell's import map points to the remote bundle (either baked into `assets` or fetched at runtime).
3. Run `npm start` in the shell (requires Angular CLI and packages installed).

## Files of interest
- `federation.config.js` — Native Federation config for the shell
- `src/main.ts` — runtime init that loads federation manifest
- `src/app/app.component.ts` — simple demo that triggers `loadRemoteModule()`

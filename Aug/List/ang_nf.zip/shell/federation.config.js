const { withNativeFederation, shareAll } = require('@angular-architects/native-federation/config');

module.exports = withNativeFederation({
  name: 'shell',
  remotes: {
    // example placeholder; actual URL will be provided at runtime via federation.manifest.json or import map
    // 'remoteApp': 'http://localhost:4201/remoteApp.js'
  },
  shared: {
    ...shareAll({ singleton: true, strictVersion: true })
  }
});

# Angular 20 Native Federation starter (Shell + Remote)

This zip contains two separate minimal starter repositories:
- `shell/` — host application that initializes the Native Federation runtime and dynamically loads remotes.
- `remote/` — microfrontend that exposes a `RemoteModule` via Native Federation.

## How to use
1. Unzip and `cd` into `shell` and `remote` in separate terminals.
2. Run `npm install` in each repo (this will install Angular CLI and dependencies).
3. Build and run the remote (example dev): `npm run start` (it will run an Angular dev server; you may need to configure the native federation output).
4. Ensure the remote's build produces a federation manifest (import map). The `@angular-architects/native-federation` package adds necessary builders to generate the import map during build — consult its README for configuration.
5. Point the shell to the remote by ensuring `assets/federation.manifest.json` is available to the shell app (or the shell fetches the remote manifest at runtime as shown in `src/main.ts`).

## Notes & next steps
- These files are intentionally minimal to give a clear starting point. You'll need to integrate the native-federation builder into `angular.json` or use the library's setup instructions to generate the proper ESM bundles + manifest.
- Read the `@angular-architects/native-federation` documentation for exact `angular.json` builders and build flags.

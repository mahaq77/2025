import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class WebSocketService {
  private socket!: Socket;
  recordStatus$ = new BehaviorSubject<string | null>(null);

  constructor(private auth: AuthService) {
    // Ensure the socket is initialized
    if (!this.socket) {
      this.connect();
    } 
  }

  connect() {
    const token = this.auth.getToken();
    this.socket = io('http://localhost:3000', {
      auth: { token }
    });

    this.socket.on('start-edit', ({ recordId, editingUser }: { recordId: string; editingUser: string }) => {
      console.log(`Record ${recordId} is being edited by ${editingUser}`);
      
      this.recordStatus$.next(`Record ${recordId} is being edited by ${editingUser}`);
    });

    this.socket.on('stop-edit', ({ recordId }: { recordId: string }) => {
      console.log(`Editing stopped for record ${recordId}`);
      this.recordStatus$.next(`Editing stopped for record ${recordId}`);
    });
  }

  onStartEdit(callback: (message: string) => void): void {
    this.socket.on('start-edit', callback);
  }

  startEdit(recordId: string) {
    this.socket.emit('start-edit', {
      recordId,
      userId: this.auth.getUserId()
    });
  }

  stopEdit(recordId: string) {
    this.socket.emit('stop-edit', { recordId });
  }
}
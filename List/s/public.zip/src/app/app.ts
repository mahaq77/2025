import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './auth.service';
import { WebSocketService } from './websocket.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, FormsModule  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'myapp';
  recordId: string = '';
  status: string = '';

  constructor(private ws: WebSocketService, private auth: AuthService) { }

  ngOnInit() {
     this.auth.login().then(() => {
      this.ws.connect();
      this.ws.recordStatus$.subscribe(msg => {
        console.log('Received status update:', msg);
        this.status = msg ?? '';
      });
    });

    this.ws.onStartEdit((message: string) => {
      console.log('Start Edit:', message);
      this.status = message;
    });
  }

  start() {
    this.ws.startEdit(this.recordId);
  }

  stop() {
    this.ws.stopEdit(this.recordId);
  }
}
function start() {
  throw new Error('Function not implemented.');
}


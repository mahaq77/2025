const editingMap = new Map();

function setEditing(recordId, userId) {
  editingMap.set(recordId, userId);
  return userId;
}

function clearEditing(recordId) {
  editingMap.delete(recordId);
}

module.exports = {
  setEditing,
  clearEditing,
};
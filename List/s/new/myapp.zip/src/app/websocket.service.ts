import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { BehaviorSubject, Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class WebSocketService {
  private socket!: Socket;
  recordStatus$ = new BehaviorSubject<any | null>(null);

  constructor(private auth: AuthService) {
    // Ensure the socket is initialized
    if (!this.socket) {
      this.connect();
      this.listen('start-edit');
      this.listen('stop-edit');
    }
  }

  connect() {
    const token = this.auth.getToken();
    this.socket = io('http://localhost:3001', {
      auth: { token }
    });

    this.socket.on('start-edit', ({ recordId, editingUser }: { recordId: string; editingUser: string }) => {
      const msg = {
        message: `Record ${recordId} is being edited by ${editingUser}`,
        userId: editingUser,
        isEditing: true,
      }
      this.recordStatus$.next(msg);
    });

    this.socket.on('stop-edit', ({ recordId, userId }: { recordId: string; userId: string }) => {
      console.log(`Record ${recordId} is being stopped by ${userId}`);
      const msg = {
        message: `Editing stopped for record ${recordId}`,
        userId: userId,
        isEditing: false,
      }
      this.recordStatus$.next(msg);
    });
  }

  onStartEdit(callback: (message: string) => void): void {
    this.socket.on('start-edit', callback);
  }

  startEdit(recordId: string) {
    this.socket.emit('start-edit', {
      recordId,
      userId: this.auth.getUserId()
    });
  }

  stopEdit(recordId: string) {
    this.socket.emit('stop-edit', {
      recordId,
      userId: this.auth.getUserId()
    });
  }

  listen<T>(eventName: string): Observable<T> {
    const socket = this.socket;
    if (!socket) {
      throw new Error('Socket connection is not established');
    }

    return new Observable((subscriber) => {
      socket.on(eventName, (data) => {
        subscriber.next(data);
      });
    });
  }
}
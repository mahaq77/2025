import { Component, OnInit, signal, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './auth.service';
import { WebSocketService } from './websocket.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from './material.module';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, FormsModule, MaterialModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  protected title = 'myapp';
  recordId: string = '';
  status = signal<string | null>(null);

  private _snackBar = inject(MatSnackBar);
  userId = '';
  isUsedByAnotherUser = false;


  constructor(private ws: WebSocketService, private auth: AuthService) { }

  ngOnInit() {
    this.auth.login().then(() => {
      this.ws.connect();
      this.userId = this.auth.getUserId();
      console.log('User ID:', this.userId);
      this.ws.recordStatus$.subscribe(status => {
        console.log('Received status update:', status);
        if (status && status?.userId !== this.userId) {
          this.isUsedByAnotherUser = status.isEditing;
          this.openSnackBar(`Record is being edited by ${status?.userId}`, 'Close');
        } else {
          this.isUsedByAnotherUser = false;
        } 
        this.status.set(status?.message);
      });
    });
  }

  start() {
    this.ws.startEdit(this.recordId);
    setTimeout(() => {
      this.stop();
    }, 3000);
  }

  stop() {
    this.ws.stopEdit(this.recordId);
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action);
  }
}

export interface RegisterRequestInterface {
  email: string;
  username: string;
  password: string;
}

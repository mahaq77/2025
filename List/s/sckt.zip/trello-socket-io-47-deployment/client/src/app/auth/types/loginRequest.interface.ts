export interface LoginRequestInterface {
  email: string;
  password: string;
}

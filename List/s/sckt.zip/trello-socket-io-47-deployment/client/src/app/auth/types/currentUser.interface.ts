export interface CurrentUserInterface {
  id: string;
  token: string;
  username: string;
  email: string;
}

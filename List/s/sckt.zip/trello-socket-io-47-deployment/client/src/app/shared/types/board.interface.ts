export interface BoardInterface {
  id: string;
  title: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export interface ColumnInputInterface {
  title: string;
  boardId: string;
}

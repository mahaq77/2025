export interface TaskInputInterface {
  title: string;
  columnId: string;
  boardId: string;
}

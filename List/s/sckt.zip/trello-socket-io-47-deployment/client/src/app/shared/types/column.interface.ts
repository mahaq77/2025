export interface ColumnInterface {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
}

export const environment = {
  production: true,
  apiUrl: 'http://eltrello.com/api',
  socketUrl: 'http://eltrello.com',
};

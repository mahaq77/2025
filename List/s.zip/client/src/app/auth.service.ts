import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private userId = 'User_' + Math.floor(Math.random() * 1000);

  login() {
    return fetch('http://localhost:3000/login', {
      method: 'POST',
      body: JSON.stringify({ userId: this.userId }),
      headers: { 'Content-Type': 'application/json' }
    }).then(res => res.json()).then(res => {
      localStorage.setItem('token', res.token);
      return res.token;
    });
  }

  getToken() {
    return localStorage.getItem('token');
  }

  getUserId() {
    return this.userId;
  }
}
import { Component, OnInit } from '@angular/core';
import { WebSocketService } from './websocket.service';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  template: \`
    <h2>Record Editor</h2>
    <input [(ngModel)]="recordId" placeholder="Record ID" />
    <button (click)="start()">Start Editing</button>
    <button (click)="stop()">Stop Editing</button>
    <p *ngIf="status">{{ status }}</p>
  \`
})
export class AppComponent implements OnInit {
  recordId = '';
  status = '';

  constructor(private ws: WebSocketService, private auth: AuthService) {}

  ngOnInit() {
    this.auth.login().then(() => {
      this.ws.connect();
      this.ws.recordStatus$.subscribe(msg => {
        this.status = msg ?? '';
      });
    });
  }

  start() {
    this.ws.startEdit(this.recordId);
  }

  stop() {
    this.ws.stopEdit(this.recordId);
  }
}
import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class WebSocketService {
  private socket: Socket;
  recordStatus$ = new BehaviorSubject<string | null>(null);

  constructor(private auth: AuthService) {}

  connect() {
    const token = this.auth.getToken();
    this.socket = io('http://localhost:3000', {
      auth: { token }
    });

    this.socket.on('record-editing', ({ recordId, editingUser }) => {
      this.recordStatus$.next(\`Record \${recordId} is being edited by \${editingUser}\`);
    });

    this.socket.on('record-edit-stopped', ({ recordId }) => {
      this.recordStatus$.next(\`Editing stopped for record \${recordId}\`);
    });
  }

  startEdit(recordId: string) {
    this.socket.emit('start-edit', {
      recordId,
      userId: this.auth.getUserId()
    });
  }

  stopEdit(recordId: string) {
    this.socket.emit('stop-edit', { recordId });
  }
}
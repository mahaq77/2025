const jwt = require('jsonwebtoken');
const SECRET = 'super_secret_key';

function generateToken(userId) {
  return jwt.sign({ userId }, SECRET, { expiresIn: '1h' });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, SECRET);
  } catch {
    return null;
  }
}

module.exports = { generateToken, verifyToken };
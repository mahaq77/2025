const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const recordState = require('./record-state');
const { verifyToken, generateToken } = require('./auth');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.post('/login', (req, res) => {
  const { userId } = req.body;
  const token = generateToken(userId);
  res.json({ token });
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  const payload = verifyToken(token);
  if (!payload) return next(new Error('Unauthorized'));
  socket.user = payload;
  next();
});

io.on('connection', (socket) => {
  socket.on('start-edit', ({ recordId, userId }) => {
    const editingUser = recordState.setEditing(recordId, userId);
    socket.broadcast.emit('record-editing', { recordId, editingUser });
  });

  socket.on('stop-edit', ({ recordId }) => {
    recordState.clearEditing(recordId);
    socket.broadcast.emit('record-edit-stopped', { recordId });
  });
});

server.listen(3000, () => console.log('Server listening on http://localhost:3000'));
# Angular 7 + Google Authenticator + Node JS Web App with Two-Factor Authentication

> This is a simple web-application to demonstrate the integration of Two-Factor Authentication in an Angular 7 application.

## With :heart: by
- Narendra Kamath G
- E-mail: [narendrakamathg@gmail.com](mailto:narendrakamathg@gmail.com)
- LinkedIn: [Narendra Kamath G](https://in.linkedin.com/in/narendra-kamath-g-50158230)
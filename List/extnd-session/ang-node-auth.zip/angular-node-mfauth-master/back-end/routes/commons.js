let userObject = {};

module.exports = {
    userObject
};
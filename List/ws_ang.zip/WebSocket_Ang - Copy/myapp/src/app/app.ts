import { Component, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './auth.service';
import { WebSocketService } from './websocket.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, FormsModule  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  protected title = 'myapp';
  recordId: string = '';
  status = signal<string | null>(null);

  constructor(private ws: WebSocketService, private auth: AuthService) { }

  ngOnInit() {
     this.auth.login().then(() => {
      this.ws.connect();
      this.ws.recordStatus$.subscribe(msg => {
        console.log('Received status update:', msg);
        this.status.set(msg);
      });
    });
  }

  start() {
    this.ws.startEdit(this.recordId);
  }

  stop() {
    this.ws.stopEdit(this.recordId);
  }
}
